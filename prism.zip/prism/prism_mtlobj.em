# prism_mtlobj - Wavefront OBJ + MTL export with a textured material.
#
# Extends emeraldx mesh.save_obj with:
#   * an .mtl sidecar referencing the baked texture (map_Kd)
#   * V flip on export (Prism/emeraldx UV origin is TOP-left; OBJ expects
#     bottom-left)
#   * chunked string building so large meshes export in linear time
#
#   export_obj(m, dir, base, texName)  ->  writes dir/base.obj, dir/base.mtl
# emx-scope-safe

import strx;

# two-level accumulator: append lines to a small chunk, fold chunks into
# parts, join once - avoids O(n^2) string growth on big meshes.
fn fold(parts, chunk, line) {
    int c = 0; int p = 0;
    p = parts; c = chunk + line;
    if (len(c) > 8000) {
        p[len(p)] = c;
        c = "";
    }
    return [p, c];
}

fn export_obj(m, dir, base, texName) {
    int acc = 0; int chunk = 0; int f = 0; int faces = 0; int i = 0; int mtl = 0;
    int nf = 0; int normals = 0; int nv = 0; int out = 0; int parts = 0; int positions = 0;
    int uvs = 0; int a = 0; int b = 0; int c = 0;
    positions = m[0]; normals = m[1]; uvs = m[2]; faces = m[3];
    nv = len(positions) // 3;
    nf = len(faces) // 3;
    parts = []; chunk = "";
    acc = fold(parts, chunk, "# Prism procedural model\n");
    parts = acc[0]; chunk = acc[1];
    acc = fold(parts, chunk, "mtllib {base}.mtl\no {base}\n");
    parts = acc[0]; chunk = acc[1];
    for (i = 0; i < nv; ++i) {
        acc = fold(parts, chunk, "v {strx.fmt_g(positions[i*3])} {strx.fmt_g(positions[i*3+1])} {strx.fmt_g(positions[i*3+2])}\n");
        parts = acc[0]; chunk = acc[1];
    }
    for (i = 0; i < nv; ++i) {
        acc = fold(parts, chunk, "vt {strx.fmt_g(uvs[i*2])} {strx.fmt_g(1.0 - uvs[i*2+1])}\n");
        parts = acc[0]; chunk = acc[1];
    }
    for (i = 0; i < nv; ++i) {
        acc = fold(parts, chunk, "vn {strx.fmt_g(normals[i*3])} {strx.fmt_g(normals[i*3+1])} {strx.fmt_g(normals[i*3+2])}\n");
        parts = acc[0]; chunk = acc[1];
    }
    acc = fold(parts, chunk, "usemtl {base}_mat\ns off\n");
    parts = acc[0]; chunk = acc[1];
    for (f = 0; f < nf; ++f) {
        a = faces[f * 3] + 1; b = faces[f * 3 + 1] + 1; c = faces[f * 3 + 2] + 1;
        acc = fold(parts, chunk, "f {a}/{a}/{a} {b}/{b}/{b} {c}/{c}/{c}\n");
        parts = acc[0]; chunk = acc[1];
    }
    parts[len(parts)] = chunk;
    out = strx.join(parts, "");
    File fo = "{dir}/{base}.obj";
    fo.write(out);
    mtl = "# Prism material\nnewmtl {base}_mat\nKa 1.000 1.000 1.000\nKd 1.000 1.000 1.000\nKs 0.150 0.150 0.150\nNs 24.0\nd 1.0\nillum 2\nmap_Kd {texName}\n";
    File fm = "{dir}/{base}.mtl";
    fm.write(mtl);
    return true;
}
