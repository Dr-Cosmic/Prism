# prism_imageio - image file I/O for Prism.
# Works on emeraldx images: [w, h, channels, flatData], values 0..1, top-left origin.
#
#   save_png(img, path)   8-bit RGB PNG, written from scratch (zlib "stored"
#                         blocks + adler32 + crc32, no compression library)
#   png_bytes(img)        the same PNG as a byte string (embedded into FBX)
#   save_bmp(img, path)   24-bit uncompressed BMP
#   load_bmp(path)        24/32-bit uncompressed BMP (bottom-up or top-down)
#   load_ppm(path)        P2/P3 (ascii) and P5/P6 (binary) PPM/PGM
#   load_any(path)        sniffs BMP / PPM / PGM; PNG+JPEG explain themselves
# emx-scope-safe

import prism_binio;
import image;

# ---- shared: image -> raw 8-bit RGB rows ----------------------------------

fn row_rgb8(img, y) {
    int bc = 0; int c = 0; int i = 0; int px = 0; int row = 0; int w = 0; int ch = 0; int base = 0; int v = 0;
    bc = prism_binio.byte_chars();
    w = img[0]; ch = img[2];
    row = "";
    base = y * w * ch;
    if (ch == 1) {
        for (i = 0; i < w; ++i) {
            v = int(floor(img[3][base + i] * 255.0 + 0.5));
            if (v < 0) { v = 0; } if (v > 255) { v = 255; }
            px = bc[v];
            row = row + px + px + px;
        }
        return row;
    }
    for (i = 0; i < w; ++i) {
        for (c = 0; c < 3; ++c) {
            v = int(floor(img[3][base + i * ch + c] * 255.0 + 0.5));
            if (v < 0) { v = 0; } if (v > 255) { v = 255; }
            row = row + bc[v];
        }
    }
    return row;
}

# ---- PNG -------------------------------------------------------------------

fn png_chunk(ctype, data) {
    int crc = 0;
    crc = prism_binio.crc32(ctype + data);
    return prism_binio.u32be(len(data)) + ctype + data + prism_binio.u32be(crc);
}

fn png_bytes(img) {
    int adler = 0; int bc = 0; int bfinal = 0; int blocklen = 0; int chunk = 0; int h = 0;
    int i = 0; int ihdr = 0; int k = 0; int n = 0; int off = 0; int out = 0; int parts = 0;
    int raw = 0; int rowlen = 0; int w = 0; int x = 0; int y = 0; int z = 0; int ch = 0; int base = 0;
    w = img[0]; h = img[1]; ch = img[2];
    bc = prism_binio.byte_chars();
    # raw scanlines: filter byte 0 + RGB8. inlined (no per-row calls: function
    # arguments are deep-cloned in Emerald, so passing img per row is O(image))
    parts = []; chunk = "";
    rowlen = w * ch;
    for (y = 0; y < h; ++y) {
        chunk = chunk + char(0);
        base = y * rowlen;
        if (ch == 1) {
            for (i = 0; i < w; ++i) {
                x = img[3][base + i];
                if (x < 0.0) { x = 0.0; }
                if (x > 1.0) { x = 1.0; }
                k = x * 255.0 + 0.5;
                chunk = chunk + bc[k] + bc[k] + bc[k];
            }
        } else {
            for (i = 0; i < rowlen; ++i) {
                x = img[3][base + i];
                if (x < 0.0) { x = 0.0; }
                if (x > 1.0) { x = 1.0; }
                chunk = chunk + bc[x * 255.0 + 0.5];
            }
        }
        if (len(chunk) > 8192) { parts[len(parts)] = chunk; chunk = ""; }
    }
    parts[len(parts)] = chunk;
    raw = prism_binio.bjoin(parts);
    # zlib stream: 0x78 0x01 header, "stored" (uncompressed) deflate blocks, adler32
    adler = prism_binio.adler32(raw);
    z = "" + char(120) + char(1);
    n = len(raw); off = 0;
    while (off < n) {
        blocklen = n - off;
        if (blocklen > 60000) { blocklen = 60000; }
        bfinal = 0;
        if (off + blocklen >= n) { bfinal = 1; }
        z = z + char(bfinal) + prism_binio.u16le(blocklen) + prism_binio.u16le(65535 - blocklen)
              + raw.get(off, off + blocklen - 1);
        off = off + blocklen;
    }
    z = z + prism_binio.u32be(adler);
    ihdr = prism_binio.u32be(w) + prism_binio.u32be(h) + char(8) + char(2) + char(0) + char(0) + char(0);
    out = "" + char(137) + "PNG" + char(13) + char(10) + char(26) + char(10)
        + png_chunk("IHDR", ihdr)
        + png_chunk("IDAT", z)
        + png_chunk("IEND", "");
    return out;
}

fn save_png(img, path) {
    File f = path;
    f.write(png_bytes(img));
    return path;
}

fn save_ppm(img, path) {
    int bc = 0; int chunk = 0; int i = 0; int n = 0; int parts = 0; int v = 0; int ch = 0;
    File f = path;
    bc = prism_binio.byte_chars();
    ch = img[2];
    n = img[0] * img[1];
    parts = ["P6" + char(10) + "{img[0]} {img[1]}" + char(10) + "255" + char(10)];
    chunk = "";
    for (i = 0; i < n; ++i) {
        if (ch == 1) {
            v = img[3][i];
            if (v < 0.0) { v = 0.0; }
            if (v > 1.0) { v = 1.0; }
            v = v * 255.0 + 0.5;
            chunk = chunk + bc[v] + bc[v] + bc[v];
        } else {
            v = img[3][i * ch];
            if (v < 0.0) { v = 0.0; } if (v > 1.0) { v = 1.0; }
            chunk = chunk + bc[v * 255.0 + 0.5];
            v = img[3][i * ch + 1];
            if (v < 0.0) { v = 0.0; } if (v > 1.0) { v = 1.0; }
            chunk = chunk + bc[v * 255.0 + 0.5];
            v = img[3][i * ch + 2];
            if (v < 0.0) { v = 0.0; } if (v > 1.0) { v = 1.0; }
            chunk = chunk + bc[v * 255.0 + 0.5];
        }
        if (len(chunk) > 8192) { parts[len(parts)] = chunk; chunk = ""; }
    }
    parts[len(parts)] = chunk;
    f.write(prism_binio.bjoin(parts));
    return path;
}

# ---- BMP -------------------------------------------------------------------

fn save_bmp(img, path) {
    int fsize = 0; int h = 0; int i = 0; int pad = 0; int padstr = 0; int row = 0;
    int rowbytes = 0; int rows = 0; int w = 0; int y = 0; int hdr = 0; int r = 0; int g = 0; int b = 0; int x = 0;
    File f = path;
    w = img[0]; h = img[1];
    rowbytes = w * 3;
    pad = (4 - rowbytes % 4) % 4;
    padstr = "";
    for (i = 0; i < pad; ++i) { padstr = padstr + char(0); }
    rows = [];
    for (y = 0; y < h; ++y) {
        row = row_rgb8(img, h - 1 - y);      # BMP is bottom-up
        # swap RGB -> BGR
        b = "";
        for (x = 0; x < w; ++x) { b = b + row[x * 3 + 2] + row[x * 3 + 1] + row[x * 3]; }
        rows[y] = b + padstr;
    }
    fsize = 54 + (rowbytes + pad) * h;
    hdr = "BM" + prism_binio.u32le(fsize) + prism_binio.u32le(0) + prism_binio.u32le(54)
        + prism_binio.u32le(40) + prism_binio.u32le(w) + prism_binio.u32le(h)
        + prism_binio.u16le(1) + prism_binio.u16le(24) + prism_binio.u32le(0)
        + prism_binio.u32le((rowbytes + pad) * h) + prism_binio.u32le(2835) + prism_binio.u32le(2835)
        + prism_binio.u32le(0) + prism_binio.u32le(0);
    f.write(hdr + prism_binio.bjoin(rows));
    return path;
}

fn load_bmp(path) {
    int bpp = 0; int comp = 0; int d = 0; int dataoff = 0; int flip = 0; int h = 0; int i = 0;
    int img = 0; int pad = 0; int raw = 0; int rowbytes = 0; int srcy = 0; int step = 0;
    int w = 0; int x = 0; int y = 0; int p = 0; int hraw = 0;
    File f = path;
    raw = f.read();
    if (len(raw) < 54 || raw.get(0, 1) != "BM") { print("prism_imageio: '{path}' is not a BMP file"); return nil; }
    dataoff = prism_binio.rd_u32le(raw, 10);
    w = prism_binio.rd_u32le(raw, 18);
    hraw = prism_binio.rd_u32le(raw, 22);
    flip = 1; h = hraw;
    if (hraw >= 2147483648) { h = 4294967296 - hraw; flip = 0; }   # negative height = top-down
    bpp = prism_binio.rd_u16le(raw, 28);
    comp = prism_binio.rd_u32le(raw, 30);
    if (comp != 0 || (bpp != 24 && bpp != 32)) {
        print("prism_imageio: only uncompressed 24/32-bit BMP supported (got {bpp}bpp, compression {comp})");
        return nil;
    }
    step = bpp // 8;
    rowbytes = w * step;
    pad = (4 - rowbytes % 4) % 4;
    img = image.new_image(w, h, 3, 0.0);
    d = img[3];
    for (y = 0; y < h; ++y) {
        srcy = y;
        if (flip == 1) { srcy = h - 1 - y; }
        p = dataoff + srcy * (rowbytes + pad);
        for (x = 0; x < w; ++x) {
            i = (y * w + x) * 3;
            d[i]     = int(raw[p + x * step + 2]) / 255.0;
            d[i + 1] = int(raw[p + x * step + 1]) / 255.0;
            d[i + 2] = int(raw[p + x * step])     / 255.0;
        }
    }
    img[3] = d;
    return img;
}

# ---- PPM / PGM -------------------------------------------------------------

# read next ascii token from s starting at position pos[0], skipping
# whitespace and '#' comments; returns [token, newPos]
fn ppm_token(s, pos) {
    int c = 0; int n = 0; int p = 0; int t = 0;
    p = pos; n = len(s); t = "";
    while (p < n) {
        c = int(s[p]);
        if (c == 35) {                       # '#' comment to end of line
            while (p < n && int(s[p]) != 10) { p = p + 1; }
        }
        elif (c == 32 || c == 9 || c == 10 || c == 13) { p = p + 1; }
        else { break; }
    }
    while (p < n) {
        c = int(s[p]);
        if (c == 32 || c == 9 || c == 10 || c == 13 || c == 35) { break; }
        t = t + s[p]; p = p + 1;
    }
    return [t, p];
}

fn load_ppm(path) {
    int ch = 0; int d = 0; int h = 0; int i = 0; int img = 0; int magic = 0; int maxv = 0;
    int n = 0; int p = 0; int raw = 0; int tk = 0; int w = 0; int binmode = 0; int total = 0;
    File f = path;
    raw = f.read();
    tk = ppm_token(raw, 0); magic = tk[0]; p = tk[1];
    if (magic != "P2" && magic != "P3" && magic != "P5" && magic != "P6") {
        print("prism_imageio: '{path}' is not a P2/P3/P5/P6 PPM/PGM"); return nil;
    }
    ch = 3;
    if (magic == "P2" || magic == "P5") { ch = 1; }
    binmode = 0;
    if (magic == "P5" || magic == "P6") { binmode = 1; }
    tk = ppm_token(raw, p); w = int(tk[0]); p = tk[1];
    tk = ppm_token(raw, p); h = int(tk[0]); p = tk[1];
    tk = ppm_token(raw, p); maxv = int(tk[0]); p = tk[1];
    if (maxv < 1) { maxv = 255; }
    img = image.new_image(w, h, ch, 0.0);
    d = img[3];
    total = w * h * ch;
    if (binmode == 1) {
        p = p + 1;                            # single whitespace after maxval
        for (i = 0; i < total; ++i) { d[i] = int(raw[p + i]) / float(maxv); }
    } else {
        for (i = 0; i < total; ++i) {
            tk = ppm_token(raw, p); p = tk[1];
            d[i] = int(tk[0]) / float(maxv);
        }
    }
    img[3] = d;
    return img;
}

# ---- dispatcher ------------------------------------------------------------

fn load_any(path) {
    int head = 0; int raw = 0;
    File f = path;
    raw = f.read(7);
    if (len(raw) < 2) { print("prism_imageio: '{path}' is empty or unreadable"); return nil; }
    head = raw.get(0, 1);
    if (head == "BM") { return load_bmp(path); }
    if (head == "P2" || head == "P3" || head == "P5" || head == "P6") { return load_ppm(path); }
    if (int(raw[0]) == 137 && head[1] == 'P') {
        print("prism_imageio: '{path}' is a PNG. Prism writes PNG but does not");
        print("  decode it (no inflate). Convert the input once, e.g.:");
        print("    magick {path} input.bmp     (or export as BMP / PPM)");
        return nil;
    }
    if (int(raw[0]) == 255 && int(raw[1]) == 216) {
        print("prism_imageio: '{path}' is a JPEG. Convert to BMP or PPM first, e.g.:");
        print("    magick {path} input.bmp");
        return nil;
    }
    print("prism_imageio: unrecognised image format in '{path}' (use BMP, PPM, or PGM)");
    return nil;
}
