# run from package root: emerald tests/test_binio.em
import prism_binio;

fn hex_of(s) {
    int d = 0; int i = 0; int o = 0; int v = 0;
    d = "0123456789abcdef"; o = "";
    for (i = 0; i < len(s); ++i) {
        v = int(s[i]);
        o = o + d[v // 16] + d[v % 16] + " ";
    }
    return o;
}

fn expect(label, got, want) {
    if (got == want) { print("  ok   {label}"); }
    else { print("  FAIL {label}: got {got} want {want}"); }
}

expect("u16le", hex_of(prism_binio.u16le(4660)), "34 12 ");
expect("u32le", hex_of(prism_binio.u32le(305419896)), "78 56 34 12 ");
expect("u32be", hex_of(prism_binio.u32be(305419896)), "12 34 56 78 ");
expect("i32le(-2)", hex_of(prism_binio.i32le(0 - 2)), "fe ff ff ff ");
expect("i64le(-1)", hex_of(prism_binio.i64le(0 - 1)), "ff ff ff ff ff ff ff ff ");
expect("u64le", hex_of(prism_binio.u64le(1311768467463790320)), "f0 de bc 9a 78 56 34 12 ");

# IEEE-754 doubles - reference bit patterns
expect("f64 1.0",    hex_of(prism_binio.f64le(1.0)),   "00 00 00 00 00 00 f0 3f ");
expect("f64 -2.0",   hex_of(prism_binio.f64le(0.0 - 2.0)), "00 00 00 00 00 00 00 c0 ");
expect("f64 0.5",    hex_of(prism_binio.f64le(0.5)),   "00 00 00 00 00 00 e0 3f ");
expect("f64 3.14...", hex_of(prism_binio.f64le(3.141592653589793)), "18 2d 44 54 fb 21 09 40 ");
expect("f64 0.1",    hex_of(prism_binio.f64le(0.1)),   "9a 99 99 99 99 99 b9 3f ");
expect("f64 0",      hex_of(prism_binio.f64le(0.0)),   "00 00 00 00 00 00 00 00 ");
expect("f32 1.0",    hex_of(prism_binio.f32le(1.0)),   "00 00 80 3f ");
expect("f32 -0.5",   hex_of(prism_binio.f32le(0.0 - 0.5)), "00 00 00 bf ");
expect("f32 3.14",   hex_of(prism_binio.f32le(3.14)),  "c3 f5 48 40 ");

# checksums - classic reference values
expect("crc32 empty", prism_binio.crc32(""), 0);
expect("crc32 '123456789'", prism_binio.crc32("123456789"), 3421780262);
expect("crc32 'IEND'", prism_binio.crc32("IEND"), 2923585666);
expect("adler32 'Wikipedia'", prism_binio.adler32("Wikipedia"), 300286872);
print("binio done");
