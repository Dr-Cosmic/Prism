import prism_prims; import mesh; import texture;

fn expect(label, cond) { if (cond) { print("  ok   {label}"); } else { print("  FAIL {label}"); } }

cyl = prism_prims.capped_cylinder(1.0, 2.0, 12);
expect("cylinder verts", mesh.vertex_count(cyl) == 13*2 + 2*(12+2));
# outward normal on wall: vertex 0 at angle 0 -> pos (1,-1,0), normal should be (+1,0,0)
n0 = mesh.get_normal(cyl, 0);
expect("cyl wall normal outward", n0[0] > 0.99);
co = prism_prims.cone(1.0, 2.0, 8);
expect("cone has faces", mesh.face_count(co) == 8 + 8);   # wall tris + base fan
g = prism_prims.gem(1.0, 1.6, 7);
expect("gem faces", mesh.face_count(g) > 20);
star = [];
for (i = 0; i < 10; ++i) {
    r = 1.0; if (i % 2 == 1) { r = 0.45; }
    a = 3.14159265 * 2.0 * i / 10.0 + 3.14159265/2.0;
    star = star + [r * cos(a), r * sin(a)];
}
tris = prism_prims.earclip(star);
expect("earclip star 8 tris", len(tris) == 8 * 3);
ex = prism_prims.extrude(star, 0.4);
expect("extrude counts", mesh.face_count(ex) == 8*2 + 10*2);
b = mesh.bounds(ex);
expect("extrude depth", abs((b[1][2]-b[0][2]) - 0.4) < 0.0001);
# clockwise input handled
cw = [0.0,0.0, 0.0,1.0, 1.0,1.0, 1.0,0.0];
ex2 = prism_prims.extrude(cw, 0.2);
expect("cw square extrude", mesh.face_count(ex2) == 2*2 + 4*2);
him = texture.value_noise(16, 16, 4.0, 3, 5);
t = prism_prims.terrain(him, 4.0, 1.0, 10);
expect("terrain verts", mesh.vertex_count(t) == 121);
ds = prism_prims.displaced_sphere(1.0, 2, 0.3, 1.5, 3);
expect("displaced sphere", mesh.vertex_count(ds) == 162);
nrm = prism_prims.normalize_size(prism_prims.recenter_ground(ds), 2.0);
bb = mesh.bounds(nrm);
mx = bb[1][0]-bb[0][0];
if (bb[1][1]-bb[0][1] > mx) { mx = bb[1][1]-bb[0][1]; }
if (bb[1][2]-bb[0][2] > mx) { mx = bb[1][2]-bb[0][2]; }
expect("normalized ground", abs(bb[0][1]) < 0.0001 && abs(mx - 2.0) < 0.001);
print("prims done");
