import image;
import prism_imageio;
img = image.new_image(32, 24, 3, 0.0);
d = img[3];
for (y = 0; y < 24; ++y) {
    for (x = 0; x < 32; ++x) {
        i = (y * 32 + x) * 3;
        d[i] = x / 31.0; d[i+1] = y / 23.0; d[i+2] = 0.25;
        if (x == 5 && y == 5) { d[i] = 1.0; d[i+1] = 0.0; d[i+2] = 0.0; }
    }
}
img[3] = d;
prism_imageio.save_png(img, "tests/out/grad.png");
prism_imageio.save_bmp(img, "tests/out/grad.bmp");
back = prism_imageio.load_bmp("tests/out/grad.bmp");
print("bmp roundtrip w={back[0]} h={back[1]} px(5,5)=", image.get_px(back,5,5,0), " ", image.get_px(back,5,5,1));
prism_imageio.save_ppm(img, "tests/out/grad.p6.ppm");
p6 = prism_imageio.load_ppm("tests/out/grad.p6.ppm");
okppm = p6 != nil && p6[0] == img[0] && p6[1] == img[1];
d0 = image.get_px(p6, 5, 5, 0) - image.get_px(img, 5, 5, 0);
if (d0 < 0) { d0 = 0.0 - d0; }
if (okppm && d0 < 0.01) { print("  ok   ppm roundtrip"); }
else { print("  FAIL ppm roundtrip"); }
print("done");
