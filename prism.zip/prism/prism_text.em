# prism_text - turns a text prompt into a generation spec.
#
# Rule-based natural-language parsing built on emeraldx `nlp` (tokenizer +
# Porter stemmer). No external services: the vocabulary below IS the model.
#
#   parse(prompt, seed)  ->  GenSpec
#
# Heuristics worth knowing:
#   * the LAST shape word wins ("stone castle" -> castle); an earlier word
#     that can be both a shape and a material ("stone") becomes the material
#   * "light"/"dark" modify the next color word
#   * counts: "two".."nine", digits, "pair", "few", "several"; "forest"
#     means several trees
#   * unknown nouns fall back to the "abstract" sculpture recipe
# emx-scope-safe

import nlp;
import strx;
import prism_binio;
import prism_types;

GenSpec = prism_types.GenSpec;   # re-export (defined import-free, see prism_types)

fn shape_lexicon() {
    # stem -> recipe key
    return [
        ["cube", "cube"], ["box", "cube"], ["block", "cube"],
        ["sphere", "sphere"], ["ball", "sphere"], ["orb", "sphere"],
        ["cylind", "cylinder"], ["tube", "cylinder"], ["pillar", "cylinder"], ["column", "cylinder"],
        ["cone", "cone"], ["pyramid", "pyramid"],
        ["toru", "torus"], ["donut", "torus"], ["doughnut", "torus"], ["ring", "ring"],
        ["gem", "gem"], ["diamond", "gem"], ["jewel", "gem"], ["crystal", "crystal_shape"], ["emerald", "crystal_shape"],
        ["hous", "house"], ["cottag", "house"], ["home", "house"], ["cabin", "house"], ["hut", "house"],
        ["tower", "tower"], ["turret", "tower"], ["lighthous", "tower"],
        ["castl", "castle"], ["fort", "castle"], ["fortress", "castle"],
        ["tree", "tree"], ["oak", "tree"],
        ["pine", "pine"], ["fir", "pine"], ["spruce", "pine"], ["conif", "pine"], ["christma", "pine"],
        ["forest", "forest"], ["grove", "forest"],
        ["rock", "rock"], ["stone", "rock"], ["boulder", "rock"], ["asteroid", "rock"], ["meteor", "rock"],
        ["mountain", "mountain"], ["hill", "mountain"], ["peak", "mountain"], ["volcano", "volcano"],
        ["terrain", "terrain"], ["landscap", "terrain"], ["island", "terrain"],
        ["planet", "planet"], ["world", "planet"], ["moon", "moon"],
        ["rocket", "rocket"], ["missil", "rocket"], ["spaceship", "rocket"], ["ship", "boat"],
        ["boat", "boat"], ["sail", "boat"], ["sailboat", "boat"],
        ["car", "car"], ["vehicl", "car"], ["truck", "car"],
        ["tabl", "table"], ["desk", "table"],
        ["chair", "chair"], ["stool", "chair"], ["seat", "chair"],
        ["mug", "mug"], ["cup", "mug"],
        ["bottl", "bottle"], ["flask", "bottle"],
        ["vase", "vase"], ["pot", "vase"], ["urn", "vase"], ["amphora", "vase"],
        ["lamp", "lamp"], ["lantern", "lamp"],
        ["sword", "sword"], ["blade", "sword"], ["dagger", "sword"],
        ["shield", "shield"],
        ["snowman", "snowman"],
        ["robot", "robot"], ["android", "robot"], ["bot", "robot"],
        ["mushroom", "mushroom"], ["toadstool", "mushroom"],
        ["barrel", "barrel"], ["keg", "barrel"],
        ["coin", "coin"], ["medal", "coin"],
        ["dice", "dice"], ["die", "dice"],
        ["crown", "crown"], ["tiara", "crown"],
        ["pawn", "pawn"], ["chess", "pawn"],
        ["heart", "heart"],
        ["star", "star"],
        ["gear", "gear"], ["cog", "gear"],
        ["arrow", "arrow"],
        ["tent", "tent"],
        ["bridg", "bridge"],
        ["well", "well"],
        ["candl", "candle"],
        ["rockingchair", "chair"]
    ];
}

fn material_lexicon() {
    return [
        ["wood", "wood"], ["wooden", "wood"], ["oak", "wood"], ["timber", "wood"], ["plank", "wood"],
        ["stone", "stone"], ["rock", "stone"], ["rocki", "stone"], ["granit", "stone"],
        ["brick", "brick"],
        ["metal", "metal"], ["steel", "metal"], ["iron", "metal"], ["silver", "metal"], ["chrome", "metal"], ["metall", "metal"],
        ["gold", "gold"], ["golden", "gold"], ["brass", "gold"], ["bronz", "gold"],
        ["marbl", "marble"],
        ["glass", "glass"], ["ice", "glass"], ["ici", "glass"], ["frozen", "glass"],
        ["crystal", "crystal"], ["emerald", "crystal"],
        ["rust", "rust"], ["rusti", "rust"], ["corrod", "rust"],
        ["snow", "snow"], ["snowi", "snow"],
        ["sand", "sand"], ["sandi", "sand"], ["desert", "sand"],
        ["lava", "lava"], ["molten", "lava"], ["magma", "lava"],
        ["water", "water"], ["ocean", "water"],
        ["grass", "grass"], ["grassi", "grass"], ["mossi", "grass"], ["moss", "grass"],
        ["fabric", "fabric"], ["cloth", "fabric"], ["velvet", "fabric"], ["woven", "fabric"],
        ["checker", "checker"], ["check", "checker"], ["chess", "checker"],
        ["bark", "bark"],
        ["lego", "plain"], ["plastic", "plain"]
    ];
}

fn color_lexicon() {
    return [
        ["red", [0.80, 0.12, 0.10]],
        ["orang", [0.92, 0.48, 0.10]],
        ["yellow", [0.95, 0.83, 0.15]],
        ["green", [0.15, 0.55, 0.18]],
        ["blue", [0.15, 0.32, 0.75]],
        ["purpl", [0.48, 0.18, 0.62]],
        ["violet", [0.52, 0.25, 0.72]],
        ["pink", [0.94, 0.48, 0.66]],
        ["magenta", [0.85, 0.15, 0.65]],
        ["cyan", [0.10, 0.70, 0.75]],
        ["teal", [0.08, 0.50, 0.50]],
        ["turquois", [0.15, 0.68, 0.62]],
        ["brown", [0.44, 0.28, 0.14]],
        ["tan", [0.75, 0.62, 0.42]],
        ["beig", [0.83, 0.76, 0.62]],
        ["white", [0.93, 0.93, 0.93]],
        ["black", [0.08, 0.08, 0.09]],
        ["gray", [0.50, 0.50, 0.52]],
        ["grey", [0.50, 0.50, 0.52]],
        ["gold", [0.85, 0.65, 0.15]],
        ["silver", [0.72, 0.74, 0.78]],
        ["crimson", [0.70, 0.05, 0.15]],
        ["scarlet", [0.85, 0.10, 0.10]],
        ["navi", [0.08, 0.12, 0.38]],
        ["lime", [0.55, 0.85, 0.15]],
        ["olive", [0.42, 0.45, 0.15]],
        ["maroon", [0.42, 0.08, 0.10]],
        ["coral", [0.95, 0.45, 0.35]],
        ["lavend", [0.68, 0.58, 0.85]],
        ["mint", [0.55, 0.85, 0.68]],
        ["salmon", [0.95, 0.55, 0.48]],
        ["indigo", [0.25, 0.12, 0.55]],
        ["amber", [0.90, 0.62, 0.10]],
        ["ivori", [0.95, 0.93, 0.85]],
        ["charcoal", [0.18, 0.19, 0.20]],
        ["emerald", [0.06, 0.55, 0.38]]
    ];
}

fn lookup(table, key) {
    int i = 0;
    for (i = 0; i < len(table); ++i) {
        if (table[i][0] == key) { return table[i][1]; }
    }
    return nil;
}

fn number_word(w) {
    if (w == "two" || w == "coupl" || w == "pair") { return 2; }
    if (w == "three" || w == "few") { return 3; }
    if (w == "four" || w == "sever") { return 4; }
    if (w == "five") { return 5; }
    if (w == "six") { return 6; }
    if (w == "seven") { return 7; }
    if (w == "eight") { return 8; }
    if (w == "nine") { return 9; }
    return 0;
}

fn parse(prompt, seed) {
    int c = 0; int col = 0; int i = 0; int lightMod = 0; int mat = 0; int n = 0;
    int sh = 0; int shapes = 0; int spec = 0; int stem = 0; int t = 0; int toks = 0; int w = 0;
    int mats = 0; int cols = 0; int prevShapeStem = 0; int darkMod = 0; int num = 0;
    spec = GenSpec;
    if (seed != nil) { spec.seed = seed; }
    else { spec.seed = 1 + prism_binio.crc32(prompt) % 100000; }
    shapes = shape_lexicon();
    mats = material_lexicon();
    cols = color_lexicon();
    toks = nlp.tokenize(strx.to_lower(prompt));
    lightMod = false; darkMod = false;
    prevShapeStem = "";
    for (i = 0; i < len(toks); ++i) {
        w = toks[i];
        stem = nlp.porter_stem(w);
        # counts
        num = number_word(stem);
        if (num == 0 && len(w) == 1 && w[0] >= '2' && w[0] <= '9') { num = int(w); }
        if (num > 0) { spec.count = num; continue; }
        # sizes / proportions / style
        if (stem == "tini" || stem == "small" || stem == "littl" || stem == "mini") { spec.size = 0.6; continue; }
        if (stem == "big" || stem == "larg") { spec.size = 1.4; continue; }
        if (stem == "huge" || stem == "giant" || stem == "massiv" || stem == "enorm") { spec.size = 1.9; continue; }
        if (stem == "tall" || stem == "high") { spec.tallness = 1.5; continue; }
        if (stem == "short" || stem == "squat") { spec.tallness = 0.65; continue; }
        if (stem == "wide" || stem == "fat" || stem == "thick" || stem == "chunki") { spec.wideness = 1.5; continue; }
        if (stem == "thin" || stem == "narrow" || stem == "slim" || stem == "skinni") { spec.wideness = 0.7; continue; }
        if (stem == "lowpoli" || stem == "facet" || (stem == "low" && i + 1 < len(toks) && nlp.porter_stem(toks[i+1]) == "poli")) { spec.style = "lowpoly"; continue; }
        if (stem == "poli") { continue; }
        if (stem == "smooth" || stem == "round") { spec.style = "smooth"; continue; }
        if (stem == "light" || stem == "pale" || stem == "bright") { lightMod = true; continue; }
        if (stem == "dark" || stem == "deep") { darkMod = true; continue; }
        # image-mode hints
        if (stem == "heightmap" || stem == "terrain" || stem == "landscap" || stem == "eleve") { spec.imageMode = "terrain"; }
        if (stem == "extrud" || stem == "cutout" || stem == "logo" || stem == "sign" || stem == "cooki" || stem == "silhouett") { spec.imageMode = "extrude"; }
        if (stem == "lath" || stem == "revolv" || stem == "spin" || stem == "spun") { spec.imageMode = "lathe"; }
        # colors
        col = lookup(cols, stem);
        if (col != nil) {
            c = col;
            if (lightMod) { c = [c[0] + (1.0 - c[0]) * 0.45, c[1] + (1.0 - c[1]) * 0.45, c[2] + (1.0 - c[2]) * 0.45]; }
            if (darkMod) { c = [c[0] * 0.45, c[1] * 0.45, c[2] * 0.45]; }
            lightMod = false; darkMod = false;
            spec.color = c;
            spec.colorName = w;
            # a color word may also be a material hint (gold, emerald, silver)
            mat = lookup(mats, stem);
            if (mat != nil && spec.texKind == "") { spec.texKind = mat; }
            continue;
        }
        # shapes (last shape wins; a displaced older shape word that is also
        # a material becomes the material, e.g. "stone castle")
        sh = lookup(shapes, stem);
        if (sh != nil) {
            # don't let a generic word undo a specialization ("pine tree")
            if (sh == "tree" && spec.shape == "pine") { continue; }
            if (sh == "rock" && (spec.shape == "mountain" || spec.shape == "volcano")) { continue; }
            if (sh == "cube" && spec.shape != "abstract") { continue; }
            if (spec.shape != "abstract" && prevShapeStem != "") {
                mat = lookup(mats, prevShapeStem);
                if (mat != nil && spec.texKind == "") { spec.texKind = mat; }
            }
            spec.shape = sh;
            spec.noun = w;
            prevShapeStem = stem;
            continue;
        }
        # materials
        mat = lookup(mats, stem);
        if (mat != nil) { spec.texKind = mat; continue; }
        # unknown noun-ish word: remember for naming if nothing found yet
        if (spec.noun == "" && len(w) > 2) { spec.noun = w; }
    }
    if (spec.shape == "forest") { spec.shape = "tree"; if (spec.count < 2) { spec.count = 6; } }
    return spec;
}
