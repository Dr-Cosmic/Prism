# prism_fbx - binary FBX 7.4 writer (no external tooling, pure Emerald).
#
# Writes a self-contained Kaydara binary FBX: one mesh, one phong material,
# one texture with the PNG bytes EMBEDDED in the file (Video/Content), so the
# .fbx alone can be dropped into Blender/Unity/assimp and keep its texture.
#
# Format notes (32-bit record layout used by FBX <= 7.4):
#   node record  = u32 EndOffset (absolute) | u32 NumProperties |
#                  u32 PropertyListLen | u8 NameLen | Name |
#                  properties | children | 13-byte NULL sentinel
#   sentinel     = written when a node has children, or has no properties
#   property     = 1 type char + payload:
#     S/R  u32 len + bytes          I i32   L i64   D f64   C u8
#     d/i  u32 count + u32 encoding(0=raw) + u32 byteLen + raw payload
#   two-part names ("Model::prism") are stored reversed with a \x00\x01
#   separator: "prism" 00 01 "Model".
#   footer = 16-byte code + 4 zeros + pad-to-16 (16 if already aligned)
#            + u32 version + 120 zeros + 16-byte magic.
#
#   write_fbx(m, path, base, texRelName, pngBytes)
# emx-scope-safe

import prism_binio;
import prng;

# ---- property encoders -------------------------------------------------------

fn pS(s)  { return "S" + prism_binio.u32le(len(s)) + s; }
fn pName(name, cls) { return pS(name + char(0) + char(1) + cls); }
fn pI(v)  { return "I" + prism_binio.i32le(v); }
fn pL(v)  { return "L" + prism_binio.i64le(v); }
fn pD(v)  { return "D" + prism_binio.f64le(v); }
fn pC(v)  { int b = 0; b = 0; if (v) { b = 1; } return "C" + char(b); }
fn pR(bytes) { return "R" + prism_binio.u32le(len(bytes)) + bytes; }

fn enc_f64_array(a) {
    int chunk = 0; int i = 0; int n = 0; int out = 0; int parts = 0;
    n = len(a);
    parts = []; chunk = "";
    for (i = 0; i < n; ++i) {
        chunk = chunk + prism_binio.f64le(a[i]);
        if (len(chunk) > 8192) { parts[len(parts)] = chunk; chunk = ""; }
    }
    parts[len(parts)] = chunk;
    out = "";
    for (i = 0; i < len(parts); ++i) { out = out + parts[i]; }
    return "d" + prism_binio.u32le(n) + prism_binio.u32le(0) + prism_binio.u32le(n * 8) + out;
}

fn enc_i32_array(a) {
    int chunk = 0; int i = 0; int n = 0; int out = 0; int parts = 0;
    n = len(a);
    parts = []; chunk = "";
    for (i = 0; i < n; ++i) {
        chunk = chunk + prism_binio.i32le(a[i]);
        if (len(chunk) > 8192) { parts[len(parts)] = chunk; chunk = ""; }
    }
    parts[len(parts)] = chunk;
    out = "";
    for (i = 0; i < len(parts); ++i) { out = out + parts[i]; }
    return "i" + prism_binio.u32le(n) + prism_binio.u32le(0) + prism_binio.u32le(n * 4) + out;
}

# ---- node tree ----------------------------------------------------------------

fn nd(name, props, children) {
    int c = 0; int p = 0;
    p = props; c = children;
    if (p == nil) { p = []; }
    if (c == nil) { c = []; }
    return [name, p, c];
}

fn props_len(node) {
    int i = 0; int t = 0;
    t = 0;
    for (i = 0; i < len(node[1]); ++i) { t = t + len(node[1][i]); }
    return t;
}

fn has_sentinel(node) {
    if (len(node[2]) > 0) { return true; }
    if (len(node[1]) == 0) { return true; }
    return false;
}

fn node_size(node) {
    int i = 0; int t = 0;
    t = 13 + len(node[0]) + props_len(node);
    for (i = 0; i < len(node[2]); ++i) { t = t + node_size(node[2][i]); }
    if (has_sentinel(node)) { t = t + 13; }
    return t;
}

fn emit_node(node, ofs) {
    int body = 0; int c = 0; int childOfs = 0; int i = 0; int out = 0; int pl = 0;
    pl = props_len(node);
    out = prism_binio.u32le(ofs + node_size(node))
        + prism_binio.u32le(len(node[1]))
        + prism_binio.u32le(pl)
        + char(len(node[0]))
        + node[0];
    for (i = 0; i < len(node[1]); ++i) { out = out + node[1][i]; }
    childOfs = ofs + 13 + len(node[0]) + pl;
    for (i = 0; i < len(node[2]); ++i) {
        c = emit_node(node[2][i], childOfs);
        childOfs = childOfs + len(c);
        out = out + c;
    }
    if (has_sentinel(node)) { out = out + prism_binio.zero_bytes(13); }
    return out;
}

# ---- Properties70 helpers ------------------------------------------------------

fn p70_int(name, v) {
    return nd("P", [pS(name), pS("int"), pS("Integer"), pS(""), pI(v)], []);
}
fn p70_dbl(name, v) {
    return nd("P", [pS(name), pS("double"), pS("Number"), pS(""), pD(v)], []);
}
fn p70_color(name, r, g, b) {
    return nd("P", [pS(name), pS("Color"), pS(""), pS("A"), pD(r), pD(g), pD(b)], []);
}
fn p70_str(name, typ, lbl, v) {
    return nd("P", [pS(name), pS(typ), pS(lbl), pS(""), pS(v)], []);
}

# ---- scene assembly ------------------------------------------------------------

fn new_id(st) {
    int r = 0;
    r = prng.randint(st, 1000000, 4000000000000000);
    return [r[0], r[1]];
}

# expand mesh to per-polygon-vertex normals; UVs stay indexed (IndexToDirect)
fn write_fbx(m, path, base, texRelName, pngBytes) {
    int conns = 0; int defs = 0; int docs = 0; int faces = 0; int fi = 0; int geom = 0;
    int geomId = 0; int gs = 0; int hdr = 0; int i = 0; int ids = 0; int layer = 0;
    int lem = 0; int leuv = 0; int matId = 0; int material = 0;
    int model = 0; int modelId = 0; int nf = 0; int normals = 0; int nrmPV = 0; int nv = 0;
    int ofs = 0; int out = 0; int pad = 0; int parts = 0; int positions = 0; int pvi = 0;
    int refs = 0; int root = 0; int st = 0; int texId = 0; int texture2 = 0; int uvIdx = 0;
    int uvs = 0; int video = 0; int vidId = 0; int a = 0; int b = 0; int c = 0; int hx = 0;
    positions = m[0]; normals = m[1]; uvs = m[2]; faces = m[3];
    nv = len(positions) // 3;
    nf = len(faces) // 3;
    st = prng.seed_from(len(positions) * 7 + nf * 13 + 91);
    ids = new_id(st); geomId = ids[0]; st = ids[1];
    ids = new_id(st); modelId = ids[0]; st = ids[1];
    ids = new_id(st); matId = ids[0]; st = ids[1];
    ids = new_id(st); texId = ids[0]; st = ids[1];
    ids = new_id(st); vidId = ids[0]; st = ids[1];
    # polygon vertex index: last of each triangle is bitwise-NOT = -(i+1)
    pvi = [];
    for (fi = 0; fi < nf; ++fi) {
        a = faces[fi * 3]; b = faces[fi * 3 + 1]; c = faces[fi * 3 + 2];
        pvi[fi * 3] = a;
        pvi[fi * 3 + 1] = b;
        pvi[fi * 3 + 2] = 0 - (c + 1);
    }
    # per-polygon-vertex normals (ByPolygonVertex / Direct)
    nrmPV = [];
    for (fi = 0; fi < nf * 3; ++fi) {
        i = faces[fi];
        nrmPV[fi * 3] = normals[i * 3];
        nrmPV[fi * 3 + 1] = normals[i * 3 + 1];
        nrmPV[fi * 3 + 2] = normals[i * 3 + 2];
    }
    # UV: IndexToDirect over the vertex uv table (flip V for FBX)
    uvIdx = [];
    for (fi = 0; fi < nf * 3; ++fi) { uvIdx[fi] = faces[fi]; }
    a = [];
    for (i = 0; i < nv; ++i) {
        a[i * 2] = uvs[i * 2];
        a[i * 2 + 1] = 1.0 - uvs[i * 2 + 1];
    }
    hdr = nd("FBXHeaderExtension", [], [
        nd("FBXHeaderVersion", [pI(1003)], []),
        nd("FBXVersion", [pI(7400)], []),
        nd("Creator", [pS("Prism procedural generator (Emerald)")], []),
        nd("CreationTimeStamp", [], [
            nd("Version", [pI(1000)], []),
            nd("Year", [pI(2026)], []), nd("Month", [pI(1)], []), nd("Day", [pI(1)], []),
            nd("Hour", [pI(0)], []), nd("Minute", [pI(0)], []), nd("Second", [pI(0)], []),
            nd("Millisecond", [pI(0)], [])
        ])
    ]);
    gs = nd("GlobalSettings", [], [
        nd("Version", [pI(1000)], []),
        nd("Properties70", [], [
            p70_int("UpAxis", 1), p70_int("UpAxisSign", 1),
            p70_int("FrontAxis", 2), p70_int("FrontAxisSign", 1),
            p70_int("CoordAxis", 0), p70_int("CoordAxisSign", 1),
            p70_int("OriginalUpAxis", 1), p70_int("OriginalUpAxisSign", 1),
            p70_dbl("UnitScaleFactor", 1.0),
            p70_dbl("OriginalUnitScaleFactor", 1.0)
        ])
    ]);
    docs = nd("Documents", [], [
        nd("Count", [pI(1)], []),
        nd("Document", [pL(999888777), pS("Scene"), pS("Scene")], [
            nd("RootNode", [pL(0)], [])
        ])
    ]);
    refs = nd("References", [], []);
    defs = nd("Definitions", [], [
        nd("Version", [pI(100)], []),
        nd("Count", [pI(5)], []),
        nd("ObjectType", [pS("GlobalSettings")], [nd("Count", [pI(1)], [])]),
        nd("ObjectType", [pS("Model")], [nd("Count", [pI(1)], [])]),
        nd("ObjectType", [pS("Geometry")], [nd("Count", [pI(1)], [])]),
        nd("ObjectType", [pS("Material")], [nd("Count", [pI(1)], [])]),
        nd("ObjectType", [pS("Texture")], [nd("Count", [pI(1)], [])]),
        nd("ObjectType", [pS("Video")], [nd("Count", [pI(1)], [])])
    ]);
    lem = nd("LayerElementNormal", [pI(0)], [
        nd("Version", [pI(101)], []),
        nd("Name", [pS("")], []),
        nd("MappingInformationType", [pS("ByPolygonVertex")], []),
        nd("ReferenceInformationType", [pS("Direct")], []),
        nd("Normals", [enc_f64_array(nrmPV)], [])
    ]);
    leuv = nd("LayerElementUV", [pI(0)], [
        nd("Version", [pI(101)], []),
        nd("Name", [pS("UVMap")], []),
        nd("MappingInformationType", [pS("ByPolygonVertex")], []),
        nd("ReferenceInformationType", [pS("IndexToDirect")], []),
        nd("UV", [enc_f64_array(a)], []),
        nd("UVIndex", [enc_i32_array(uvIdx)], [])
    ]);
    layer = nd("Layer", [pI(0)], [
        nd("Version", [pI(100)], []),
        nd("LayerElement", [], [
            nd("Type", [pS("LayerElementNormal")], []),
            nd("TypedIndex", [pI(0)], [])
        ]),
        nd("LayerElement", [], [
            nd("Type", [pS("LayerElementMaterial")], []),
            nd("TypedIndex", [pI(0)], [])
        ]),
        nd("LayerElement", [], [
            nd("Type", [pS("LayerElementUV")], []),
            nd("TypedIndex", [pI(0)], [])
        ])
    ]);
    geom = nd("Geometry", [pL(geomId), pName(base, "Geometry"), pS("Mesh")], [
        nd("Vertices", [enc_f64_array(positions)], []),
        nd("PolygonVertexIndex", [enc_i32_array(pvi)], []),
        nd("GeometryVersion", [pI(124)], []),
        lem,
        nd("LayerElementMaterial", [pI(0)], [
            nd("Version", [pI(101)], []),
            nd("Name", [pS("")], []),
            nd("MappingInformationType", [pS("AllSame")], []),
            nd("ReferenceInformationType", [pS("IndexToDirect")], []),
            nd("Materials", [enc_i32_array([0])], [])
        ]),
        leuv,
        layer
    ]);
    model = nd("Model", [pL(modelId), pName(base, "Model"), pS("Mesh")], [
        nd("Version", [pI(232)], []),
        nd("Shading", [pC(true)], []),
        nd("Culling", [pS("CullingOff")], [])
    ]);
    material = nd("Material", [pL(matId), pName(base + "_mat", "Material"), pS("")], [
        nd("Version", [pI(102)], []),
        nd("ShadingModel", [pS("phong")], []),
        nd("MultiLayer", [pI(0)], []),
        nd("Properties70", [], [
            p70_color("DiffuseColor", 0.8, 0.8, 0.8),
            p70_color("AmbientColor", 0.1, 0.1, 0.1),
            p70_color("SpecularColor", 0.15, 0.15, 0.15),
            p70_dbl("Shininess", 12.0),
            p70_dbl("ShininessExponent", 12.0),
            p70_dbl("Opacity", 1.0)
        ])
    ]);
    texture2 = nd("Texture", [pL(texId), pName(base + "_tex", "Texture"), pS("TextureVideoClip")], [
        nd("Type", [pS("TextureVideoClip")], []),
        nd("Version", [pI(202)], []),
        nd("TextureName", [pS(base + "_tex" + char(0) + char(1) + "Texture")], []),
        nd("Media", [pS(base + "_vid" + char(0) + char(1) + "Video")], []),
        nd("FileName", [pS(texRelName)], []),
        nd("RelativeFilename", [pS(texRelName)], []),
        nd("Properties70", [], [
            p70_str("UVSet", "KString", "", "UVMap"),
            p70_int("UseMaterial", 1)
        ])
    ]);
    video = nd("Video", [pL(vidId), pName(base + "_vid", "Video"), pS("Clip")], [
        nd("Type", [pS("Clip")], []),
        nd("Properties70", [], [
            p70_str("Path", "KString", "XRefUrl", texRelName)
        ]),
        nd("UseMipMap", [pI(0)], []),
        nd("Filename", [pS(texRelName)], []),
        nd("RelativeFilename", [pS(texRelName)], []),
        nd("Content", [pR(pngBytes)], [])
    ]);
    conns = nd("Connections", [], [
        nd("C", [pS("OO"), pL(geomId), pL(modelId)], []),
        nd("C", [pS("OO"), pL(modelId), pL(0)], []),
        nd("C", [pS("OO"), pL(matId), pL(modelId)], []),
        nd("C", [pS("OP"), pL(texId), pL(matId), pS("DiffuseColor")], []),
        nd("C", [pS("OO"), pL(vidId), pL(texId)], [])
    ]);
    root = [hdr, gs, docs, refs, defs,
            nd("Objects", [], [geom, model, material, texture2, video]),
            conns];
    out = "Kaydara FBX Binary  " + char(0) + char(26) + char(0) + prism_binio.u32le(7400);
    ofs = len(out);
    for (i = 0; i < len(root); ++i) {
        hx = emit_node(root[i], ofs);
        ofs = ofs + len(hx);
        out = out + hx;
    }
    out = out + prism_binio.zero_bytes(13);
    out = out + char(250) + char(188) + char(171) + char(9) + char(208) + char(200)
              + char(212) + char(102) + char(177) + char(118) + char(251) + char(131)
              + char(28) + char(247) + char(38) + char(126);
    out = out + prism_binio.zero_bytes(4);
    pad = 16 - (len(out) % 16);
    if (pad == 0) { pad = 16; }
    out = out + prism_binio.zero_bytes(pad);
    out = out + prism_binio.u32le(7400);
    out = out + prism_binio.zero_bytes(120);
    out = out + char(248) + char(90) + char(140) + char(106) + char(222) + char(245)
              + char(217) + char(126) + char(236) + char(233) + char(12) + char(227)
              + char(117) + char(143) + char(41) + char(11);
    File f = path;
    f.write(out);
    return true;
}
