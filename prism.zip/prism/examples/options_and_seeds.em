# Options: quality, size, deterministic seeds.
# Run from the package root:   ./emerald examples/options_and_seeds.em
# emx-scope-safe

import prism;
import prism_preview;

shellexec("mkdir -p out");

# same prompt, three seeds -> three different rocks
for (i = 0; i < 3; ++i) {
    o = prism.PrismOpts;
    o.seed = 1000 + i;
    o.quality = "fast";       # "fast" | "normal" | "high" (atlas resolution)
    o.targetSize = 2.0;       # max dimension in model units
    model = prism.generate("mossy rock", nil, o);
    prism.export_all(model, "out", "rock_{o.seed}", false);
    print("rock seed {o.seed} -> out/rock_{o.seed}.obj");
}
print("same prompt + same seed always gives the same mesh.");
