# Generate models from text prompts.
# Run from the package root:   ./emerald examples/text_to_model.em
# emx-scope-safe

import prism;
import prism_preview;

shellexec("mkdir -p out");

prompts = [
    "a small red house",
    "low poly golden crown",
    "three tall pine trees"
];

for (i = 0; i < len(prompts); ++i) {
    p = prompts[i];
    print("generating '{p}' ...");
    model = prism.generate(p, nil, nil);
    prism.export_all(model, "out", model.name, true);
    prism_preview.save_preview(model, "out/{model.name}_preview.png", 340, 130);
    print("  -> out/{model.name}.obj/.mtl/.png/.fbx");
}
