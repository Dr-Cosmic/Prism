# Generate models from images (heightmap terrain + silhouette extrude).
# Run from the package root:   ./emerald examples/image_to_model.em
# emx-scope-safe

import prism;
import prism_preview;
import prism_imageio;

shellexec("mkdir -p out");

# 1. grayscale heightmap -> terrain (auto-colorized by altitude)
img = prism_imageio.load_any("tests/island.bmp");
model = prism.generate("terrain", img, nil);
prism.export_all(model, "out", "island", true);
prism_preview.save_preview(model, "out/island_preview.png", 340, 130);
print("island terrain -> out/island.*");

# 2. colored silhouette -> extruded shape, photo on the caps
img = prism_imageio.load_any("tests/heart.bmp");
model = prism.generate("extrude", img, nil);
prism.export_all(model, "out", "heart", true);
prism_preview.save_preview(model, "out/heart_preview.png", 340, 130);
print("heart extrude -> out/heart.*");

# 3. silhouette -> surface of revolution
img = prism_imageio.load_any("tests/pawnish.bmp");
model = prism.generate("lathe", img, nil);
prism.export_all(model, "out", "pawn", true);
prism_preview.save_preview(model, "out/pawn_preview.png", 340, 130);
print("pawn lathe -> out/pawn.*");
