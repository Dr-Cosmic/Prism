# prism_cli - driver used by run.sh. Reads .run_params.tmp:
#   line 1 prompt, line 2 image path (may be empty), line 3 output dir
# emx-scope-safe

import prism;
import prism_preview;
import prism_imageio;
import strx;
import mesh;

File pf = ".run_params.tmp";
nl = "" + char(10);
params = strx.split(pf.read(), nl);
prompt = params[0];
imgPath = "";
outDir = "out";
if (len(params) > 1) { imgPath = params[1]; }
if (len(params) > 2 && params[2] != "") { outDir = params[2]; }

img = nil;
if (imgPath != "") {
    img = prism_imageio.load_any(imgPath);
    if (img == nil) {
        print("could not load '{imgPath}' (BMP or PPM expected)");
    }
}

model = prism.generate(prompt, img, nil);
base = model.name;
prism.export_all(model, outDir, base, true);
prism_preview.save_preview(model, "{outDir}/{base}_preview.png", 340, 130);
nf = mesh.face_count(model.mesh);
nv = mesh.vertex_count(model.mesh);
print("wrote {outDir}/{base}.obj  .mtl  .png  .fbx  _preview.png");
print("{nv} vertices, {nf} faces, atlas {model.atlas[0]}x{model.atlas[1]}, seed {model.seed}");
