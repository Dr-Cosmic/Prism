# prism_types - plain data classes used across Prism.
#
# Kept in a module with NO imports on purpose: Emerald class field
# initializers assign through enclosing scopes when the name already
# exists there (Environment::assign tries outer scopes before creating
# a field), so a field called `mesh` in a module that imports `mesh`
# would silently overwrite the module binding. An import-free module
# guarantees every initializer creates a real field.
# emx-scope-safe

class GenSpec {
    shape = "abstract";
    color = nil;          # [r,g,b] override or nil
    colorName = "";
    texKind = "";         # material override ("wood", "stone", ...)
    size = 1.0;
    tallness = 1.0;
    wideness = 1.0;
    style = "";           # "lowpoly" | "smooth" | ""
    count = 1;
    seed = 1;
    noun = "";
    imageMode = "";       # "terrain" | "extrude" | "lathe" | "" (auto)
}

class PrismOpts {
    seed = nil;           # override the prompt-derived seed
    quality = "normal";   # "fast" | "normal" | "high"
    targetSize = 2.0;     # max dimension of the exported model
}

class PrismModel {
    mesh = nil;
    atlas = nil;
    name = "model";
    shape = "";
    seed = 0;
}
