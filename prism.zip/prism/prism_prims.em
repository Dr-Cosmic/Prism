# prism_prims - geometry generators that extend emeraldx `mesh`.
# Meshes use the emeraldx layout: [positions, normals, uvs, faces], flat
# parallel arrays over one vertex index space, CCW triangles.
#
#   box(sx, sy, sz)                     axis-aligned box (per-face UVs)
#   lathe(profile, segs, capB, capT)    surface of revolution around Y
#   cone(r, h, segs) / frustum(...)     via lathe
#   pyramid(base, h)                    4-segment lathe, flat shaded
#   gem(r, h, sides)                    faceted bipyramid-with-girdle
#   disc(r, segs)                       flat fan facing +Y
#   extrude(poly, depth)                ear-clipped 2D polygon -> solid
#   terrain(himg, size, amp, res)       heightfield from a gray image
#   displaced_sphere(r, sub, amt, sc, seed)  fbm-displaced icosphere
#   flat_shaded(m)                      unweld + facet normals
#   place(m, pos3, eulerXYZ, scale3)    trs transform
#   recenter_ground(m) / normalize_size(m, target) / bbox helpers
# emx-scope-safe

import mathx;
import mesh;
import uvmap;
import texture;
import mat4;
import arrayx;

# ---- transforms & fitting --------------------------------------------------

fn place(m, pos, euler, scale) {
    int e = 0; int p = 0; int s = 0;
    p = pos; e = euler; s = scale;
    if (p == nil) { p = [0.0, 0.0, 0.0]; }
    if (e == nil) { e = [0.0, 0.0, 0.0]; }
    if (s == nil) { s = [1.0, 1.0, 1.0]; }
    return mesh.transform_mesh(m, mat4.trs(p, e, s));
}

fn recenter_ground(m) {
    int b = 0; int cx = 0; int cz = 0; int out = 0;
    b = mesh.bounds(m);                  # [[minx,miny,minz],[maxx,maxy,maxz]]
    cx = (b[0][0] + b[1][0]) / 2.0;
    cz = (b[0][2] + b[1][2]) / 2.0;
    out = mesh.transform_mesh(m, mat4.translation(0.0 - cx, 0.0 - b[0][1], 0.0 - cz));
    return out;
}

fn normalize_size(m, target) {
    int b = 0; int d = 0; int s = 0;
    b = mesh.bounds(m);
    d = mathx.max3(b[1][0] - b[0][0], b[1][1] - b[0][1], b[1][2] - b[0][2]);
    if (d <= 0.0) { return m; }
    s = target / d;
    return mesh.transform_mesh(m, mat4.scaling(s, s, s));
}

fn merge_all(parts) {
    int i = 0; int m = 0;
    if (len(parts) == 0) { return mesh.new_mesh(); }
    m = parts[0];
    for (i = 1; i < len(parts); ++i) { m = mesh.merge(m, parts[i]); }
    return m;
}

# ---- simple solids ----------------------------------------------------------

fn box(sx, sy, sz) {
    return mesh.transform_mesh(mesh.cube(1.0), mat4.scaling(sx, sy, sz));
}

fn disc(r, segs) {
    int faces = 0; int i = 0; int normals = 0; int positions = 0; int th = 0; int uvs = 0;
    positions = [0.0, 0.0, 0.0];
    normals = [0.0, 1.0, 0.0];
    uvs = [0.5, 0.5];
    faces = [];
    for (i = 0; i <= segs; ++i) {
        th = mathx.TAU * i / segs;
        positions = positions + [r * cos(th), 0.0, r * sin(th)];
        normals = normals + [0.0, 1.0, 0.0];
        uvs = uvs + [0.5 + 0.5 * cos(th), 0.5 + 0.5 * sin(th)];
    }
    for (i = 1; i <= segs; ++i) { faces = faces + [0, i + 1, i]; }
    return [positions, normals, uvs, faces];
}

# profile: flat [r0,y0, r1,y1, ...] listed bottom -> top, radii >= 0.
# Revolves around +Y. capB/capT (default true) close ends whose radius > 0.
fn lathe(profile, segs, capB, capT) {
    int arclen = 0; int cB = 0; int cT = 0; int ci = 0; int cx = 0; int cz = 0; int dr = 0; int dy = 0;
    int faces = 0; int i = 0; int j = 0; int k = 0; int l = 0; int np = 0; int normals = 0; int nr = 0; int ny = 0;
    int positions = 0; int prevr = 0; int prevy = 0; int r = 0; int ring = 0; int s = 0; int th = 0;
    int total = 0; int uvs = 0; int v = 0; int y = 0; int base = 0; int a = 0; int b = 0; int c = 0; int d = 0;
    int r0 = 0; int r1 = 0; int rmax = 0;
    cB = capB; cT = capT;
    if (cB == nil) { cB = true; }
    if (cT == nil) { cT = true; }
    np = len(profile) // 2;
    # cumulative arclength for the v coordinate
    arclen = [0.0];
    total = 0.0;
    for (j = 1; j < np; ++j) {
        dr = profile[j * 2] - profile[(j - 1) * 2];
        dy = profile[j * 2 + 1] - profile[(j - 1) * 2 + 1];
        total = total + sqrt(dr * dr + dy * dy);
        arclen[j] = total;
    }
    if (total <= 0.0) { total = 1.0; }
    # per-profile-point outward normal (in the radial/Y plane), central differences
    nr = []; ny = [];
    for (j = 0; j < np; ++j) {
        a = j - 1; b = j + 1;
        if (a < 0) { a = 0; }
        if (b > np - 1) { b = np - 1; }
        dr = profile[b * 2] - profile[a * 2];
        dy = profile[b * 2 + 1] - profile[a * 2 + 1];
        l = sqrt(dr * dr + dy * dy);
        if (l <= 0.0) { nr[j] = 1.0; ny[j] = 0.0; }
        else { nr[j] = dy / l; ny[j] = (0.0 - dr) / l; }
    }
    positions = []; normals = []; uvs = []; faces = [];
    for (i = 0; i <= segs; ++i) {
        th = mathx.TAU * i / segs;
        cx = cos(th); cz = sin(th);
        for (j = 0; j < np; ++j) {
            r = profile[j * 2]; y = profile[j * 2 + 1];
            positions = positions + [r * cx, y, r * cz];
            if (r == 0.0 && ny[j] != 0.0) { normals = normals + [0.0, ny[j] / abs(ny[j]), 0.0]; }
            else { normals = normals + [nr[j] * cx, ny[j], nr[j] * cz]; }
            uvs = uvs + [i * 1.0 / segs, arclen[j] / total];
        }
    }
    for (i = 0; i < segs; ++i) {
        for (j = 0; j + 1 < np; ++j) {
            a = i * np + j;            # bottom, this column
            b = a + 1;                 # top, this column
            c = (i + 1) * np + j;      # bottom, next column
            d = c + 1;                 # top, next column
            r0 = profile[j * 2]; r1 = profile[j * 2 + 2];
            if (r0 > 0.0) { faces = faces + [a, b, c]; }
            if (r1 > 0.0) { faces = faces + [c, b, d]; }
        }
    }
    # caps
    rmax = 0.0;
    for (j = 0; j < np; ++j) { if (profile[j * 2] > rmax) { rmax = profile[j * 2]; } }
    if (cB && profile[0] > 0.0) {
        r = profile[0]; y = profile[1];
        base = len(positions) // 3;
        positions = positions + [0.0, y, 0.0];
        normals = normals + [0.0, 0.0 - 1.0, 0.0];
        uvs = uvs + [0.5, 0.5];
        for (i = 0; i <= segs; ++i) {
            th = mathx.TAU * i / segs;
            positions = positions + [r * cos(th), y, r * sin(th)];
            normals = normals + [0.0, 0.0 - 1.0, 0.0];
            uvs = uvs + [0.5 + 0.5 * (r / rmax) * cos(th), 0.5 + 0.5 * (r / rmax) * sin(th)];
        }
        for (i = 1; i <= segs; ++i) { faces = faces + [base, base + i, base + i + 1]; }
    }
    if (cT && profile[(np - 1) * 2] > 0.0) {
        r = profile[(np - 1) * 2]; y = profile[(np - 1) * 2 + 1];
        base = len(positions) // 3;
        positions = positions + [0.0, y, 0.0];
        normals = normals + [0.0, 1.0, 0.0];
        uvs = uvs + [0.5, 0.5];
        for (i = 0; i <= segs; ++i) {
            th = mathx.TAU * i / segs;
            positions = positions + [r * cos(th), y, r * sin(th)];
            normals = normals + [0.0, 1.0, 0.0];
            uvs = uvs + [0.5 + 0.5 * (r / rmax) * cos(th), 0.5 + 0.5 * (r / rmax) * sin(th)];
        }
        for (i = 1; i <= segs; ++i) { faces = faces + [base, base + i + 1, base + i]; }
    }
    return [positions, normals, uvs, faces];
}

fn cone(r, h, segs) {
    return lathe([r, 0.0 - h / 2.0, 0.0, h / 2.0], segs, true, false);
}

fn frustum(rBottom, rTop, h, segs) {
    return lathe([rBottom, 0.0 - h / 2.0, rTop, h / 2.0], segs, true, true);
}

fn capped_cylinder(r, h, segs) {
    return lathe([r, 0.0 - h / 2.0, r, h / 2.0], segs, true, true);
}

fn pyramid(base, h) {
    int m = 0;
    m = lathe([base * 0.7071, 0.0 - h / 2.0, 0.0, h / 2.0], 4, true, false);
    m = mesh.transform_mesh(m, mat4.rot_y(mathx.TAU / 8.0));
    return flat_shaded(m);
}

fn gem(r, h, sides) {
    int m = 0; int s = 0;
    s = sides;
    if (s == nil) { s = 7; }
    m = lathe([0.0, 0.0 - h * 0.52,
               r * 0.58, 0.0 - h * 0.18,
               r, h * 0.10,
               r * 0.62, h * 0.34,
               0.0, h * 0.48], s, false, false);
    return flat_shaded(m);
}

fn flat_shaded(m) {
    return mesh.compute_normals(uvmap.unweld(m));
}

# ---- 2D polygon -> solid -----------------------------------------------------

fn poly_signed_area(poly) {
    int a = 0; int i = 0; int j = 0; int n = 0;
    n = len(poly) // 2;
    a = 0.0;
    for (i = 0; i < n; ++i) {
        j = (i + 1) % n;
        a = a + poly[i * 2] * poly[j * 2 + 1] - poly[j * 2] * poly[i * 2 + 1];
    }
    return a / 2.0;
}

fn point_in_tri(px, py, ax, ay, bx, by, cx, cy) {
    int d1 = 0; int d2 = 0; int d3 = 0; int hasneg = 0; int haspos = 0;
    d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
    d2 = (px - cx) * (by - cy) - (bx - cx) * (py - cy);
    d3 = (px - ax) * (cy - ay) - (cx - ax) * (py - ay);
    hasneg = d1 < 0.0 || d2 < 0.0 || d3 < 0.0;
    haspos = d1 > 0.0 || d2 > 0.0 || d3 > 0.0;
    return !(hasneg && haspos);
}

# ear-clipping triangulation of a simple CCW polygon (flat [x,y,...]).
# returns flat triangle index triples into the original point list.
fn earclip(poly) {
    int ax = 0; int ay = 0; int bx = 0; int by = 0; int cx = 0; int cy = 0; int cross = 0;
    int i = 0; int idx = 0; int inside = 0; int k = 0; int n = 0; int p = 0; int prev = 0;
    int next = 0; int out = 0; int guard = 0; int px = 0; int py = 0; int cur = 0;
    n = len(poly) // 2;
    idx = [];
    for (i = 0; i < n; ++i) { idx[i] = i; }
    out = [];
    guard = 0;
    while (len(idx) > 3 && guard < 10000) {
        guard = guard + 1;
        n = len(idx);
        cur = 0 - 1;
        for (i = 0; i < n; ++i) {
            prev = idx[(i + n - 1) % n];
            p = idx[i];
            next = idx[(i + 1) % n];
            ax = poly[prev * 2]; ay = poly[prev * 2 + 1];
            bx = poly[p * 2];    by = poly[p * 2 + 1];
            cx = poly[next * 2]; cy = poly[next * 2 + 1];
            cross = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
            if (cross <= 0.0) { continue; }              # reflex corner: not an ear
            inside = false;
            for (k = 0; k < n; ++k) {
                if (idx[k] == prev || idx[k] == p || idx[k] == next) { continue; }
                px = poly[idx[k] * 2]; py = poly[idx[k] * 2 + 1];
                if (point_in_tri(px, py, ax, ay, bx, by, cx, cy)) { inside = true; break; }
            }
            if (!inside) { cur = i; break; }
        }
        if (cur < 0) { cur = 0; }                        # degenerate fallback: clip anyway
        prev = idx[(cur + len(idx) - 1) % len(idx)];
        p = idx[cur];
        next = idx[(cur + 1) % len(idx)];
        out = out + [prev, p, next];
        idx = arrayx.remove_at(idx, cur);
    }
    if (len(idx) == 3) { out = out + [idx[0], idx[1], idx[2]]; }
    return out;
}

# extrudes a simple polygon (flat [x,y,...], any winding) along Z.
# Front face at z=+depth/2 with UVs mapping the polygon's bbox to [0,1]
# upright (v grows downward in image space, so v = 1 at the top).
fn extrude_parts(polyIn, depth) {
    int cumu = 0; int dx = 0; int dy = 0; int el = 0; int hh = 0; int i = 0;
    int j = 0; int minx = 0; int miny = 0; int maxx = 0; int maxy = 0; int n = 0;
    int nx = 0; int ny = 0; int perim = 0; int poly = 0; int tris = 0;
    int u0 = 0; int u1 = 0; int w = 0; int x0 = 0; int x1 = 0; int y0 = 0; int y1 = 0;
    int z = 0; int base = 0; int nt = 0; int rev = 0;
    int cp = 0; int cn = 0; int cu = 0; int cf = 0;
    int sp = 0; int sn = 0; int su = 0; int sf = 0;
    poly = polyIn;
    if (poly_signed_area(poly) < 0.0) {                  # force CCW
        rev = [];
        n = len(poly) // 2;
        for (i = 0; i < n; ++i) {
            rev[i * 2] = poly[(n - 1 - i) * 2];
            rev[i * 2 + 1] = poly[(n - 1 - i) * 2 + 1];
        }
        poly = rev;
    }
    n = len(poly) // 2;
    z = depth / 2.0;
    minx = poly[0]; maxx = poly[0]; miny = poly[1]; maxy = poly[1];
    for (i = 1; i < n; ++i) {
        if (poly[i * 2] < minx) { minx = poly[i * 2]; }
        if (poly[i * 2] > maxx) { maxx = poly[i * 2]; }
        if (poly[i * 2 + 1] < miny) { miny = poly[i * 2 + 1]; }
        if (poly[i * 2 + 1] > maxy) { maxy = poly[i * 2 + 1]; }
    }
    w = maxx - minx; hh = maxy - miny;
    if (w <= 0.0) { w = 1.0; }
    if (hh <= 0.0) { hh = 1.0; }
    tris = earclip(poly);
    nt = len(tris) // 3;
    cp = []; cn = []; cu = []; cf = [];
    # front cap (+Z)
    for (i = 0; i < n; ++i) {
        cp = cp + [poly[i * 2], poly[i * 2 + 1], z];
        cn = cn + [0.0, 0.0, 1.0];
        cu = cu + [(poly[i * 2] - minx) / w, 1.0 - (poly[i * 2 + 1] - miny) / hh];
    }
    for (i = 0; i < nt; ++i) { cf = cf + [tris[i * 3], tris[i * 3 + 1], tris[i * 3 + 2]]; }
    # back cap (-Z), reversed winding, mirrored u so texture is not flipped
    base = n;
    for (i = 0; i < n; ++i) {
        cp = cp + [poly[i * 2], poly[i * 2 + 1], 0.0 - z];
        cn = cn + [0.0, 0.0, 0.0 - 1.0];
        cu = cu + [1.0 - (poly[i * 2] - minx) / w, 1.0 - (poly[i * 2 + 1] - miny) / hh];
    }
    for (i = 0; i < nt; ++i) {
        cf = cf + [base + tris[i * 3], base + tris[i * 3 + 2], base + tris[i * 3 + 1]];
    }
    # side wall: independent quads, u = perimeter fraction, v across depth
    sp = []; sn = []; su = []; sf = [];
    perim = 0.0;
    for (i = 0; i < n; ++i) {
        j = (i + 1) % n;
        dx = poly[j * 2] - poly[i * 2]; dy = poly[j * 2 + 1] - poly[i * 2 + 1];
        perim = perim + sqrt(dx * dx + dy * dy);
    }
    if (perim <= 0.0) { perim = 1.0; }
    cumu = 0.0;
    for (i = 0; i < n; ++i) {
        j = (i + 1) % n;
        x0 = poly[i * 2]; y0 = poly[i * 2 + 1];
        x1 = poly[j * 2]; y1 = poly[j * 2 + 1];
        dx = x1 - x0; dy = y1 - y0;
        el = sqrt(dx * dx + dy * dy);
        if (el <= 0.0) { continue; }
        nx = dy / el; ny = (0.0 - dx) / el;              # outward for CCW
        u0 = cumu / perim; u1 = (cumu + el) / perim;
        cumu = cumu + el;
        base = len(sp) // 3;
        sp = sp + [x0, y0, z,  x0, y0, 0.0 - z,  x1, y1, z,  x1, y1, 0.0 - z];
        sn = sn + [nx, ny, 0.0,  nx, ny, 0.0,  nx, ny, 0.0,  nx, ny, 0.0];
        su = su + [u0, 0.0,  u0, 1.0,  u1, 0.0,  u1, 1.0];
        sf = sf + [base, base + 2, base + 1,  base + 1, base + 2, base + 3];
    }
    return [[cp, cn, cu, cf], [sp, sn, su, sf]];
}

fn extrude(polyIn, depth) {
    int pr = 0;
    pr = extrude_parts(polyIn, depth);
    return mesh.merge(pr[0], pr[1]);
}

# ---- heightfield -------------------------------------------------------------

import image;

# gray/rgb image -> grid heightfield, XZ size `size`, height `amp`, res x res quads
fn terrain(himg, size, amp, res) {
    int faces = 0; int g = 0; int gx = 0; int gz = 0; int i = 0; int m = 0;
    int positions = 0; int u = 0; int uvs = 0; int v = 0; int x = 0; int y = 0; int z = 0;
    int a = 0; int b = 0; int c = 0; int d = 0; int gw = 0; int gh = 0; int gd = 0; int gch = 0;
    int sx = 0; int sy = 0; int ix = 0; int iy = 0; int fx = 0; int fy = 0;
    int i00 = 0; int a0 = 0; int a1 = 0; int h00 = 0; int h10 = 0; int h01 = 0; int h11 = 0;
    g = himg;
    gw = g[0]; gh = g[1]; gch = g[2]; gd = g[3];
    positions = []; uvs = []; faces = [];
    for (gz = 0; gz <= res; ++gz) {
        for (gx = 0; gx <= res; ++gx) {
            u = gx * 1.0 / res; v = gz * 1.0 / res;
            # inlined bilinear height fetch (channel 0 or gray average)
            sx = u * (gw - 1); sy = v * (gh - 1);
            ix = int(sx); iy = int(sy);
            if (ix > gw - 2) { ix = gw - 2; }
            if (iy > gh - 2) { iy = gh - 2; }
            if (ix < 0) { ix = 0; }
            if (iy < 0) { iy = 0; }
            fx = sx - ix; fy = sy - iy;
            i00 = (iy * gw + ix) * gch;
            if (gch == 1) {
                h00 = gd[i00]; h10 = gd[i00 + 1];
                h01 = gd[i00 + gw]; h11 = gd[i00 + gw + 1];
            } else {
                h00 = (gd[i00] + gd[i00 + 1] + gd[i00 + 2]) / 3.0;
                h10 = (gd[i00 + gch] + gd[i00 + gch + 1] + gd[i00 + gch + 2]) / 3.0;
                h01 = (gd[i00 + gw * gch] + gd[i00 + gw * gch + 1] + gd[i00 + gw * gch + 2]) / 3.0;
                h11 = (gd[i00 + gw * gch + gch] + gd[i00 + gw * gch + gch + 1] + gd[i00 + gw * gch + gch + 2]) / 3.0;
            }
            a0 = h00 + (h10 - h00) * fx;
            a1 = h01 + (h11 - h01) * fx;
            y = amp * (a0 + (a1 - a0) * fy);
            x = (u - 0.5) * size; z = (v - 0.5) * size;
            positions = positions + [x, y, z];
            uvs = uvs + [u, v];
        }
    }
    for (gz = 0; gz < res; ++gz) {
        for (gx = 0; gx < res; ++gx) {
            a = gz * (res + 1) + gx;
            b = a + 1;
            c = a + (res + 1);
            d = c + 1;
            faces = faces + [a, b, c,  b, d, c];
        }
    }
    m = [positions, [], uvs, faces];
    return mesh.compute_normals(m);
}

# ---- noise-displaced sphere ---------------------------------------------------

fn displaced_sphere(r, subdiv, amount, scale, seed) {
    int d = 0; int i = 0; int m = 0; int n = 0; int nv = 0; int p = 0; int x = 0; int y = 0; int z = 0;
    m = mesh.icosphere(r, subdiv);
    p = m[0];
    nv = len(p) // 3;
    for (i = 0; i < nv; ++i) {
        x = p[i * 3]; y = p[i * 3 + 1]; z = p[i * 3 + 2];
        n = texture.fbm_at(x * scale + 13.7, y * scale + 5.1, 4, seed)
          + texture.fbm_at(y * scale + 71.3, z * scale + 9.7, 4, seed + 7)
          + texture.fbm_at(z * scale + 37.1, x * scale + 3.3, 4, seed + 19);
        d = 1.0 + amount * (n / 1.5 - 1.0);
        p[i * 3] = x * d; p[i * 3 + 1] = y * d; p[i * 3 + 2] = z * d;
    }
    m[0] = p;
    return mesh.compute_normals(m);
}
