#!/usr/bin/env bash
# Build the Emerald interpreter from the bundled sources and self-test Prism.
set -euo pipefail
cd "$(dirname "$0")"

cmake -S third_party/Emerald -B third_party/Emerald/build -DCMAKE_BUILD_TYPE=Release
cmake --build third_party/Emerald/build -j"$(nproc 2>/dev/null || echo 2)"
ln -sf third_party/Emerald/build/emerald emerald
echo
./emerald selftest.em
echo
echo "Prism is ready:  ./run.sh \"a small red house\""
