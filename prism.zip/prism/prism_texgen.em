# prism_texgen - procedural texture synthesis for Prism.
#
# A model gets ONE square texture atlas. Each part-group owns a cell of the
# atlas and is painted with a material "kind" driven by a color palette
# (a ramp of RGB stops). All pattern math is built on the emeraldx `texture`
# noise (hash-lattice value noise / fbm / turbulence).
#
#   make_atlas(size)                       mid-gray RGB image
#   paint_cell(atlas, rect, kind, pal, sd) paint one cell; rect = [u0,v0,size]
#   paint_cell_image(atlas, rect, img)     resample an input image into a cell
#   ramp(pal, t)                           palette lookup, t in [0,1]
#   palette_of_kind(kind)                  default palette for a material
#   palette_from_color(rgb)                dark->light ramp around one color
#   palette_from_image(img, k, seed)       k-means dominant-color ramp
#
# kinds: plain checker wood bark marble stone brick roof metal gold grass
#        leaf sand snow water lava fabric crystal glass rust
# emx-scope-safe

import image;
import texture;
import mathx;
import ml_unsupervised;
import prng;

# ---- palettes ---------------------------------------------------------------

fn ramp(pal, t) {
    int f = 0; int i = 0; int n = 0; int tt = 0; int a = 0; int b = 0;
    n = len(pal);
    if (n == 1) { return pal[0]; }
    tt = mathx.clampf(t, 0.0, 1.0) * (n - 1);
    i = int(floor(tt));
    if (i > n - 2) { i = n - 2; }
    f = tt - i;
    a = pal[i]; b = pal[i + 1];
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
}

fn lighten(c, f) {
    return [c[0] + (1.0 - c[0]) * f, c[1] + (1.0 - c[1]) * f, c[2] + (1.0 - c[2]) * f];
}

fn scale_rgb(c, f) { return [c[0] * f, c[1] * f, c[2] * f]; }

fn palette_from_color(c) {
    return [scale_rgb(c, 0.42), scale_rgb(c, 0.75), c, lighten(c, 0.35)];
}

fn palette_of_kind(kind) {
    if (kind == "wood")    { return [[0.26,0.15,0.07],[0.45,0.27,0.12],[0.63,0.42,0.22],[0.76,0.56,0.32]]; }
    if (kind == "bark")    { return [[0.16,0.11,0.07],[0.30,0.21,0.13],[0.44,0.33,0.22]]; }
    if (kind == "marble")  { return [[0.58,0.58,0.64],[0.86,0.86,0.89],[0.95,0.95,0.97]]; }
    if (kind == "stone")   { return [[0.33,0.33,0.35],[0.50,0.50,0.52],[0.65,0.65,0.66]]; }
    if (kind == "brick")   { return [[0.44,0.15,0.11],[0.58,0.23,0.15],[0.68,0.32,0.19]]; }
    if (kind == "roof")    { return [[0.26,0.09,0.07],[0.40,0.14,0.11],[0.52,0.20,0.15]]; }
    if (kind == "metal")   { return [[0.40,0.42,0.46],[0.58,0.60,0.64],[0.78,0.80,0.84]]; }
    if (kind == "gold")    { return [[0.52,0.34,0.05],[0.83,0.60,0.11],[1.00,0.85,0.34]]; }
    if (kind == "grass")   { return [[0.09,0.27,0.07],[0.18,0.42,0.11],[0.32,0.56,0.17]]; }
    if (kind == "leaf")    { return [[0.06,0.22,0.08],[0.13,0.37,0.13],[0.23,0.50,0.19]]; }
    if (kind == "sand")    { return [[0.70,0.58,0.36],[0.81,0.70,0.47],[0.89,0.80,0.57]]; }
    if (kind == "snow")    { return [[0.78,0.84,0.91],[0.91,0.94,0.97],[1.00,1.00,1.00]]; }
    if (kind == "water")   { return [[0.04,0.16,0.33],[0.09,0.30,0.52],[0.23,0.52,0.72]]; }
    if (kind == "lava")    { return [[0.05,0.02,0.02],[0.44,0.05,0.02],[0.90,0.35,0.05],[1.00,0.80,0.25]]; }
    if (kind == "fabric")  { return [[0.28,0.12,0.32],[0.42,0.20,0.47],[0.56,0.32,0.60]]; }
    if (kind == "crystal") { return [[0.03,0.30,0.24],[0.08,0.55,0.42],[0.42,0.90,0.72]]; }
    if (kind == "glass")   { return [[0.50,0.72,0.83],[0.68,0.86,0.94],[0.85,0.96,1.00]]; }
    if (kind == "rust")    { return [[0.42,0.19,0.08],[0.56,0.28,0.11],[0.68,0.38,0.16]]; }
    if (kind == "checker") { return [[0.12,0.12,0.14],[0.92,0.92,0.94]]; }
    return [[0.45,0.45,0.48],[0.62,0.62,0.65],[0.78,0.78,0.80]];   # plain
}

fn palette_from_image(img, k, seed) {
    int c = 0; int centers = 0; int fit = 0; int i = 0; int kk = 0; int lum = 0; int n = 0;
    int order = 0; int out = 0; int s = 0; int step = 0; int total = 0; int x = 0; int xs = 0; int y = 0;
    int best = 0; int bi = 0; int j = 0; int tmp = 0;
    kk = k;
    if (kk == nil) { kk = 4; }
    total = img[0] * img[1];
    n = 300;
    if (n > total) { n = total; }
    step = total // n;
    if (step < 1) { step = 1; }
    xs = [];
    s = img[3];                     # direct data access: get_px would clone img per call
    for (i = 0; i < n; ++i) {
        x = (i * step * img[2]) % len(s);
        if (img[2] == 1) { xs[i] = [s[x], s[x], s[x]]; }
        else { xs[i] = [s[x], s[x + 1], s[x + 2]]; }
    }
    fit = ml_unsupervised.kmeans_fit(xs, kk, 15, seed);
    centers = fit[0];
    # order centers dark -> light
    lum = [];
    for (i = 0; i < kk; ++i) {
        c = centers[i];
        lum[i] = 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
    }
    out = [];
    for (i = 0; i < kk; ++i) {
        best = 1.0e9; bi = 0;
        for (j = 0; j < kk; ++j) { if (lum[j] < best) { best = lum[j]; bi = j; } }
        out[i] = centers[bi];
        lum[bi] = 1.0e9;
    }
    return out;
}

# ---- atlas ------------------------------------------------------------------

fn make_atlas(size) {
    return image.new_image(size, size, 3, 0.5);
}

fn kind_code(kind) {
    if (kind == "plain")   { return 0; }
    if (kind == "checker") { return 1; }
    if (kind == "wood")    { return 2; }
    if (kind == "bark")    { return 3; }
    if (kind == "marble")  { return 4; }
    if (kind == "stone")   { return 5; }
    if (kind == "brick")   { return 6; }
    if (kind == "roof")    { return 7; }
    if (kind == "metal")   { return 8; }
    if (kind == "gold")    { return 9; }
    if (kind == "grass")   { return 10; }
    if (kind == "leaf")    { return 11; }
    if (kind == "sand")    { return 12; }
    if (kind == "snow")    { return 13; }
    if (kind == "water")   { return 14; }
    if (kind == "lava")    { return 15; }
    if (kind == "fabric")  { return 16; }
    if (kind == "crystal") { return 17; }
    if (kind == "glass")   { return 18; }
    if (kind == "rust")    { return 19; }
    return 0;
}

# ---- coarse noise grids -----------------------------------------------------
# fbm is smooth, so it is evaluated on a coarse pixel lattice and bilinearly
# resampled per pixel; crisp detail comes from cheap per-pixel hashes.

fn noise_grid(w, h, su, sv, oct, seed, step) {
    int d = 0; int gh = 0; int gw = 0; int gx = 0; int gy = 0;
    gw = w // step + 2;
    gh = h // step + 2;
    d = [];
    for (gy = 0; gy < gh; ++gy) {
        for (gx = 0; gx < gw; ++gx) {
            d[gy * gw + gx] = texture.fbm_at(gx * step / float(w) * su, gy * step / float(h) * sv, oct, seed);
        }
    }
    return [gw, gh, step, d];
}

fn gsamp(fg, px, py) {
    int d = 0; int fx = 0; int fy = 0; int gw = 0; int tx = 0; int ty = 0;
    int x0 = 0; int y0 = 0; int a = 0; int b = 0;
    gw = fg[0];
    fx = px / float(fg[2]);
    fy = py / float(fg[2]);
    x0 = int(floor(fx)); y0 = int(floor(fy));
    if (x0 > fg[0] - 2) { x0 = fg[0] - 2; }
    if (y0 > fg[1] - 2) { y0 = fg[1] - 2; }
    tx = fx - x0; ty = fy - y0;
    d = fg[3];
    a = d[y0 * gw + x0] + (d[y0 * gw + x0 + 1] - d[y0 * gw + x0]) * tx;
    b = d[(y0 + 1) * gw + x0] + (d[(y0 + 1) * gw + x0 + 1] - d[(y0 + 1) * gw + x0]) * tx;
    return a + (b - a) * ty;
}

# paint the atlas region rect=[u0,v0,size] (uv space) with material `kind`.
fn paint_cell(atlas, rect, kind, palIn, seed) {
    int a = 0; int b = 0; int bx = 0; int by = 0; int col = 0; int d = 0; int g = 0;
    int h = 0; int k = 0; int m = 0; int mortar = 0; int n = 0; int out = 0; int pal = 0;
    int px = 0; int py = 0; int row = 0; int rowoff = 0; int rgb = 0; int t = 0;
    int tint = 0; int u = 0; int v = 0; int w = 0; int x0 = 0; int x1 = 0; int y0 = 0; int y1 = 0;
    int sd = 0; int size = 0; int fx = 0; int fy = 0; int q = 0; int hi = 0;
    int A = 0; int B = 0; int lx = 0; int ly = 0; int metalPal = 0;
    int Agw = 0; int Ast = 0; int Ad = 0; int Bgw = 0; int Bst = 0; int Bd = 0;
    int pr = 0; int pg = 0; int pb = 0; int pn = 0; int mr = 0; int mg2 = 0; int mb = 0;
    int fxx = 0; int fyy = 0; int xg = 0; int yg = 0; int txx = 0; int tyy = 0; int s0 = 0; int s1 = 0;
    int gA = 0; int gB = 0; int i = 0; int hh = 0; int tt = 0; int r0 = 0; int g0 = 0; int b0 = 0;
    out = atlas;
    size = out[0];
    pal = palIn;
    if (pal == nil) { pal = palette_of_kind(kind); }
    k = kind_code(kind);
    sd = seed;
    if (sd == nil) { sd = 1; }
    x0 = int(floor(rect[0] * size));
    y0 = int(floor(rect[1] * size));
    x1 = int(floor((rect[0] + rect[2]) * size));
    y1 = int(floor((rect[1] + rect[2]) * size));
    if (x1 > size) { x1 = size; }
    if (y1 > size) { y1 = size; }
    w = x1 - x0; h = y1 - y0;
    if (w < 1 || h < 1) { return out; }
    # precompute the smooth fields this material needs
    A = nil; B = nil;
    if (k == 0)  { A = noise_grid(w, h, 5.0, 5.0, 3, sd, 4); }
    elif (k == 1)  { A = noise_grid(w, h, 9.0, 9.0, 2, sd, 4); }
    elif (k == 2)  { A = noise_grid(w, h, 3.0, 9.0, 3, sd, 3); }
    elif (k == 3)  { A = noise_grid(w, h, 14.0, 3.0, 3, sd, 2); }
    elif (k == 4)  { A = noise_grid(w, h, 4.0, 4.0, 4, sd, 3); }
    elif (k == 5)  { A = noise_grid(w, h, 4.0, 4.0, 3, sd, 4); }
    elif (k == 6 || k == 7) { A = noise_grid(w, h, 12.0, 12.0, 2, sd + 2, 3); }
    elif (k == 8 || k == 9) { A = noise_grid(w, h, 2.0, 8.0, 2, sd, 3); }
    elif (k == 10) { A = noise_grid(w, h, 22.0, 22.0, 2, sd, 2); }
    elif (k == 11) { A = noise_grid(w, h, 9.0, 9.0, 3, sd, 3); }
    elif (k == 12) { A = noise_grid(w, h, 3.0, 3.0, 2, sd, 4); }
    elif (k == 13) { A = noise_grid(w, h, 10.0, 10.0, 2, sd, 3); }
    elif (k == 14) { A = noise_grid(w, h, 3.0, 3.0, 2, sd, 4); B = noise_grid(w, h, 4.0, 4.0, 2, sd + 4, 4); }
    elif (k == 15) { A = noise_grid(w, h, 6.0, 6.0, 3, sd, 2); }
    elif (k == 16) { A = noise_grid(w, h, 6.0, 6.0, 2, sd, 4); }
    elif (k == 17 || k == 18) { A = noise_grid(w, h, 3.5, 3.5, 2, sd, 4); }
    elif (k == 19) { A = noise_grid(w, h, 5.0, 5.0, 3, sd, 3); B = noise_grid(w, h, 2.0, 8.0, 2, sd + 8, 3); }
    if (A != nil) { Agw = A[0]; Ast = A[2]; Ad = A[3]; }
    if (B != nil) { Bgw = B[0]; Bst = B[2]; Bd = B[3]; }
    # flatten palette for inline ramp
    pn = len(pal);
    pr = []; pg = []; pb = [];
    for (i = 0; i < pn; ++i) { pr[i] = pal[i][0]; pg[i] = pal[i][1]; pb[i] = pal[i][2]; }
    mr = [0.40, 0.58, 0.75]; mg2 = [0.42, 0.60, 0.77]; mb = [0.46, 0.64, 0.81];
    d = out[3];
    for (py = y0; py < y1; ++py) {
        ly = py - y0;
        v = ly / float(h);
        for (px = x0; px < x1; ++px) {
            lx = px - x0;
            u = lx / float(w);
            gA = 0.0;
            if (A != nil) {
                fxx = lx / float(Ast); fyy = ly / float(Ast);
                xg = int(floor(fxx)); yg = int(floor(fyy));
                txx = fxx - xg; tyy = fyy - yg;
                s0 = Ad[yg * Agw + xg];       s0 = s0 + (Ad[yg * Agw + xg + 1] - s0) * txx;
                s1 = Ad[(yg + 1) * Agw + xg]; s1 = s1 + (Ad[(yg + 1) * Agw + xg + 1] - s1) * txx;
                gA = s0 + (s1 - s0) * tyy;
            }
            gB = 0.0;
            if (B != nil) {
                fxx = lx / float(Bst); fyy = ly / float(Bst);
                xg = int(floor(fxx)); yg = int(floor(fyy));
                txx = fxx - xg; tyy = fyy - yg;
                s0 = Bd[yg * Bgw + xg];       s0 = s0 + (Bd[yg * Bgw + xg + 1] - s0) * txx;
                s1 = Bd[(yg + 1) * Bgw + xg]; s1 = s1 + (Bd[(yg + 1) * Bgw + xg + 1] - s1) * txx;
                gB = s0 + (s1 - s0) * tyy;
            }
            rgb = nil;
            if (k == 0) {          # plain: gentle fbm around the mid tones
                g = 0.4 + 0.3 * gA;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 1) {        # checker
                a = int(floor(u * 8.0)) + int(floor(v * 8.0));
                g = 0.06 * gA;
                if (a % 2 == 0) { tt = 0.0 + g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1; } else { tt = 1.0 - g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1; }
            }
            elif (k == 2) {        # wood: rings warped by noise
                fx = u * 2.4 - 1.2; fy = v * 6.0;
                t = sqrt(fx * fx * 9.0 + fy * fy * 0.08) + 0.9 * gA;
                g = t * 4.0 - floor(t * 4.0);
                g = 0.25 + 0.75 * g;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 3) {        # bark: strong vertical grain + fine streaks
                g = 0.8 * gA + 0.25 * ((((((px) * 374761 + (py // 5) * 668265 + (sd + 3) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 4) {        # marble: classic sin + turbulence veins
                t = sin((u * 4.0 + v * 2.0) * 3.14159 + 5.5 * gA);
                g = 0.5 + 0.5 * t;
                g = g * g;
                tt = 1.0 - g * 0.9;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 5) {        # stone: coarse blotches + fine speckle
                g = 0.72 * gA + 0.28 * ((((((px // 2) * 374761 + (py // 2) * 668265 + (sd + 5) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 6 || k == 7) {   # brick / roof shingles
                row = v * 6.0;
                if (k == 7) { row = v * 7.0; }
                rowoff = 0.0;
                if (int(floor(row)) % 2 == 1) { rowoff = 0.5; }
                col = u * 3.0 + rowoff;
                if (k == 7) { col = u * 4.0 + rowoff; }
                by = row - floor(row);
                bx = col - floor(col);
                mortar = 0;
                if (by < 0.12 || bx < 0.06) { mortar = 1; }
                if (mortar == 1) {
                    g = 0.72 + 0.10 * gA;
                    r0 = g; g0 = g * 0.98; b0 = g * 0.94;
                    if (k == 7) { r0 = g * 0.45; g0 = g * 0.42; b0 = g * 0.42; }
                    rgb = 1;
                } else {
                    tint = ((((((int(floor(col)) + 13) * 374761 + (int(floor(row)) * 7) * 668265 + (sd) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0;
                    g = 0.25 + 0.55 * tint + 0.20 * gA;
                    tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
                }
            }
            elif (k == 8 || k == 9) {   # metal / gold: brushed streaks
                g = 0.28 + 0.42 * gA
                  + 0.22 * (((((((7) * 374761 + (py) * 668265 + (sd) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0 + ((((((7) * 374761 + (py + 1) * 668265 + (sd) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0) * 0.5
                  + 0.14 * (1.0 - v);
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 10) {       # grass
                g = 0.7 * gA + 0.3 * ((((((px) * 374761 + (py) * 668265 + (sd + 9) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 11) {       # leaf / foliage clumps
                g = gA;
                g = g * g * 1.4 + 0.12 * ((((((px // 2) * 374761 + (py // 2) * 668265 + (sd + 1) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 12) {       # sand: fine grain + soft dunes
                g = 0.55 * (0.5 + 0.5 * sin((u * 3.0 + v) * 6.28 + 2.0 * gA))
                  + 0.45 * ((((((px) * 374761 + (py) * 668265 + (sd + 2) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0 * 0.6;
                tt = g + 0.1;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 13) {       # snow
                g = 0.6 + 0.4 * gA;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 14) {       # water: layered waves
                t = sin(u * 18.0 + 3.0 * gA)
                  + sin((u * 6.0 + v * 14.0) + 2.5 * gB);
                g = 0.5 + 0.25 * t;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 15) {       # lava: hot cracks
                g = gA;
                g = abs(g * 2.0 - 1.0);
                g = 1.0 - g * g;
                tt = g * g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 16) {       # fabric: weave
                t = 0.5 * sin(u * 90.0) + 0.5 * sin(v * 90.0);
                g = 0.45 + 0.18 * t + 0.30 * gA;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 17 || k == 18) { # crystal / glass: posterized facets + sheen
                g = gA;
                q = floor(g * 5.0) / 5.0;
                hi = 0.0;
                t = u + v * 0.6;
                if (t - floor(t / 0.9) * 0.9 < 0.08) { hi = 0.35; }   # diagonal sheen stripes
                g = 0.25 + 0.6 * q + hi;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            elif (k == 19) {       # rust: patchy corrosion over metal
                m = gA;
                if (m > 0.55) {
                    g = 0.35 + 0.45 * ((((((px // 2) * 374761 + (py // 2) * 668265 + (sd + 6) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0 + 0.2 * m;
                    tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
                } else {
                    g = 0.30 + 0.45 * gB
                      + 0.20 * (((((((7) * 374761 + (py) * 668265 + (sd) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0 + ((((((7) * 374761 + (py + 1) * 668265 + (sd) * 1274126) * 1103515245 + 12345) % 2147483648) * 1103515245 + 12345) % 2147483648) / 2147483648.0) * 0.5;
                    tt = g;
                    if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                    tt = tt * 2.0; i = int(floor(tt)); if (i > 1) { i = 1; } tt = tt - i;
                    r0 = mr[i] + (mr[i + 1] - mr[i]) * tt;
                    g0 = mg2[i] + (mg2[i + 1] - mg2[i]) * tt;
                    b0 = mb[i] + (mb[i + 1] - mb[i]) * tt;
                    rgb = 1;
                }
            }
            else {
                g = 0.5;
                tt = g;
                if (tt < 0.0) { tt = 0.0; } if (tt > 1.0) { tt = 1.0; }
                tt = tt * (pn - 1);
                i = int(floor(tt));
                if (i > pn - 2) { i = pn - 2; }
                if (i < 0) { i = 0; }
                tt = tt - i;
                r0 = pr[i] + (pr[i + 1] - pr[i]) * tt;
                g0 = pg[i] + (pg[i + 1] - pg[i]) * tt;
                b0 = pb[i] + (pb[i + 1] - pb[i]) * tt;
                rgb = 1;
            }
            n = (py * size + px) * 3;
            d[n] = r0; d[n + 1] = g0; d[n + 2] = b0;
        }
    }
    out[3] = d;
    return out;
}

# resample an arbitrary image into the given atlas cell (bilinear)
fn paint_cell_image(atlas, rect, img) {
    int d = 0; int h = 0; int n = 0; int out = 0; int px = 0; int py = 0; int size = 0;
    int sx = 0; int sy = 0; int u = 0; int v = 0; int w = 0; int x0 = 0; int x1 = 0;
    int y0 = 0; int y1 = 0; int src = 0; int sw = 0; int sh = 0; int sd = 0; int sch = 0;
    int ix = 0; int iy = 0; int fx = 0; int fy = 0; int i00 = 0; int i10 = 0; int i01 = 0;
    int i11 = 0; int c = 0; int a0 = 0; int a1 = 0;
    out = atlas;
    size = out[0];
    src = img;
    sw = src[0]; sh = src[1]; sch = src[2]; sd = src[3];
    x0 = rect[0] * size;
    y0 = rect[1] * size;
    x1 = (rect[0] + rect[2]) * size;
    y1 = (rect[1] + rect[2]) * size;
    w = x1 - x0; h = y1 - y0;
    if (w < 1 || h < 1) { return out; }
    d = out[3];
    # inlined bilinear fetch: function args are deep-cloned per call in
    # Emerald, so image.sample_bilinear(src, ...) per pixel is O(image) each
    for (py = y0; py < y1; ++py) {
        v = (py - y0) / (h - 1 + 0.0001);
        sy = v * (sh - 1);
        iy = int(sy);
        if (iy > sh - 2) { iy = sh - 2; }
        if (iy < 0) { iy = 0; }
        fy = sy - iy;
        for (px = x0; px < x1; ++px) {
            u = (px - x0) / (w - 1 + 0.0001);
            sx = u * (sw - 1);
            ix = int(sx);
            if (ix > sw - 2) { ix = sw - 2; }
            if (ix < 0) { ix = 0; }
            fx = sx - ix;
            n = (py * size + px) * 3;
            for (c = 0; c < 3; ++c) {
                if (sch == 1) {
                    i00 = iy * sw + ix;
                    i10 = i00 + 1;
                    i01 = i00 + sw;
                    i11 = i01 + 1;
                } else {
                    i00 = (iy * sw + ix) * sch + c;
                    i10 = i00 + sch;
                    i01 = i00 + sw * sch;
                    i11 = i01 + sch;
                }
                a0 = sd[i00] + (sd[i10] - sd[i00]) * fx;
                a1 = sd[i01] + (sd[i11] - sd[i01]) * fx;
                d[n + c] = a0 + (a1 - a0) * fy;
            }
        }
    }
    out[3] = d;
    return out;
}
