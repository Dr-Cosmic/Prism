# prism_shapes - the recipe library: spec -> parts.
#
# A "part" is [mesh, texKind, palette, cellKey]:
#   mesh     placed in world space with UVs already projected to [0,1]
#   texKind  material painter name (see prism_texgen)
#   palette  RGB ramp override, or nil for the material default
#   cellKey  parts sharing a cellKey share one atlas cell (same paint)
#
# Recipes honor the spec: spec.color/texKind restyle the PRIMARY surfaces
# of a shape (house walls, vase body, ...) while accents (roofs, foliage,
# windows) keep their own materials. spec.style == "lowpoly" facets the
# main forms. Every recipe grounds near y=0 and spans roughly 1-2 units;
# the facade rescales afterwards.
# emx-scope-safe

import mesh;
import mat4;
import mathx;
import prng;
import prism_prims;
import prism_uv;
import prism_texgen;

# part helpers ----------------------------------------------------------------

fn P(m, kind, pal, key) { return [m, kind, pal, key]; }

# primary material for a shape: user color/material overrides the default
fn prim_kind(spec, defKind) {
    if (spec.texKind != "") { return spec.texKind; }
    return defKind;
}
fn prim_pal(spec, defKind) {
    if (spec.color != nil) { return prism_texgen.palette_from_color(spec.color); }
    if (spec.texKind != "") { return nil; }
    if (defKind == "__color__") { return nil; }
    return nil;
}
# key for the primary cell (varies with color so instances can differ)
fn prim_key(spec, defKind) {
    return prim_kind(spec, defKind) + "|" + spec.colorName;
}

fn maybe_facet(spec, m) {
    if (spec.style == "lowpoly") { return prism_prims.flat_shaded(m); }
    return m;
}

fn proj(m, mode) { return prism_uv.project(m, mode); }

# ---- basic solids -------------------------------------------------------------

fn r_cube(spec) {
    int m = 0;
    m = proj(prism_prims.box(1.4, 1.4, 1.4), "box");
    m = prism_prims.place(m, [0.0, 0.7, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_sphere(spec) {
    int m = 0;
    m = mesh.uv_sphere(0.8, 28, 18);
    if (spec.style == "lowpoly") { m = prism_prims.flat_shaded(mesh.icosphere(0.8, 2)); m = proj(m, "sphere"); }
    else { m = proj(m, "sphere"); }
    m = prism_prims.place(m, [0.0, 0.8, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_cylinder(spec) {
    int m = 0;
    m = maybe_facet(spec, prism_prims.capped_cylinder(0.55, 1.6, 24));
    m = proj(m, "keep");
    m = prism_prims.place(m, [0.0, 0.8, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_cone(spec) {
    int m = 0;
    m = maybe_facet(spec, prism_prims.cone(0.75, 1.6, 24));
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.8, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_pyramid(spec) {
    int m = 0;
    m = prism_prims.pyramid(1.5, 1.2);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.6, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "sand"), prim_pal(spec, "sand"), prim_key(spec, "sand"))];
}

fn r_torus(spec) {
    int m = 0;
    m = mesh.torus(0.65, 0.26, 28, 16);
    m = maybe_facet(spec, m);
    m = prism_prims.place(proj(m, "cyl"), [0.0, 0.4, 0.0], [1.5708, 0.0, 0.0], nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_ring(spec) {
    int m = 0;
    m = mesh.torus(0.6, 0.09, 32, 12);
    m = prism_prims.place(proj(m, "cyl"), [0.0, 0.62, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "gold"), prim_pal(spec, "gold"), prim_key(spec, "gold"))];
}

fn r_gem(spec) {
    int m = 0;
    m = prism_prims.gem(0.75, 1.5, 7);
    m = prism_prims.place(proj(m, "cyl"), [0.0, 0.85, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "crystal"), prim_pal(spec, "crystal"), prim_key(spec, "crystal"))];
}

fn r_crystal_shape(spec) {
    int i = 0; int m = 0; int parts = 0; int st = 0; int r = 0; int h = 0; int x = 0; int z = 0; int a = 0;
    st = prng.seed_from(spec.seed);
    parts = [];
    for (i = 0; i < 5; ++i) {
        r = prng.uniform(st, 0.10, 0.24); st = r[1]; h = r[0];
        r = prng.uniform(st, 0.5, 1.5); st = r[1];
        m = prism_prims.gem(h * 1.6, r[0], 6);
        r = prng.uniform(st, 0.0, 6.28); st = r[1]; a = r[0];
        x = 0.34 * cos(a) * i / 2.0;
        z = 0.34 * sin(a) * i / 2.0;
        r = prng.uniform(st, -0.4, 0.4); st = r[1];
        m = prism_prims.place(proj(m, "cyl"), [x, 0.42 * (i % 3), z], [r[0] * 0.5, a, r[0]], nil);
        parts[len(parts)] = P(m, prim_kind(spec, "crystal"), prim_pal(spec, "crystal"), prim_key(spec, "crystal"));
    }
    return parts;
}

# ---- buildings ------------------------------------------------------------------

fn roof_prism(w, d, h) {
    # triangular prism roof via extrude, laid over X
    int m = 0;
    m = prism_prims.extrude([0.0 - d / 2.0, 0.0, d / 2.0, 0.0, 0.0, h], w);
    m = mesh.transform_mesh(m, mat4.rot_y(1.5708));
    return m;
}

fn r_house(spec) {
    int body = 0; int chimney = 0; int door = 0; int parts = 0; int roof = 0; int w1 = 0; int w2 = 0;
    int wallKind = 0; int wallPal = 0; int wallKey = 0;
    wallKind = prim_kind(spec, "brick");
    wallPal = prim_pal(spec, "brick");
    wallKey = prim_key(spec, "brick");
    parts = [];
    body = prism_prims.place(proj(prism_prims.box(1.6, 1.0, 1.2), "box"), [0.0, 0.5, 0.0], nil, nil);
    parts[0] = P(body, wallKind, wallPal, wallKey);
    roof = roof_prism(1.8, 1.4, 0.62);
    roof = prism_prims.place(proj(roof, "box"), [0.0, 1.0, 0.0], nil, nil);
    parts[1] = P(roof, "roof", nil, "roof|");
    door = prism_prims.place(proj(prism_prims.box(0.34, 0.56, 0.06), "planar"), [0.0, 0.28, 0.62], nil, nil);
    parts[2] = P(door, "wood", nil, "wood|");
    w1 = prism_prims.place(proj(prism_prims.box(0.30, 0.30, 0.05), "planar"), [0.55, 0.62, 0.62], nil, nil);
    parts[3] = P(w1, "glass", nil, "glass|");
    w2 = prism_prims.place(proj(prism_prims.box(0.30, 0.30, 0.05), "planar"), [0.0 - 0.55, 0.62, 0.62], nil, nil);
    parts[4] = P(w2, "glass", nil, "glass|");
    chimney = prism_prims.place(proj(prism_prims.box(0.2, 0.55, 0.2), "box"), [0.5, 1.35, 0.0 - 0.25], nil, nil);
    parts[5] = P(chimney, "brick", nil, "chimney|brick");
    return parts;
}

fn r_tower(spec) {
    int body = 0; int door = 0; int parts = 0; int roof = 0; int trim = 0; int w1 = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "stone"); pal = prim_pal(spec, "stone"); key = prim_key(spec, "stone");
    parts = [];
    body = prism_prims.capped_cylinder(0.45, 1.9, 18);
    body = prism_prims.place(proj(body, "keep"), [0.0, 0.95, 0.0], nil, nil);
    parts[0] = P(body, k, pal, key);
    trim = prism_prims.capped_cylinder(0.52, 0.12, 18);
    trim = prism_prims.place(proj(trim, "keep"), [0.0, 1.93, 0.0], nil, nil);
    parts[1] = P(trim, k, pal, key);
    roof = prism_prims.cone(0.58, 0.7, 18);
    roof = prism_prims.place(proj(roof, "keep"), [0.0, 2.35, 0.0], nil, nil);
    parts[2] = P(roof, "roof", nil, "roof|");
    door = prism_prims.place(proj(prism_prims.box(0.26, 0.5, 0.1), "planar"), [0.0, 0.25, 0.42], nil, nil);
    parts[3] = P(door, "wood", nil, "wood|");
    w1 = prism_prims.place(proj(prism_prims.box(0.16, 0.24, 0.1), "planar"), [0.0, 1.35, 0.43], nil, nil);
    parts[4] = P(w1, "glass", nil, "glass|");
    return parts;
}

fn r_castle(spec) {
    int i = 0; int keep2 = 0; int kroof = 0; int parts = 0; int t = 0; int troof = 0; int wall = 0;
    int x = 0; int z = 0; int k = 0; int pal = 0; int key = 0; int gate = 0;
    k = prim_kind(spec, "stone"); pal = prim_pal(spec, "stone"); key = prim_key(spec, "stone");
    parts = [];
    # four corner towers + connecting walls + central keep
    for (i = 0; i < 4; ++i) {
        x = 0.85; z = 0.85;
        if (i == 1 || i == 2) { x = 0.0 - 0.85; }
        if (i >= 2) { z = 0.0 - 0.85; }
        t = prism_prims.capped_cylinder(0.28, 1.5, 14);
        t = prism_prims.place(proj(t, "keep"), [x, 0.75, z], nil, nil);
        parts[len(parts)] = P(t, k, pal, key);
        troof = prism_prims.cone(0.36, 0.5, 14);
        troof = prism_prims.place(proj(troof, "keep"), [x, 1.75, z], nil, nil);
        parts[len(parts)] = P(troof, "roof", nil, "roof|");
    }
    wall = prism_prims.place(proj(prism_prims.box(1.7, 1.0, 0.22), "box"), [0.0, 0.5, 0.85], nil, nil);
    parts[len(parts)] = P(wall, k, pal, key);
    wall = prism_prims.place(proj(prism_prims.box(1.7, 1.0, 0.22), "box"), [0.0, 0.5, 0.0 - 0.85], nil, nil);
    parts[len(parts)] = P(wall, k, pal, key);
    wall = prism_prims.place(proj(prism_prims.box(0.22, 1.0, 1.7), "box"), [0.85, 0.5, 0.0], nil, nil);
    parts[len(parts)] = P(wall, k, pal, key);
    wall = prism_prims.place(proj(prism_prims.box(0.22, 1.0, 1.7), "box"), [0.0 - 0.85, 0.5, 0.0], nil, nil);
    parts[len(parts)] = P(wall, k, pal, key);
    keep2 = prism_prims.place(proj(prism_prims.box(0.9, 1.6, 0.9), "box"), [0.0, 0.8, 0.0], nil, nil);
    parts[len(parts)] = P(keep2, k, pal, key);
    kroof = prism_prims.pyramid(1.15, 0.6);
    kroof = prism_prims.place(proj(kroof, "box"), [0.0, 1.9, 0.0], nil, nil);
    parts[len(parts)] = P(kroof, "roof", nil, "roof|");
    gate = prism_prims.place(proj(prism_prims.box(0.4, 0.6, 0.1), "planar"), [0.0, 0.3, 0.97], nil, nil);
    parts[len(parts)] = P(gate, "wood", nil, "wood|");
    return parts;
}

# ---- nature ---------------------------------------------------------------------

fn r_tree(spec) {
    int c = 0; int i = 0; int parts = 0; int r = 0; int st = 0; int trunk = 0; int x = 0; int y = 0; int z = 0;
    int leafPal = 0;
    st = prng.seed_from(spec.seed);
    parts = [];
    trunk = prism_prims.lathe([0.16, 0.0, 0.12, 0.55, 0.09, 1.0], 10, true, false);
    trunk = prism_prims.place(proj(trunk, "keep"), nil, nil, nil);
    parts[0] = P(trunk, "bark", nil, "bark|");
    leafPal = prim_pal(spec, "leaf");
    for (i = 0; i < 4; ++i) {
        r = prng.uniform(st, 0.30, 0.46); st = r[1];
        c = mesh.icosphere(r[0], 2);
        if (spec.style == "lowpoly") { c = prism_prims.flat_shaded(c); }
        r = prng.uniform(st, 0.0 - 0.30, 0.30); st = r[1]; x = r[0];
        r = prng.uniform(st, 0.0 - 0.30, 0.30); st = r[1]; z = r[0];
        r = prng.uniform(st, 1.0, 1.45); st = r[1]; y = r[0];
        c = prism_prims.place(proj(c, "sphere"), [x, y, z], nil, nil);
        parts[i + 1] = P(c, "leaf", leafPal, "leaf|" + spec.colorName);
    }
    return parts;
}

fn r_pine(spec) {
    int c = 0; int i = 0; int parts = 0; int trunk = 0; int y = 0; int rr = 0;
    parts = [];
    trunk = prism_prims.capped_cylinder(0.10, 0.5, 8);
    trunk = prism_prims.place(proj(trunk, "keep"), [0.0, 0.25, 0.0], nil, nil);
    parts[0] = P(trunk, "bark", nil, "bark|");
    y = 0.55; rr = 0.55;
    for (i = 0; i < 3; ++i) {
        c = prism_prims.cone(rr, 0.62, 12);
        if (spec.style == "lowpoly") { c = prism_prims.flat_shaded(c); }
        c = prism_prims.place(proj(c, "keep"), [0.0, y + 0.31, 0.0], nil, nil);
        parts[i + 1] = P(c, "leaf", prim_pal(spec, "leaf"), "leaf|" + spec.colorName);
        y = y + 0.40;
        rr = rr * 0.74;
    }
    return parts;
}

fn r_rock(spec) {
    int m = 0;
    m = prism_prims.displaced_sphere(0.8, 3, 0.42, 1.6, spec.seed);
    if (spec.style == "lowpoly") { m = prism_prims.flat_shaded(prism_prims.displaced_sphere(0.8, 2, 0.42, 1.6, spec.seed)); }
    m = mesh.transform_mesh(m, mat4.scaling(1.15, 0.8, 1.0));
    m = prism_prims.place(proj(m, "sphere"), [0.0, 0.62, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "stone"), prim_pal(spec, "stone"), prim_key(spec, "stone"))];
}

fn jagged_profile(seed, baseR, h, steps) {
    int i = 0; int p = 0; int r = 0; int st = 0; int t = 0;
    st = prng.seed_from(seed);
    p = [];
    for (i = 0; i <= steps; ++i) {
        t = i * 1.0 / steps;
        r = prng.uniform(st, 0.78, 1.22); st = r[1];
        p[i * 2] = baseR * (1.0 - t * 0.92) * r[0];
        p[i * 2 + 1] = h * t;
    }
    p[steps * 2] = 0.0;
    return p;
}

fn r_mountain(spec) {
    int cap = 0; int m = 0; int parts = 0;
    parts = [];
    m = prism_prims.lathe(jagged_profile(spec.seed, 1.1, 1.7, 7), 9, true, false);
    m = prism_prims.flat_shaded(m);
    m = prism_prims.place(proj(m, "cyl"), nil, nil, nil);
    parts[0] = P(m, prim_kind(spec, "stone"), prim_pal(spec, "stone"), prim_key(spec, "stone"));
    cap = prism_prims.lathe(jagged_profile(spec.seed + 5, 0.40, 0.62, 4), 9, false, false);
    cap = prism_prims.flat_shaded(cap);
    cap = prism_prims.place(proj(cap, "cyl"), [0.0, 1.06, 0.0], nil, nil);
    parts[1] = P(cap, "snow", nil, "snow|");
    return parts;
}

fn r_volcano(spec) {
    int lava = 0; int m = 0; int parts = 0;
    parts = [];
    m = prism_prims.lathe([1.2, 0.0, 0.95, 0.35, 0.55, 1.1, 0.42, 1.25], 12, true, false);
    m = prism_prims.flat_shaded(m);
    m = prism_prims.place(proj(m, "cyl"), nil, nil, nil);
    parts[0] = P(m, prim_kind(spec, "stone"), prim_pal(spec, "stone"), prim_key(spec, "stone"));
    lava = prism_prims.disc(0.40, 12);
    lava = prism_prims.place(proj(lava, "keep"), [0.0, 1.26, 0.0], nil, nil);
    parts[1] = P(lava, "lava", nil, "lava|");
    return parts;
}

fn r_planet(spec) {
    int m = 0; int parts = 0; int pal = 0; int ringm = 0;
    parts = [];
    m = proj(mesh.uv_sphere(0.85, 30, 20), "sphere");
    m = prism_prims.place(m, [0.0, 1.0, 0.0], nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.06,0.15,0.40],[0.10,0.35,0.60],[0.16,0.50,0.30],[0.55,0.48,0.30],[0.92,0.94,0.96]]; }
    parts[0] = P(m, "plain", pal, "planet|" + spec.colorName);
    ringm = mesh.torus(1.22, 0.10, 36, 8);
    ringm = mesh.transform_mesh(ringm, mat4.scaling(1.0, 0.22, 1.0));
    ringm = prism_prims.place(proj(ringm, "cyl"), [0.0, 1.0, 0.0], [0.18, 0.0, 0.0], nil);
    parts[1] = P(ringm, "sand", nil, "ring|");
    return parts;
}

fn r_moon(spec) {
    int m = 0;
    m = prism_prims.displaced_sphere(0.85, 3, 0.10, 2.2, spec.seed);
    m = prism_prims.place(proj(m, "sphere"), [0.0, 1.0, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "stone"), prim_pal(spec, "stone"), prim_key(spec, "stone"))];
}

fn r_mushroom(spec) {
    int cap = 0; int parts = 0; int stem = 0; int capPal = 0;
    parts = [];
    stem = prism_prims.lathe([0.16, 0.0, 0.13, 0.5, 0.17, 0.62], 12, true, false);
    stem = prism_prims.place(proj(stem, "keep"), nil, nil, nil);
    parts[0] = P(stem, "plain", [[0.78,0.72,0.62],[0.88,0.84,0.75],[0.94,0.91,0.85]], "shroomstem|");
    cap = prism_prims.lathe([0.02, 0.0, 0.52, 0.05, 0.44, 0.28, 0.02, 0.42], 16, false, false);
    cap = prism_prims.place(proj(cap, "cyl"), [0.0, 0.58, 0.0], nil, nil);
    capPal = prim_pal(spec, "__color__");
    if (capPal == nil) { capPal = [[0.55,0.06,0.05],[0.78,0.10,0.08],[0.92,0.25,0.15]]; }
    parts[1] = P(cap, "plain", capPal, "shroomcap|" + spec.colorName);
    return parts;
}

# ---- vehicles & objects -----------------------------------------------------------

fn r_rocket(spec) {
    int body = 0; int eng = 0; int fin = 0; int i = 0; int nose = 0; int parts = 0; int a = 0;
    int k = 0; int pal = 0; int key = 0; int fm = 0;
    k = prim_kind(spec, "metal"); pal = prim_pal(spec, "metal"); key = prim_key(spec, "metal");
    parts = [];
    body = prism_prims.capped_cylinder(0.34, 1.5, 18);
    body = prism_prims.place(proj(body, "keep"), [0.0, 1.05, 0.0], nil, nil);
    parts[0] = P(body, k, pal, key);
    nose = prism_prims.cone(0.34, 0.62, 18);
    nose = prism_prims.place(proj(nose, "keep"), [0.0, 2.11, 0.0], nil, nil);
    parts[1] = P(nose, "plain", [[0.55,0.06,0.05],[0.80,0.10,0.08],[0.94,0.30,0.20]], "nose|");
    eng = prism_prims.frustum(0.30, 0.20, 0.30, 14);
    eng = prism_prims.place(proj(eng, "keep"), [0.0, 0.30, 0.0], nil, nil);
    parts[2] = P(eng, "metal", [[0.16,0.16,0.18],[0.30,0.30,0.33],[0.46,0.46,0.50]], "engine|");
    for (i = 0; i < 3; ++i) {
        a = 6.2832 * i / 3.0;
        fin = prism_prims.extrude([0.0, 0.0, 0.42, 0.0 - 0.28, 0.42, 0.30, 0.06, 0.55], 0.05);
        fin = mesh.transform_mesh(fin, mat4.rot_y(a + 1.5708));
        fin = prism_prims.place(proj(fin, "box"), [0.30 * cos(a), 0.62, 0.30 * sin(a)], nil, nil);
        parts[3 + i] = P(fin, "plain", [[0.55,0.06,0.05],[0.80,0.10,0.08],[0.94,0.30,0.20]], "nose|");
    }
    return parts;
}

fn r_boat(spec) {
    int hull = 0; int mast = 0; int parts = 0; int sail = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "wood"); pal = prim_pal(spec, "wood"); key = prim_key(spec, "wood");
    parts = [];
    # hull: lathe half-sunk ellipsoid squashed on Z, open top via profile
    hull = prism_prims.lathe([0.10, 0.0, 0.72, 0.32, 0.80, 0.55], 16, true, false);
    hull = mesh.transform_mesh(hull, mat4.scaling(1.35, 0.9, 0.62));
    hull = prism_prims.place(proj(hull, "cyl"), nil, nil, nil);
    parts[0] = P(hull, k, pal, key);
    mast = prism_prims.capped_cylinder(0.045, 1.4, 8);
    mast = prism_prims.place(proj(mast, "keep"), [0.0, 1.15, 0.0], nil, nil);
    parts[1] = P(mast, "wood", nil, "mast|wood");
    sail = prism_prims.extrude([0.0, 0.0, 0.62, 0.0, 0.0, 0.95], 0.03);
    sail = prism_prims.place(proj(sail, "planar"), [0.06, 0.78, 0.0], [0.0, 1.5708, 0.0], nil);
    parts[2] = P(sail, "fabric", [[0.88,0.86,0.80],[0.94,0.93,0.89],[1.0,1.0,0.97]], "sail|");
    return parts;
}

fn r_car(spec) {
    int body = 0; int cab = 0; int i = 0; int parts = 0; int wheel = 0; int x = 0; int z = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "plain");
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.45,0.05,0.05],[0.70,0.08,0.08],[0.88,0.22,0.18]]; }
    key = "carbody|" + spec.colorName;
    parts = [];
    body = prism_prims.box(1.7, 0.42, 0.8);
    body = prism_prims.place(proj(body, "box"), [0.0, 0.42, 0.0], nil, nil);
    parts[0] = P(body, k, pal, key);
    cab = prism_prims.box(0.85, 0.38, 0.72);
    cab = prism_prims.place(proj(cab, "box"), [0.0 - 0.10, 0.80, 0.0], nil, nil);
    parts[1] = P(cab, "glass", nil, "glass|");
    for (i = 0; i < 4; ++i) {
        x = 0.55; z = 0.42;
        if (i == 1 || i == 3) { x = 0.0 - 0.55; }
        if (i >= 2) { z = 0.0 - 0.42; }
        wheel = prism_prims.capped_cylinder(0.21, 0.14, 14);
        wheel = mesh.transform_mesh(wheel, mat4.rot_x(1.5708));
        wheel = prism_prims.place(proj(wheel, "cyl"), [x, 0.21, z], nil, nil);
        parts[2 + i] = P(wheel, "plain", [[0.06,0.06,0.07],[0.13,0.13,0.15],[0.22,0.22,0.24]], "tire|");
    }
    return parts;
}

fn r_table(spec) {
    int i = 0; int leg = 0; int parts = 0; int top = 0; int x = 0; int z = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "wood"); pal = prim_pal(spec, "wood"); key = prim_key(spec, "wood");
    parts = [];
    top = prism_prims.box(1.6, 0.10, 1.0);
    top = prism_prims.place(proj(top, "box"), [0.0, 0.85, 0.0], nil, nil);
    parts[0] = P(top, k, pal, key);
    for (i = 0; i < 4; ++i) {
        x = 0.68; z = 0.38;
        if (i == 1 || i == 3) { x = 0.0 - 0.68; }
        if (i >= 2) { z = 0.0 - 0.38; }
        leg = prism_prims.box(0.10, 0.80, 0.10);
        leg = prism_prims.place(proj(leg, "box"), [x, 0.40, z], nil, nil);
        parts[1 + i] = P(leg, k, pal, key);
    }
    return parts;
}

fn r_chair(spec) {
    int back = 0; int i = 0; int leg = 0; int parts = 0; int seat = 0; int x = 0; int z = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "wood"); pal = prim_pal(spec, "wood"); key = prim_key(spec, "wood");
    parts = [];
    seat = prism_prims.box(0.78, 0.09, 0.78);
    seat = prism_prims.place(proj(seat, "box"), [0.0, 0.55, 0.0], nil, nil);
    parts[0] = P(seat, k, pal, key);
    back = prism_prims.box(0.78, 0.85, 0.09);
    back = prism_prims.place(proj(back, "box"), [0.0, 1.0, 0.0 - 0.345], nil, nil);
    parts[1] = P(back, k, pal, key);
    for (i = 0; i < 4; ++i) {
        x = 0.31; z = 0.31;
        if (i == 1 || i == 3) { x = 0.0 - 0.31; }
        if (i >= 2) { z = 0.0 - 0.31; }
        leg = prism_prims.box(0.09, 0.52, 0.09);
        leg = prism_prims.place(proj(leg, "box"), [x, 0.26, z], nil, nil);
        parts[2 + i] = P(leg, k, pal, key);
    }
    return parts;
}

fn r_mug(spec) {
    int body = 0; int handle = 0; int parts = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "plain");
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.10,0.25,0.45],[0.16,0.38,0.62],[0.30,0.55,0.78]]; }
    key = "mug|" + spec.colorName;
    parts = [];
    body = prism_prims.lathe([0.42, 0.0, 0.46, 0.05, 0.46, 0.85, 0.40, 0.85, 0.40, 0.08, 0.0, 0.08], 20, true, false);
    body = prism_prims.place(proj(body, "cyl"), nil, nil, nil);
    parts[0] = P(body, k, pal, key);
    handle = mesh.torus(0.24, 0.055, 18, 10);
    handle = prism_prims.place(proj(handle, "cyl"), [0.55, 0.44, 0.0], nil, nil);
    parts[1] = P(handle, k, pal, key);
    return parts;
}

fn r_bottle(spec) {
    int m = 0; int pal = 0;
    m = prism_prims.lathe([0.30, 0.0, 0.34, 0.08, 0.34, 0.75, 0.24, 0.95, 0.10, 1.05, 0.10, 1.30, 0.13, 1.34, 0.13, 1.42, 0.0, 1.42], 20, true, true);
    m = prism_prims.place(proj(m, "cyl"), nil, nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.05,0.28,0.12],[0.10,0.45,0.20],[0.30,0.68,0.38]]; }
    return [P(m, prim_kind(spec, "glass"), pal, "bottle|" + spec.colorName)];
}

fn r_vase(spec) {
    int m = 0;
    m = prism_prims.lathe([0.26, 0.0, 0.38, 0.10, 0.52, 0.42, 0.40, 0.85, 0.22, 1.05, 0.26, 1.25, 0.34, 1.38], 22, true, false);
    m = maybe_facet(spec, m);
    m = prism_prims.place(proj(m, "cyl"), nil, nil, nil);
    return [P(m, prim_kind(spec, "marble"), prim_pal(spec, "marble"), prim_key(spec, "marble"))];
}

fn r_lamp(spec) {
    int base = 0; int parts = 0; int shade = 0; int stem = 0; int bulb = 0;
    parts = [];
    base = prism_prims.lathe([0.42, 0.0, 0.40, 0.07, 0.12, 0.12], 16, true, false);
    base = prism_prims.place(proj(base, "cyl"), nil, nil, nil);
    parts[0] = P(base, prim_kind(spec, "metal"), prim_pal(spec, "metal"), prim_key(spec, "metal"));
    stem = prism_prims.capped_cylinder(0.05, 0.95, 10);
    stem = prism_prims.place(proj(stem, "keep"), [0.0, 0.58, 0.0], nil, nil);
    parts[1] = P(stem, prim_kind(spec, "metal"), prim_pal(spec, "metal"), prim_key(spec, "metal"));
    shade = prism_prims.frustum(0.45, 0.28, 0.45, 18);
    shade = prism_prims.place(proj(shade, "keep"), [0.0, 1.22, 0.0], nil, nil);
    parts[2] = P(shade, "fabric", [[0.85,0.66,0.30],[0.93,0.78,0.42],[0.98,0.88,0.58]], "shade|");
    bulb = mesh.uv_sphere(0.12, 12, 8);
    bulb = prism_prims.place(proj(bulb, "sphere"), [0.0, 1.02, 0.0], nil, nil);
    parts[3] = P(bulb, "snow", nil, "bulb|");
    return parts;
}

fn r_sword(spec) {
    int blade = 0; int grip = 0; int guard = 0; int parts = 0; int pommel = 0;
    parts = [];
    blade = prism_prims.extrude([0.0, 0.0, 0.08, 0.10, 0.08, 1.35, 0.0, 1.52, 0.0 - 0.08, 1.35, 0.0 - 0.08, 0.10], 0.035);
    blade = prism_prims.place(proj(blade, "planar"), [0.0, 0.42, 0.0], nil, nil);
    parts[0] = P(blade, prim_kind(spec, "metal"), prim_pal(spec, "metal"), prim_key(spec, "metal"));
    guard = prism_prims.box(0.44, 0.07, 0.09);
    guard = prism_prims.place(proj(guard, "box"), [0.0, 0.42, 0.0], nil, nil);
    parts[1] = P(guard, "gold", nil, "gold|");
    grip = prism_prims.capped_cylinder(0.045, 0.34, 10);
    grip = prism_prims.place(proj(grip, "keep"), [0.0, 0.22, 0.0], nil, nil);
    parts[2] = P(grip, "wood", [[0.20,0.10,0.06],[0.32,0.17,0.10],[0.45,0.26,0.16]], "grip|");
    pommel = mesh.uv_sphere(0.07, 10, 8);
    pommel = prism_prims.place(proj(pommel, "sphere"), [0.0, 0.03, 0.0], nil, nil);
    parts[3] = P(pommel, "gold", nil, "gold|");
    return parts;
}

fn r_shield(spec) {
    int boss = 0; int face = 0; int parts = 0; int i = 0; int a = 0; int poly = 0; int n = 0;
    parts = [];
    n = 18;
    poly = [];
    for (i = 0; i < n; ++i) {
        a = 6.2832 * i / n;
        poly[i * 2] = 0.72 * cos(a);
        poly[i * 2 + 1] = 0.85 * sin(a);
    }
    face = prism_prims.extrude(poly, 0.09);
    face = prism_prims.place(proj(face, "keep"), [0.0, 0.9, 0.0], nil, nil);
    parts[0] = P(face, prim_kind(spec, "wood"), prim_pal(spec, "wood"), prim_key(spec, "wood"));
    boss = mesh.uv_sphere(0.20, 14, 10);
    boss = mesh.transform_mesh(boss, mat4.scaling(1.0, 1.0, 0.5));
    boss = prism_prims.place(proj(boss, "sphere"), [0.0, 0.9, 0.07], nil, nil);
    parts[1] = P(boss, "metal", nil, "boss|");
    return parts;
}

fn r_snowman(spec) {
    int b1 = 0; int b2 = 0; int b3 = 0; int brim = 0; int eye = 0; int hat = 0; int nose = 0; int parts = 0;
    parts = [];
    b1 = prism_prims.place(proj(mesh.uv_sphere(0.55, 20, 14), "sphere"), [0.0, 0.5, 0.0], nil, nil);
    b2 = prism_prims.place(proj(mesh.uv_sphere(0.40, 18, 12), "sphere"), [0.0, 1.18, 0.0], nil, nil);
    b3 = prism_prims.place(proj(mesh.uv_sphere(0.28, 16, 12), "sphere"), [0.0, 1.70, 0.0], nil, nil);
    parts[0] = P(b1, "snow", nil, "snow|");
    parts[1] = P(b2, "snow", nil, "snow|");
    parts[2] = P(b3, "snow", nil, "snow|");
    nose = prism_prims.cone(0.055, 0.28, 8);
    nose = prism_prims.place(proj(nose, "keep"), [0.0, 1.72, 0.34], [1.5708, 0.0, 0.0], nil);
    parts[3] = P(nose, "plain", [[0.75,0.32,0.05],[0.90,0.45,0.08],[1.0,0.60,0.18]], "carrot|");
    eye = prism_prims.place(proj(mesh.uv_sphere(0.035, 8, 6), "sphere"), [0.10, 1.78, 0.25], nil, nil);
    parts[4] = P(eye, "plain", [[0.04,0.04,0.05],[0.08,0.08,0.09],[0.15,0.15,0.16]], "coal|");
    eye = prism_prims.place(proj(mesh.uv_sphere(0.035, 8, 6), "sphere"), [0.0 - 0.10, 1.78, 0.25], nil, nil);
    parts[5] = P(eye, "plain", [[0.04,0.04,0.05],[0.08,0.08,0.09],[0.15,0.15,0.16]], "coal|");
    brim = prism_prims.capped_cylinder(0.26, 0.03, 14);
    brim = prism_prims.place(proj(brim, "keep"), [0.0, 1.93, 0.0], nil, nil);
    hat = prism_prims.capped_cylinder(0.17, 0.28, 14);
    hat = prism_prims.place(proj(hat, "keep"), [0.0, 2.08, 0.0], nil, nil);
    parts[6] = P(brim, "fabric", [[0.05,0.05,0.06],[0.10,0.10,0.12],[0.18,0.18,0.20]], "hat|");
    parts[7] = P(hat, "fabric", [[0.05,0.05,0.06],[0.10,0.10,0.12],[0.18,0.18,0.20]], "hat|");
    return parts;
}

fn r_robot(spec) {
    int antenna = 0; int arm = 0; int body = 0; int eye = 0; int head = 0; int i = 0; int leg = 0;
    int parts = 0; int x = 0; int tip = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "metal"); pal = prim_pal(spec, "metal"); key = prim_key(spec, "metal");
    parts = [];
    body = prism_prims.box(0.8, 0.95, 0.5);
    body = prism_prims.place(proj(body, "box"), [0.0, 1.02, 0.0], nil, nil);
    parts[0] = P(body, k, pal, key);
    head = prism_prims.box(0.5, 0.42, 0.42);
    head = prism_prims.place(proj(head, "box"), [0.0, 1.75, 0.0], nil, nil);
    parts[1] = P(head, k, pal, key);
    for (i = 0; i < 2; ++i) {
        x = 0.24; if (i == 1) { x = 0.0 - 0.24; }
        eye = prism_prims.place(proj(mesh.uv_sphere(0.06, 8, 6), "sphere"), [x * 0.5, 1.80, 0.22], nil, nil);
        parts[len(parts)] = P(eye, "crystal", [[0.05,0.35,0.45],[0.10,0.60,0.75],[0.45,0.90,1.0]], "eye|");
        arm = prism_prims.capped_cylinder(0.09, 0.85, 10);
        arm = prism_prims.place(proj(arm, "keep"), [x * 2.2, 1.05, 0.0], nil, nil);
        parts[len(parts)] = P(arm, k, pal, key);
        leg = prism_prims.capped_cylinder(0.12, 0.55, 10);
        leg = prism_prims.place(proj(leg, "keep"), [x, 0.28, 0.0], nil, nil);
        parts[len(parts)] = P(leg, k, pal, key);
    }
    antenna = prism_prims.capped_cylinder(0.025, 0.28, 6);
    antenna = prism_prims.place(proj(antenna, "keep"), [0.0, 2.10, 0.0], nil, nil);
    parts[len(parts)] = P(antenna, k, pal, key);
    tip = prism_prims.place(proj(mesh.uv_sphere(0.05, 8, 6), "sphere"), [0.0, 2.26, 0.0], nil, nil);
    parts[len(parts)] = P(tip, "plain", [[0.55,0.06,0.05],[0.80,0.10,0.08],[0.94,0.30,0.20]], "tip|");
    return parts;
}

fn r_barrel(spec) {
    int band = 0; int body = 0; int parts = 0;
    parts = [];
    body = prism_prims.lathe([0.38, 0.0, 0.50, 0.30, 0.53, 0.55, 0.50, 0.80, 0.38, 1.1], 16, true, true);
    body = prism_prims.place(proj(body, "cyl"), nil, nil, nil);
    parts[0] = P(body, prim_kind(spec, "wood"), prim_pal(spec, "wood"), prim_key(spec, "wood"));
    band = mesh.torus(0.51, 0.035, 20, 8);
    band = prism_prims.place(proj(band, "cyl"), [0.0, 0.30, 0.0], nil, nil);
    parts[1] = P(band, "metal", nil, "band|");
    band = mesh.torus(0.51, 0.035, 20, 8);
    band = prism_prims.place(proj(band, "cyl"), [0.0, 0.80, 0.0], nil, nil);
    parts[2] = P(band, "metal", nil, "band|");
    return parts;
}

fn r_coin(spec) {
    int m = 0;
    m = prism_prims.capped_cylinder(0.75, 0.12, 28);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.38, 0.0], [0.35, 0.0, 0.0], nil);
    return [P(m, prim_kind(spec, "gold"), prim_pal(spec, "gold"), prim_key(spec, "gold"))];
}

fn r_dice(spec) {
    int m = 0;
    m = proj(prism_prims.box(1.1, 1.1, 1.1), "box");
    m = prism_prims.place(m, [0.0, 0.55, 0.0], [0.0, 0.6, 0.0], nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_crown(spec) {
    int band = 0; int i = 0; int parts = 0; int spike = 0; int a = 0; int gemp = 0;
    parts = [];
    band = prism_prims.lathe([0.62, 0.0, 0.62, 0.35], 16, false, false);
    band = prism_prims.place(proj(band, "keep"), [0.0, 0.3, 0.0], nil, nil);
    parts[0] = P(band, prim_kind(spec, "gold"), prim_pal(spec, "gold"), prim_key(spec, "gold"));
    for (i = 0; i < 6; ++i) {
        a = 6.2832 * i / 6.0;
        spike = prism_prims.cone(0.14, 0.42, 8);
        spike = prism_prims.place(proj(spike, "keep"), [0.58 * cos(a), 0.82, 0.58 * sin(a)], nil, nil);
        parts[1 + i] = P(spike, prim_kind(spec, "gold"), prim_pal(spec, "gold"), prim_key(spec, "gold"));
    }
    gemp = prism_prims.gem(0.14, 0.24, 6);
    gemp = prism_prims.place(proj(gemp, "cyl"), [0.0, 0.44, 0.64], [1.5708, 0.0, 0.0], nil);
    parts[7] = P(gemp, "crystal", [[0.45,0.03,0.10],[0.70,0.06,0.16],[0.95,0.30,0.40]], "crownjewel|");
    return parts;
}

fn r_pawn(spec) {
    int m = 0;
    m = prism_prims.lathe([0.40, 0.0, 0.42, 0.08, 0.30, 0.14, 0.14, 0.35, 0.11, 0.72, 0.20, 0.80, 0.11, 0.88, 0.22, 1.02, 0.16, 1.16, 0.0, 1.24], 20, true, false);
    m = maybe_facet(spec, m);
    m = prism_prims.place(proj(m, "cyl"), nil, nil, nil);
    return [P(m, prim_kind(spec, "marble"), prim_pal(spec, "marble"), prim_key(spec, "marble"))];
}

fn heart_poly(n) {
    int a = 0; int i = 0; int p = 0; int t = 0; int x = 0; int y = 0;
    p = [];
    for (i = 0; i < n; ++i) {
        t = 6.2832 * i / n;
        x = 0.05 * 16.0 * sin(t) * sin(t) * sin(t);
        y = 0.05 * (13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t));
        p[i * 2] = x;
        p[i * 2 + 1] = y;
    }
    return p;
}

fn r_heart(spec) {
    int m = 0; int pal = 0;
    m = prism_prims.extrude(heart_poly(40), 0.34);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.85, 0.0], nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.52,0.03,0.08],[0.78,0.06,0.12],[0.95,0.25,0.30]]; }
    return [P(m, prim_kind(spec, "plain"), pal, "heart|" + spec.colorName)];
}

fn star_poly(points, rOut, rIn) {
    int a = 0; int i = 0; int p = 0; int r = 0;
    p = [];
    for (i = 0; i < points * 2; ++i) {
        r = rOut; if (i % 2 == 1) { r = rIn; }
        a = 3.14159 * i / points + 1.5708;
        p[i * 2] = r * cos(a);
        p[i * 2 + 1] = r * sin(a);
    }
    return p;
}

fn r_star(spec) {
    int m = 0; int pal = 0;
    m = prism_prims.extrude(star_poly(5, 0.85, 0.36), 0.22);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.9, 0.0], nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.70,0.48,0.05],[0.92,0.72,0.10],[1.0,0.90,0.40]]; }
    return [P(m, prim_kind(spec, "gold"), pal, "star|" + spec.colorName)];
}

fn gear_poly(teeth, rOut, rIn) {
    int a = 0; int hw = 0; int i = 0; int p = 0; int step = 0;
    p = [];
    step = 6.2832 / teeth;
    hw = step * 0.24;
    for (i = 0; i < teeth; ++i) {
        a = step * i;
        p = p + [rIn * cos(a - step * 0.5 + hw), rIn * sin(a - step * 0.5 + hw)];
        p = p + [rIn * cos(a - hw), rIn * sin(a - hw)];
        p = p + [rOut * cos(a - hw * 0.7), rOut * sin(a - hw * 0.7)];
        p = p + [rOut * cos(a + hw * 0.7), rOut * sin(a + hw * 0.7)];
    }
    return p;
}

fn r_gear(spec) {
    int hub = 0; int m = 0; int parts = 0;
    parts = [];
    m = prism_prims.extrude(gear_poly(10, 0.85, 0.66), 0.18);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.85, 0.0], nil, nil);
    parts[0] = P(m, prim_kind(spec, "metal"), prim_pal(spec, "metal"), prim_key(spec, "metal"));
    hub = prism_prims.capped_cylinder(0.16, 0.26, 12);
    hub = prism_prims.place(proj(hub, "keep"), [0.0, 0.85, 0.0], [1.5708, 0.0, 0.0], nil);
    parts[1] = P(hub, prim_kind(spec, "metal"), prim_pal(spec, "metal"), prim_key(spec, "metal"));
    return parts;
}

fn r_arrow(spec) {
    int m = 0;
    m = prism_prims.extrude([0.0 - 0.14, 0.0, 0.14, 0.0, 0.14, 0.75, 0.34, 0.75, 0.0, 1.25, 0.0 - 0.34, 0.75, 0.0 - 0.14, 0.75], 0.14);
    m = prism_prims.place(proj(m, "keep"), [0.0, 0.62, 0.0], nil, nil);
    return [P(m, prim_kind(spec, "plain"), prim_pal(spec, "plain"), prim_key(spec, "plain"))];
}

fn r_tent(spec) {
    int m = 0; int parts = 0; int pole = 0; int pal = 0;
    parts = [];
    m = prism_prims.extrude([0.0 - 0.85, 0.0, 0.85, 0.0, 0.0, 1.1], 1.5);
    m = prism_prims.place(proj(m, "box"), nil, nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.55,0.28,0.06],[0.75,0.42,0.10],[0.88,0.58,0.22]]; }
    parts[0] = P(m, prim_kind(spec, "fabric"), pal, "tent|" + spec.colorName);
    pole = prism_prims.capped_cylinder(0.04, 1.15, 8);
    pole = prism_prims.place(proj(pole, "keep"), [0.0, 0.55, 0.80], nil, nil);
    parts[1] = P(pole, "wood", nil, "pole|");
    return parts;
}

fn r_bridge(spec) {
    int deck = 0; int i = 0; int parts = 0; int post = 0; int rail = 0; int x = 0; int s = 0;
    int k = 0; int pal = 0; int key = 0;
    k = prim_kind(spec, "wood"); pal = prim_pal(spec, "wood"); key = prim_key(spec, "wood");
    parts = [];
    deck = prism_prims.box(2.2, 0.12, 0.8);
    deck = prism_prims.place(proj(deck, "box"), [0.0, 0.55, 0.0], nil, nil);
    parts[0] = P(deck, k, pal, key);
    for (i = 0; i < 6; ++i) {
        x = 0.0 - 1.0 + 0.4 * i;
        s = 0.34; if (i % 2 == 1) { s = 0.0 - 0.34; }
        post = prism_prims.box(0.08, 0.5, 0.08);
        post = prism_prims.place(proj(post, "box"), [x, 0.85, s], nil, nil);
        parts[len(parts)] = P(post, k, pal, key);
    }
    rail = prism_prims.box(2.2, 0.07, 0.07);
    rail = prism_prims.place(proj(rail, "box"), [0.0, 1.1, 0.34], nil, nil);
    parts[len(parts)] = P(rail, k, pal, key);
    rail = prism_prims.box(2.2, 0.07, 0.07);
    rail = prism_prims.place(proj(rail, "box"), [0.0, 1.1, 0.0 - 0.34], nil, nil);
    parts[len(parts)] = P(rail, k, pal, key);
    return parts;
}

fn r_well(spec) {
    int bucketp = 0; int parts = 0; int post = 0; int roof = 0; int wall = 0; int beam = 0;
    parts = [];
    wall = prism_prims.lathe([0.55, 0.0, 0.55, 0.55, 0.46, 0.55, 0.46, 0.05, 0.0, 0.05], 14, false, false);
    wall = prism_prims.place(proj(wall, "cyl"), nil, nil, nil);
    parts[0] = P(wall, prim_kind(spec, "stone"), prim_pal(spec, "stone"), prim_key(spec, "stone"));
    post = prism_prims.box(0.09, 1.0, 0.09);
    post = prism_prims.place(proj(post, "box"), [0.48, 1.0, 0.0], nil, nil);
    parts[1] = P(post, "wood", nil, "wood|");
    post = prism_prims.box(0.09, 1.0, 0.09);
    post = prism_prims.place(proj(post, "box"), [0.0 - 0.48, 1.0, 0.0], nil, nil);
    parts[2] = P(post, "wood", nil, "wood|");
    beam = prism_prims.capped_cylinder(0.05, 1.05, 8);
    beam = mesh.transform_mesh(beam, mat4.rot_z(1.5708));
    beam = prism_prims.place(proj(beam, "cyl"), [0.0, 1.35, 0.0], nil, nil);
    parts[3] = P(beam, "wood", nil, "wood|");
    roof = roof_prism(1.3, 1.0, 0.45);
    roof = prism_prims.place(proj(roof, "box"), [0.0, 1.55, 0.0], nil, nil);
    parts[4] = P(roof, "roof", nil, "roof|");
    bucketp = prism_prims.lathe([0.10, 0.0, 0.13, 0.16], 10, true, false);
    bucketp = prism_prims.place(proj(bucketp, "cyl"), [0.0, 0.9, 0.0], nil, nil);
    parts[5] = P(bucketp, "wood", nil, "wood|");
    return parts;
}

fn r_candle(spec) {
    int body = 0; int flame = 0; int parts = 0; int wick = 0; int pal = 0;
    parts = [];
    body = prism_prims.lathe([0.24, 0.0, 0.24, 0.9, 0.20, 0.9, 0.20, 0.82, 0.0, 0.82], 14, true, false);
    body = prism_prims.place(proj(body, "cyl"), nil, nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.85,0.80,0.68],[0.93,0.89,0.78],[0.98,0.96,0.90]]; }
    parts[0] = P(body, prim_kind(spec, "plain"), pal, "candle|" + spec.colorName);
    wick = prism_prims.capped_cylinder(0.02, 0.10, 6);
    wick = prism_prims.place(proj(wick, "keep"), [0.0, 0.87, 0.0], nil, nil);
    parts[1] = P(wick, "plain", [[0.06,0.05,0.04],[0.12,0.10,0.08],[0.2,0.18,0.15]], "wick|");
    flame = mesh.uv_sphere(0.09, 10, 8);
    flame = mesh.transform_mesh(flame, mat4.scaling(1.0, 1.7, 1.0));
    flame = prism_prims.place(proj(flame, "sphere"), [0.0, 1.05, 0.0], nil, nil);
    parts[2] = P(flame, "lava", nil, "flame|");
    return parts;
}

fn r_abstract(spec) {
    int m = 0; int pal = 0;
    m = prism_prims.displaced_sphere(0.85, 3, 0.5, 1.3, spec.seed);
    if (spec.style == "lowpoly") { m = prism_prims.flat_shaded(prism_prims.displaced_sphere(0.85, 2, 0.5, 1.3, spec.seed)); }
    m = prism_prims.place(proj(m, "sphere"), [0.0, 0.9, 0.0], nil, nil);
    pal = prim_pal(spec, "__color__");
    if (pal == nil) { pal = [[0.16,0.10,0.42],[0.40,0.15,0.55],[0.80,0.35,0.45],[0.98,0.72,0.35]]; }
    return [P(m, prim_kind(spec, "plain"), pal, "abstract|" + spec.colorName)];
}

# ---- dispatch -------------------------------------------------------------------

fn build(spec) {
    int s = 0;
    s = spec.shape;
    if (s == "cube") { return r_cube(spec); }
    if (s == "sphere") { return r_sphere(spec); }
    if (s == "cylinder") { return r_cylinder(spec); }
    if (s == "cone") { return r_cone(spec); }
    if (s == "pyramid") { return r_pyramid(spec); }
    if (s == "torus") { return r_torus(spec); }
    if (s == "ring") { return r_ring(spec); }
    if (s == "gem") { return r_gem(spec); }
    if (s == "crystal_shape") { return r_crystal_shape(spec); }
    if (s == "house") { return r_house(spec); }
    if (s == "tower") { return r_tower(spec); }
    if (s == "castle") { return r_castle(spec); }
    if (s == "tree") { return r_tree(spec); }
    if (s == "pine") { return r_pine(spec); }
    if (s == "rock") { return r_rock(spec); }
    if (s == "mountain") { return r_mountain(spec); }
    if (s == "volcano") { return r_volcano(spec); }
    if (s == "planet") { return r_planet(spec); }
    if (s == "moon") { return r_moon(spec); }
    if (s == "mushroom") { return r_mushroom(spec); }
    if (s == "rocket") { return r_rocket(spec); }
    if (s == "boat") { return r_boat(spec); }
    if (s == "car") { return r_car(spec); }
    if (s == "table") { return r_table(spec); }
    if (s == "chair") { return r_chair(spec); }
    if (s == "mug") { return r_mug(spec); }
    if (s == "bottle") { return r_bottle(spec); }
    if (s == "vase") { return r_vase(spec); }
    if (s == "lamp") { return r_lamp(spec); }
    if (s == "sword") { return r_sword(spec); }
    if (s == "shield") { return r_shield(spec); }
    if (s == "snowman") { return r_snowman(spec); }
    if (s == "robot") { return r_robot(spec); }
    if (s == "barrel") { return r_barrel(spec); }
    if (s == "coin") { return r_coin(spec); }
    if (s == "dice") { return r_dice(spec); }
    if (s == "crown") { return r_crown(spec); }
    if (s == "pawn") { return r_pawn(spec); }
    if (s == "heart") { return r_heart(spec); }
    if (s == "star") { return r_star(spec); }
    if (s == "gear") { return r_gear(spec); }
    if (s == "arrow") { return r_arrow(spec); }
    if (s == "tent") { return r_tent(spec); }
    if (s == "bridge") { return r_bridge(spec); }
    if (s == "well") { return r_well(spec); }
    if (s == "candle") { return r_candle(spec); }
    return r_abstract(spec);
}
