# prism_repl - interactive Prism session.
#
#   ./emerald prism_repl.em
#
# Type a description and press enter; add "img:path.bmp" anywhere in the
# line to feed an image. Files are written to out/. Empty line quits.
# emx-scope-safe

import prism;
import prism_preview;
import prism_imageio;
import strx;
import mesh;

print("Prism - text/image -> textured 3D model (obj + mtl + png + fbx)");
print("examples:");
print("  a small red house");
print("  three tall pine trees");
print("  low poly golden crown");
print("  img:tests/island.bmp terrain");
print("empty line quits.");
print("");

shellexec("mkdir -p out");
n = 0;

while (true) {
    line = getinput("prism> ");
    if (line == "") { break; }
    imgPath = "";
    prompt = "";
    toks = strx.split(line, " ");
    for (i = 0; i < len(toks); ++i) {
        t = toks[i];
        if (len(t) > 4 && t.get(0, 3) == "img:") {
            imgPath = t.get(4, len(t) - 1);
        } else {
            if (prompt == "") { prompt = t; }
            else { prompt = prompt + " " + t; }
        }
    }
    img = nil;
    if (imgPath != "") {
        img = prism_imageio.load_any(imgPath);
        if (img == nil) {
            print("could not load '{imgPath}' (BMP or PPM expected)");
            continue;
        }
    }
    model = prism.generate(prompt, img, nil);
    n = n + 1;
    base = "{n}_{model.name}";
    prism.export_all(model, "out", base, true);
    prism_preview.save_preview(model, "out/{base}_preview.png", 340, 130);
    nf = mesh.face_count(model.mesh);
    print("  -> out/{base}.obj/.mtl/.png/.fbx + preview  ({nf} faces, seed {model.seed})");
}
print("bye");
