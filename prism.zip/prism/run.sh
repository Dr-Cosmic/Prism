#!/usr/bin/env bash
# Prism one-shot CLI.
#
#   ./run.sh "a small red house"
#   ./run.sh "terrain" tests/island.bmp
#   ./run.sh "low poly crown" "" mymodels
#
# args: 1 = text prompt, 2 = optional image (BMP/PPM), 3 = output dir (default out)
# Writes <name>.obj/.mtl/.png/.fbx plus a _preview.png.
set -euo pipefail
cd "$(dirname "$0")"

PROMPT="${1:-}"
IMAGE="${2:-}"
OUTDIR="${3:-out}"
if [ -z "$PROMPT" ] && [ -z "$IMAGE" ]; then
    echo "usage: ./run.sh \"prompt\" [image.bmp] [outdir]" >&2
    exit 1
fi

EMERALD=./emerald
if [ ! -x "$EMERALD" ]; then
    if command -v emerald >/dev/null 2>&1; then EMERALD=emerald;
    else echo "emerald interpreter not found - run ./setup.sh first" >&2; exit 1; fi
fi

mkdir -p "$OUTDIR"
# parameters go through a file so prompts never need shell/Emerald escaping
PARAMS=".run_params.tmp"
printf '%s\n%s\n%s\n' "$PROMPT" "$IMAGE" "$OUTDIR" > "$PARAMS"
trap 'rm -f "$PARAMS"' EXIT

"$EMERALD" prism_cli.em
