# prism_binio - binary byte-string building for Prism.
# Emerald strings are NUL-safe byte containers and File.write is binary,
# so binary formats (FBX, PNG, BMP) are built as ordinary strings.
# Emerald has no bitwise operators; XOR is done with precomputed nibble
# tables, everything else with // and % (Python-style, sign of divisor).
# emx-scope-safe

emxPrismXT = [];        # 256-entry nibble xor table: xt[a*16+b] = a xor b  (a,b in 0..15)
emxPrismCrcT = [];      # 256-entry crc32 table (ints)
emxPrismByteChar = [];  # 256 single-char strings
emxPrismXB = [];        # 65536-entry byte xor table: xb[a*256+b] = a xor b
emxPrismCT0 = [];       # crc table split into its 4 bytes
emxPrismCT1 = [];
emxPrismCT2 = [];
emxPrismCT3 = [];

fn nibble_tab() {
    int a = 0; int b = 0; int bit = 0; int ra = 0; int rb = 0; int t = 0; int v = 0; int p = 0;
    if (len(emxPrismXT) > 0) { return emxPrismXT; }
    t = [];
    for (a = 0; a < 16; ++a) {
        for (b = 0; b < 16; ++b) {
            v = 0; p = 1; ra = a; rb = b;
            for (bit = 0; bit < 4; ++bit) {
                if (ra % 2 != rb % 2) { v = v + p; }
                ra = ra // 2; rb = rb // 2; p = p * 2;
            }
            t[a * 16 + b] = v;
        }
    }
    emxPrismXT = t;
    return emxPrismXT;
}

fn xor8(a, b) {
    int xt = 0;
    xt = nibble_tab();
    return xt[(a // 16) * 16 + (b // 16)] * 16 + xt[(a % 16) * 16 + (b % 16)];
}

fn xor32(a, b) {
    int r = 0; int p = 0; int i = 0; int xa = 0; int xb = 0;
    r = 0; p = 1; xa = a; xb = b;
    for (i = 0; i < 4; ++i) {
        r = r + xor8(xa % 256, xb % 256) * p;
        xa = xa // 256; xb = xb // 256; p = p * 256;
    }
    return r;
}

fn crc_tab() {
    int c = 0; int k = 0; int n = 0; int t = 0;
    if (len(emxPrismCrcT) > 0) { return emxPrismCrcT; }
    t = [];
    for (n = 0; n < 256; ++n) {
        c = n;
        for (k = 0; k < 8; ++k) {
            if (c % 2 == 1) { c = xor32(3988292384, c // 2); }
            else { c = c // 2; }
        }
        t[n] = c;
    }
    emxPrismCrcT = t;
    return emxPrismCrcT;
}

# full 8-bit xor table (built once, ~65K entries) for fast crc32
fn byte_xor_tab() {
    int a = 0; int b = 0; int t = 0; int xt = 0; int ah = 0; int al = 0; int arow = 0;
    if (len(emxPrismXB) > 0) { return emxPrismXB; }
    xt = nibble_tab();
    t = [];
    for (a = 0; a < 256; ++a) {
        ah = (a // 16) * 16; al = (a % 16) * 16; arow = a * 256;
        for (b = 0; b < 256; ++b) {
            t[arow + b] = xt[ah + b // 16] * 16 + xt[al + b % 16];
        }
    }
    emxPrismXB = t;
    return emxPrismXB;
}

fn crc_split_tabs() {
    int i = 0; int t = 0; int v = 0;
    if (len(emxPrismCT0) > 0) { return true; }
    t = crc_tab();
    for (i = 0; i < 256; ++i) {
        v = t[i];
        emxPrismCT0[i] = v % 256;
        emxPrismCT1[i] = (v // 256) % 256;
        emxPrismCT2[i] = (v // 65536) % 256;
        emxPrismCT3[i] = v // 16777216;
    }
    return true;
}

fn byte_chars() {
    int i = 0; int t = 0;
    if (len(emxPrismByteChar) > 0) { return emxPrismByteChar; }
    t = [];
    for (i = 0; i < 256; ++i) { t[i] = "" + char(i); }
    emxPrismByteChar = t;
    return emxPrismByteChar;
}

# ---- integer encodings ----------------------------------------------------

fn u8s(n) { return "" + char(n % 256); }

fn u16le(n) {
    int v = 0;
    v = n % 65536;
    return "" + char(v % 256) + char(v // 256);
}

fn u16be(n) {
    int v = 0;
    v = n % 65536;
    return "" + char(v // 256) + char(v % 256);
}

fn u32le(n) {
    int v = 0;
    v = n % 4294967296;
    return "" + char(v % 256) + char((v // 256) % 256) + char((v // 65536) % 256) + char((v // 16777216) % 256);
}

fn u32be(n) {
    int v = 0;
    v = n % 4294967296;
    return "" + char((v // 16777216) % 256) + char((v // 65536) % 256) + char((v // 256) % 256) + char(v % 256);
}

# two's-complement 32-bit (Python-style % makes negatives wrap correctly)
fn i32le(n) { return u32le(n % 4294967296); }

fn u64le(n) {
    int lo = 0; int hi = 0;
    lo = n % 4294967296;
    hi = ((n - lo) // 4294967296) % 4294967296;
    return u32le(lo) + u32le(hi);
}

fn i64le(n) { return u64le(n); }   # u64le already wraps via %

# ---- IEEE-754 -------------------------------------------------------------
# Extracting mantissa bits: after normalising m into [1,2), frac = m-1 has at
# most 52 fractional bits, and frac * 2^52 is an exact power-of-two scaling,
# so floor() recovers the exact bit pattern with a single multiply.

fn f64le(x) {
    int e = 0; int ebits = 0; int frac = 0; int m = 0; int mant = 0; int s = 0;
    int b6 = 0; int b7 = 0; int lo32 = 0; int mid = 0;
    if (x == 0.0) { return u32le(0) + u32le(0); }
    s = 0; m = float(x);
    if (m < 0.0) { s = 1; m = 0.0 - m; }
    e = 0;
    while (m >= 2.0) { m = m / 2.0; e = e + 1; }
    while (m < 1.0)  { m = m * 2.0; e = e - 1; }
    if (e > 1023) { e = 1023; m = 1.9999999999999998; }       # clamp to max finite
    if (e < 0 - 1022) { return u32le(0) + u32le(0); }         # flush denormals to 0
    ebits = e + 1023;
    frac = m - 1.0;
    mant = int(floor(frac * 4503599627370496.0));             # 2^52, exact
    lo32 = mant % 4294967296;
    mid  = (mant // 4294967296) % 65536;                      # bits 32..47
    b6   = (mant // 281474976710656) % 16 + (ebits % 16) * 16; # top 4 mant bits + low 4 exp bits
    b7   = s * 128 + ebits // 16;
    return u32le(lo32) + u16le(mid) + u8s(b6) + u8s(b7);
}

fn f32le(x) {
    int e = 0; int ebits = 0; int frac = 0; int m = 0; int mant = 0; int s = 0;
    int b2 = 0; int b3 = 0;
    if (x == 0.0) { return u32le(0); }
    s = 0; m = float(x);
    if (m < 0.0) { s = 1; m = 0.0 - m; }
    e = 0;
    while (m >= 2.0) { m = m / 2.0; e = e + 1; }
    while (m < 1.0)  { m = m * 2.0; e = e - 1; }
    frac = m - 1.0;
    mant = int(floor(frac * 8388608.0 + 0.5));                # 2^23, round to nearest
    if (mant >= 8388608) { mant = 0; e = e + 1; }             # rounding overflow
    if (e > 127) { e = 127; mant = 8388607; }
    if (e < 0 - 126) { return u32le(0); }
    ebits = e + 127;
    b2 = (mant // 65536) % 128 + (ebits % 2) * 128;
    b3 = s * 128 + ebits // 2;
    return u16le(mant % 65536) + u8s(b2) + u8s(b3);
}

# ---- checksums ------------------------------------------------------------

fn crc32(s) {
    int b = 0; int c0 = 0; int c1 = 0; int c2 = 0; int c3 = 0; int i = 0; int idx = 0;
    int n = 0; int t0 = 0; int t1 = 0; int t2 = 0; int t3 = 0; int xb = 0;
    xb = byte_xor_tab();
    crc_split_tabs();
    t0 = emxPrismCT0; t1 = emxPrismCT1; t2 = emxPrismCT2; t3 = emxPrismCT3;
    n = len(s);
    c0 = 255; c1 = 255; c2 = 255; c3 = 255;
    for (i = 0; i < n; ++i) {
        idx = xb[c0 * 256 + int(s[i])];
        c0 = xb[t0[idx] * 256 + c1];
        c1 = xb[t1[idx] * 256 + c2];
        c2 = xb[t2[idx] * 256 + c3];
        c3 = t3[idx];
    }
    # final xor with 0xFFFFFFFF = complement of each byte
    return (255 - c3) * 16777216 + (255 - c2) * 65536 + (255 - c1) * 256 + (255 - c0);
}

fn adler32(s) {
    int a = 0; int b = 0; int end = 0; int i = 0; int n = 0; int off = 0;
    a = 1; b = 0; n = len(s); off = 0;
    while (off < n) {
        end = off + 4000;
        if (end > n) { end = n; }
        for (i = off; i < end; ++i) {
            a = a + int(s[i]);
            b = b + a;
        }
        a = a % 65521; b = b % 65521;
        off = end;
    }
    return b * 65536 + a;
}

# ---- misc -----------------------------------------------------------------

fn bjoin(parts) {
    int i = 0; int n = 0; int s = 0;
    s = ""; n = len(parts);
    for (i = 0; i < n; ++i) { s = s + parts[i]; }
    return s;
}

fn zero_bytes(n) {
    int i = 0; int s = 0;
    s = "";
    for (i = 0; i < n; ++i) { s = s + char(0); }
    return s;
}

# unsigned byte value of character i of string s
fn ub(s, i) { return int(s[i]); }

# read little-endian u16/u32 from a byte string (for BMP/PPM readers)
fn rd_u16le(s, off) { return int(s[off]) + int(s[off + 1]) * 256; }
fn rd_u32le(s, off) {
    return int(s[off]) + int(s[off + 1]) * 256 + int(s[off + 2]) * 65536 + int(s[off + 3]) * 16777216;
}
