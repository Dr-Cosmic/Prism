# prism - text/image -> textured 3D model. Main entry points.
#
#   import prism;
#   model = prism.generate("a small red house", nil, nil);
#   prism.export_all(model, "out", "house", true);
#
# generate(prompt, img, opts) -> PrismModel
#   prompt  text description (see prism_text for the vocabulary)
#   img     optional emeraldx image (see prism_image3d for image modes)
#   opts    nil or PrismOpts
#
# export_all writes <base>.obj, <base>.mtl, <base>.png, <base>.fbx (texture
# embedded) and optionally <base>_preview.png into the given directory.
# emx-scope-safe

import mesh;
import mat4;
import prng;
import strx;
import prism_text;
import prism_shapes;
import prism_uv;
import prism_texgen;
import prism_prims;
import prism_imageio;
import prism_mtlobj;
import prism_fbx;
import prism_image3d;
import prism_types;

# re-exported so callers can write prism.PrismOpts / prism.PrismModel
PrismOpts = prism_types.PrismOpts;
PrismModel = prism_types.PrismModel;

fn cell_px_for(quality) {
    if (quality == "fast") { return 72; }
    if (quality == "high") { return 128; }
    return 96;
}

# collect unique cell keys in first-seen order
fn collect_keys(parts) {
    int found = 0; int i = 0; int j = 0; int keys = 0;
    keys = [];
    for (i = 0; i < len(parts); ++i) {
        found = false;
        for (j = 0; j < len(keys); ++j) {
            if (keys[j] == parts[i][3]) { found = true; break; }
        }
        if (!found) { keys[len(keys)] = parts[i][3]; }
    }
    return keys;
}

fn key_index(keys, k) {
    int i = 0;
    for (i = 0; i < len(keys); ++i) { if (keys[i] == k) { return i; } }
    return 0;
}

# replicate spec-built parts `count` times in a ring with seeded jitter
fn build_instances(spec) {
    int a = 0; int i = 0; int inst = 0; int j = 0; int parts = 0; int r = 0; int ring = 0;
    int s2 = 0; int st = 0; int sc = 0; int x = 0; int z = 0; int one = 0;
    if (spec.count <= 1) { return prism_shapes.build(spec); }
    st = prng.seed_from(spec.seed * 3 + 17);
    ring = 0.75 + spec.count * 0.28;
    parts = [];
    for (i = 0; i < spec.count; ++i) {
        s2 = spec;
        s2.seed = spec.seed + i * 101;
        s2.count = 1;
        inst = prism_shapes.build(s2);
        a = 6.2832 * i / spec.count;
        r = prng.uniform(st, 0.85, 1.15); st = r[1];
        x = ring * cos(a) * r[0];
        r = prng.uniform(st, 0.85, 1.15); st = r[1];
        z = ring * sin(a) * r[0];
        r = prng.uniform(st, 0.0, 6.2832); st = r[1];
        r = [r[0], st];
        sc = prng.uniform(st, 0.82, 1.15); st = sc[1];
        for (j = 0; j < len(inst); ++j) {
            one = inst[j];
            one[0] = mesh.transform_mesh(one[0], mat4.trs([x, 0.0, z], [0.0, r[0], 0.0], [sc[0], sc[0], sc[0]]));
            parts[len(parts)] = one;
        }
    }
    return parts;
}

fn generate(prompt, img, optsIn) {
    int atlas = 0; int cellPx = 0; int grid = 0; int i = 0; int keys = 0; int m = 0;
    int merged = 0; int model = 0; int opts = 0; int parts = 0; int rect = 0; int size = 0;
    int spec = 0; int one = 0; int ci = 0; int painted = 0; int seedBase = 0; int nm = 0;
    opts = optsIn;
    if (opts == nil) { opts = PrismOpts; }
    spec = prism_text.parse(prompt, opts.seed);
    if (img != nil) {
        parts = prism_image3d.build(spec, img);
    } else {
        parts = build_instances(spec);
    }
    # ---- atlas ----
    keys = collect_keys(parts);
    grid = prism_uv.grid_for(len(keys));
    cellPx = cell_px_for(opts.quality);
    size = cellPx * grid;
    if (size < 128) { size = 128; }
    if (size > 384) { size = 384; }
    size = (size // 16) * 16;
    atlas = prism_texgen.make_atlas(size);
    seedBase = spec.seed;
    painted = [];
    for (i = 0; i < len(keys); ++i) { painted[i] = false; }
    for (i = 0; i < len(parts); ++i) {
        one = parts[i];
        ci = key_index(keys, one[3]);
        rect = prism_uv.cell_rect(ci, grid, 0.04);
        if (!painted[ci]) {
            if (one[1] == "__image__") {
                atlas = prism_texgen.paint_cell_image(atlas, rect, one[2]);
            } else {
                atlas = prism_texgen.paint_cell(atlas, rect, one[1], one[2], seedBase + ci * 7);
            }
            painted[ci] = true;
        }
        one[0] = prism_uv.to_cell(one[0], ci, grid, 0.04);
        parts[i] = one;
    }
    # ---- merge & fit ----
    merged = parts[0][0];
    for (i = 1; i < len(parts); ++i) { merged = mesh.merge(merged, parts[i][0]); }
    if (spec.tallness != 1.0 || spec.wideness != 1.0) {
        merged = mesh.transform_mesh(merged, mat4.scaling(spec.wideness, spec.tallness, spec.wideness));
        merged = mesh.compute_normals(merged);
    }
    merged = prism_prims.normalize_size(merged, opts.targetSize * spec.size);
    merged = prism_prims.recenter_ground(merged);
    model = PrismModel;
    model.mesh = merged;
    model.atlas = atlas;
    model.shape = spec.shape;
    model.seed = spec.seed;
    nm = spec.noun;
    if (nm == "") { nm = spec.shape; }
    model.name = strx.replace_all(nm, " ", "_");
    return model;
}

fn export_all(model, dir, base, withFbx) {
    int png = 0; int wf = 0;
    png = prism_imageio.png_bytes(model.atlas);
    File fp = "{dir}/{base}.png";
    fp.write(png);
    prism_mtlobj.export_obj(model.mesh, dir, base, "{base}.png");
    wf = withFbx;
    if (wf == nil) { wf = true; }
    if (wf) {
        prism_fbx.write_fbx(model.mesh, "{dir}/{base}.fbx", base, "{base}.png", png);
    }
    return true;
}
