# prism_preview - small turntable previews of a model, self-contained.
#
#   save_preview(model, path, w, h)   two orbit views side by side -> PNG
#
# Has its own inlined rasterizer (z-buffer, lambert + ambient, nearest
# texture fetch): Emerald deep-clones function arguments, so calling into
# the generic renderer's per-pixel helpers would clone the atlas for every
# shaded pixel. Everything below runs in one stack frame on purpose.
# emx-scope-safe

import mat4;
import prism_imageio;

# render one orbit view into data (flat rgb float array, w*h*3), returns data
fn render_view(data, w, h, m, tex, dist, yaw, pitch, liftY) {
    int area = 0; int base = 0; int cb2 = 0; int cg2 = 0; int cr2 = 0; int cw = 0; int cx = 0;
    int cy = 0; int f = 0; int faces = 0; int i = 0; int i0 = 0; int i1 = 0; int i2 = 0;
    int invArea = 0; int iw0 = 0; int iw1 = 0; int iw2 = 0; int lum = 0; int lx = 0; int ly = 0;
    int lz = 0; int maxx = 0; int maxy = 0; int minx = 0; int miny = 0; int mvp = 0; int ndl = 0;
    int nf = 0; int normals = 0; int nv = 0; int nx = 0; int ny = 0; int nz = 0; int positions = 0;
    int proj = 0; int px = 0; int py = 0; int q0 = 0; int q1 = 0; int q2 = 0; int qs = 0;
    int sw = 0; int sx = 0; int sy = 0; int sz = 0; int tc = 0; int td = 0; int th = 0; int ti = 0;
    int tj = 0; int tw = 0; int u = 0; int uvs = 0; int v = 0; int view = 0; int w0 = 0; int w1 = 0;
    int w2 = 0; int x0 = 0; int x1 = 0; int x2 = 0; int y0 = 0; int y1 = 0; int y2 = 0; int z = 0;
    int zbuf = 0; int zi = 0; int clip = 0; int ex = 0; int ey = 0; int ez = 0; int d = 0; int nl = 0;
    positions = m[0]; normals = m[1]; uvs = m[2]; faces = m[3];
    tw = tex[0]; th = tex[1]; td = tex[3];
    d = data;
    # camera
    ex = dist * cos(pitch) * sin(yaw);
    ey = dist * sin(pitch);
    ez = dist * cos(pitch) * cos(yaw);
    view = mat4.look_at([ex, ey, ez], [0.0, 0.0, 0.0], [0.0, 1.0, 0.0]);
    proj = mat4.perspective(38.0, w * 1.0 / h, 0.1, 100.0);
    mvp = mat4.mul(proj, mat4.mul(view, mat4.translation(0.0, liftY, 0.0)));
    # light (normalized in-line)
    lx = 0.45; ly = 0.80; lz = 0.55;
    nl = sqrt(lx * lx + ly * ly + lz * lz);
    lx = lx / nl; ly = ly / nl; lz = lz / nl;
    zbuf = [];
    for (i = 0; i < w * h; ++i) { zbuf[i] = 1.0e30; }
    # transform vertices (model = translation only, so normals pass through)
    nv = len(positions) // 3;
    sx = []; sy = []; sz = []; sw = [];
    for (i = 0; i < nv; ++i) {
        clip = mat4.transform_vec4(mvp, [positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2], 1.0]);
        cw = clip[3];
        if (cw < 1.0e-9 && cw > 0.0 - 1.0e-9) { cw = 1.0e-9; }
        sw[i] = cw;
        sx[i] = (clip[0] / cw * 0.5 + 0.5) * (w - 1);
        sy[i] = (1.0 - (clip[1] / cw * 0.5 + 0.5)) * (h - 1);
        sz[i] = clip[2] / cw;
    }
    nf = len(faces) // 3;
    for (f = 0; f < nf; ++f) {
        i0 = faces[f * 3]; i1 = faces[f * 3 + 1]; i2 = faces[f * 3 + 2];
        if (sw[i0] <= 0.0 || sw[i1] <= 0.0 || sw[i2] <= 0.0) { continue; }
        x0 = sx[i0]; y0 = sy[i0];
        x1 = sx[i1]; y1 = sy[i1];
        x2 = sx[i2]; y2 = sy[i2];
        area = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
        if (area >= 0.0) { continue; }
        minx = x0; if (x1 < minx) { minx = x1; } if (x2 < minx) { minx = x2; }
        maxx = x0; if (x1 > maxx) { maxx = x1; } if (x2 > maxx) { maxx = x2; }
        miny = y0; if (y1 < miny) { miny = y1; } if (y2 < miny) { miny = y2; }
        maxy = y0; if (y1 > maxy) { maxy = y1; } if (y2 > maxy) { maxy = y2; }
        minx = minx - 0.0; if (minx < 0) { minx = 0; }
        miny = miny - 0.0; if (miny < 0) { miny = 0; }
        maxx = maxx + 1.0; if (maxx > w - 1) { maxx = w - 1; }
        maxy = maxy + 1.0; if (maxy > h - 1) { maxy = h - 1; }
        minx = int(minx); miny = int(miny); maxx = int(maxx); maxy = int(maxy);
        if (minx > maxx || miny > maxy) { continue; }
        invArea = 1.0 / area;
        iw0 = 1.0 / sw[i0]; iw1 = 1.0 / sw[i1]; iw2 = 1.0 / sw[i2];
        for (py = miny; py <= maxy; ++py) {
            cy = py + 0.0;
            for (px = minx; px <= maxx; ++px) {
                cx = px + 0.0;
                w0 = ((x2 - x1) * (cy - y1) - (y2 - y1) * (cx - x1)) * invArea;
                if (w0 < 0.0) { continue; }
                w1 = ((x0 - x2) * (cy - y2) - (y0 - y2) * (cx - x2)) * invArea;
                if (w1 < 0.0) { continue; }
                w2 = 1.0 - w0 - w1;
                if (w2 < 0.0) { continue; }
                z = w0 * sz[i0] + w1 * sz[i1] + w2 * sz[i2];
                zi = py * w + px;
                if (z >= zbuf[zi]) { continue; }
                zbuf[zi] = z;
                q0 = w0 * iw0; q1 = w1 * iw1; q2 = w2 * iw2;
                qs = q0 + q1 + q2;
                q0 = q0 / qs; q1 = q1 / qs; q2 = q2 / qs;
                # interpolated normal (model has no rotation)
                nx = q0 * normals[i0 * 3] + q1 * normals[i1 * 3] + q2 * normals[i2 * 3];
                ny = q0 * normals[i0 * 3 + 1] + q1 * normals[i1 * 3 + 1] + q2 * normals[i2 * 3 + 1];
                nz = q0 * normals[i0 * 3 + 2] + q1 * normals[i1 * 3 + 2] + q2 * normals[i2 * 3 + 2];
                nl = sqrt(nx * nx + ny * ny + nz * nz);
                if (nl < 1.0e-9) { nl = 1.0; }
                ndl = (nx * lx + ny * ly + nz * lz) / nl;
                if (ndl < 0.0) { ndl = 0.0; }
                lum = 0.34 + 0.72 * ndl;
                # nearest texture fetch
                u = q0 * uvs[i0 * 2] + q1 * uvs[i1 * 2] + q2 * uvs[i2 * 2];
                v = q0 * uvs[i0 * 2 + 1] + q1 * uvs[i1 * 2 + 1] + q2 * uvs[i2 * 2 + 1];
                if (u < 0.0) { u = 0.0; }
                if (u > 0.9995) { u = 0.9995; }
                if (v < 0.0) { v = 0.0; }
                if (v > 0.9995) { v = 0.9995; }
                ti = u * tw;
                tj = v * th;
                tc = (tj * tw + ti) * 3;
                cr2 = td[tc] * lum;
                cg2 = td[tc + 1] * lum;
                cb2 = td[tc + 2] * lum;
                if (cr2 > 1.0) { cr2 = 1.0; }
                if (cg2 > 1.0) { cg2 = 1.0; }
                if (cb2 > 1.0) { cb2 = 1.0; }
                base = zi * 3;
                d[base] = cr2;
                d[base + 1] = cg2;
                d[base + 2] = cb2;
            }
        }
    }
    return d;
}

fn save_preview(model, path, w, h) {
    int d1 = 0; int d2 = 0; int half = 0; int hh = 0; int i = 0; int out = 0; int px = 0;
    int py = 0; int row = 0; int ww = 0; int lift = 0; int bnds = 0; int c = 0;
    ww = w; hh = h;
    if (ww == nil) { ww = 320; }
    if (hh == nil) { hh = 130; }
    half = ww // 2;
    # lift so the model's vertical center sits at the orbit target
    bnds = model.mesh;
    lift = 0.0;
    for (i = 1; i < len(bnds[0]); i = i + 3) {
        if (bnds[0][i] > lift) { lift = bnds[0][i]; }
    }
    lift = 0.0 - lift * 0.5;
    d1 = [];
    for (i = 0; i < half * hh * 3; ++i) { d1[i] = 0.94; }
    d1 = render_view(d1, half, hh, model.mesh, model.atlas, 3.6, 0.62, 0.40, lift);
    d2 = [];
    for (i = 0; i < half * hh * 3; ++i) { d2[i] = 0.94; }
    d2 = render_view(d2, half, hh, model.mesh, model.atlas, 3.6, 2.45, 0.16, lift);
    out = [];
    for (py = 0; py < hh; ++py) {
        for (px = 0; px < half; ++px) {
            for (c = 0; c < 3; ++c) {
                out[(py * ww + px) * 3 + c] = d1[(py * half + px) * 3 + c];
                out[(py * ww + px + half) * 3 + c] = d2[(py * half + px) * 3 + c];
            }
        }
    }
    prism_imageio.save_png([ww, hh, 3, out], path);
    return path;
}
