# selftest.em - quick health check for a Prism installation.
# Run from the package root:   ./emerald selftest.em
# emx-scope-safe

import prism_binio;
import prism_prims;
import prism_uv;
import prism_texgen;
import prism_text;
import prism;
import mesh;

pass = 0;
fail = 0;

fn check(name, ok) {
    if (ok) { pass = pass + 1; print("  ok   {name}"); }
    else { fail = fail + 1; print("  FAIL {name}"); }
}

print("prism selftest");

# checksums against known vectors
v = prism_binio.crc32("123456789");
check("crc32 vector", v == 3421780262);
v = prism_binio.adler32("Wikipedia");
check("adler32 vector", v == 300286872);

# primitives
m = prism_prims.box(1.0, 1.0, 1.0);
check("box 12 tris", mesh.face_count(m) == 12);
m = prism_prims.capped_cylinder(0.5, 1.0, 12);
check("cylinder closed", mesh.face_count(m) == 12 * 2 + 12 * 2);
m = prism_prims.extrude([0.0,0.0, 1.0,0.0, 0.5,1.0], 0.3);
check("extrude tri prism", mesh.face_count(m) == 1 + 1 + 6);

# uv projection stays in range
m = prism_uv.project(prism_prims.box(1.0, 2.0, 3.0), "box");
u = m[2];
ok = true;
for (i = 0; i < len(u); ++i) {
    if (u[i] < 0.0 - 0.001 || u[i] > 1.001) { ok = false; break; }
}
check("box uv in [0,1]", ok);

# parser
s = prism_text.parse("two tall wooden towers", nil);
check("parse shape", s.shape == "tower");
check("parse material", s.texKind == "wood");
check("parse count", s.count == 2);
check("parse tallness", s.tallness > 1.0);

# a full tiny generate (fast quality)
o = prism.PrismOpts;
o.quality = "fast";
model = prism.generate("red cube", nil, o);
check("generate mesh", mesh.face_count(model.mesh) == 12);
check("generate atlas", model.atlas[0] >= 128);

print("passed {pass}, failed {fail}");
if (fail > 0) { print("SELFTEST FAILED"); }
else { print("SELFTEST OK"); }
