# prism_uv - per-part UV projection and atlas placement.
#
# Prism models are built from parts. Every part gets a UV projection in its
# own [0,1] space (using the emeraldx `uvmap` projections), and each *group*
# of parts that shares a texture is then remapped into one cell of a square
# texture atlas. The result is a single texture image + a single material
# per model, with every part painted independently - which keeps the OBJ/MTL
# and FBX side simple (one mesh, one material, one map).
#
#   project(m, mode)                "box" | "cyl" | "sphere" | "planar" | "keep"
#   normalize_uvs(m)                rescale UV bbox to [0,1]
#   to_cell(m, cell, grid, margin)  remap [0,1] UVs into atlas cell `cell`
#   grid_for(nCells)                smallest n with n*n >= nCells
#   cell_rect(cell, grid, margin)   -> [u0, v0, size] of the painted region
# emx-scope-safe

import uvmap;
import mathx;

fn grid_for(nCells) {
    int n = 0;
    n = 1;
    while (n * n < nCells) { n = n + 1; }
    return n;
}

fn normalize_uvs(m) {
    int du = 0; int dv = 0; int i = 0; int nv = 0; int out = 0; int u0 = 0; int u1 = 0;
    int uvs = 0; int v0 = 0; int v1 = 0;
    out = m;
    uvs = out[2];
    nv = len(uvs) // 2;
    if (nv == 0) { return out; }
    u0 = uvs[0]; u1 = uvs[0]; v0 = uvs[1]; v1 = uvs[1];
    for (i = 0; i < nv; ++i) {
        if (uvs[i * 2] < u0) { u0 = uvs[i * 2]; }
        if (uvs[i * 2] > u1) { u1 = uvs[i * 2]; }
        if (uvs[i * 2 + 1] < v0) { v0 = uvs[i * 2 + 1]; }
        if (uvs[i * 2 + 1] > v1) { v1 = uvs[i * 2 + 1]; }
    }
    du = mathx.maxv(u1 - u0, 1.0e-9);
    dv = mathx.maxv(v1 - v0, 1.0e-9);
    for (i = 0; i < nv; ++i) {
        uvs[i * 2] = (uvs[i * 2] - u0) / du;
        uvs[i * 2 + 1] = (uvs[i * 2 + 1] - v0) / dv;
    }
    out[2] = uvs;
    return out;
}

fn project(m, mode) {
    int out = 0;
    if (mode == "keep") { return m; }
    if (mode == "box") { out = uvmap.box_project(m); }
    elif (mode == "cyl") { out = uvmap.cylindrical_project(m); }
    elif (mode == "sphere") { out = uvmap.spherical_project(m); }
    elif (mode == "planar") { out = uvmap.planar_project(m, 1); }
    else { out = uvmap.box_project(m); }
    return normalize_uvs(out);
}

# cell rectangle in UV space (top-left cell = 0, row-major),
# margin is a fraction of one cell kept as a gutter on every side.
fn cell_rect(cell, grid, margin) {
    int cs = 0; int cx = 0; int cy = 0; int mg = 0;
    cs = 1.0 / grid;
    cx = cell % grid;
    cy = cell // grid;
    mg = margin;
    if (mg == nil) { mg = 0.05; }
    return [cx * cs + cs * mg, cy * cs + cs * mg, cs * (1.0 - 2.0 * mg)];
}

fn to_cell(m, cell, grid, margin) {
    int i = 0; int nv = 0; int out = 0; int r = 0; int uvs = 0;
    out = m;
    r = cell_rect(cell, grid, margin);
    uvs = out[2];
    nv = len(uvs) // 2;
    for (i = 0; i < nv; ++i) {
        uvs[i * 2] = r[0] + uvs[i * 2] * r[2];
        uvs[i * 2 + 1] = r[1] + uvs[i * 2 + 1] * r[2];
    }
    out[2] = uvs;
    return out;
}
