# Prism

Author: Jean-Jacques François Reibel

Text and images in, **UV-mapped, textured 3D models** out — written entirely
in the [Emerald](https://github.com/Dr-Cosmic/Emerald) scripting language on
top of the [EmeraldX](https://github.com/Dr-Cosmic/Emeraldx) module library.

Every model is exported as:

| file | what it is |
|------|-----------|
| `name.obj` + `name.mtl` | Wavefront OBJ with normals + UVs, MTL references the texture |
| `name.png`              | the generated texture atlas (PNG written by Prism's own encoder) |
| `name.fbx`              | **binary FBX 7.4** with the texture **embedded** — a single portable file |
| `name_preview.png`      | two-view software render of the result |

No network, no external AI services, no native dependencies beyond the
Emerald interpreter itself: parsing, geometry, texture synthesis, PNG
encoding, the FBX binary writer and the preview rasterizer are all `.em`
scripts you can read.

```
./setup.sh                                   # builds the interpreter, runs the selftest
./run.sh "a small red house"                 # -> out/house.obj .mtl .png .fbx + preview
./run.sh "low poly golden crown"
./run.sh "terrain" tests/island.bmp          # image -> heightmap terrain
./emerald prism_repl.em                      # interactive session
```

## How it works

**Text pipeline** — `prism_text` tokenizes and Porter-stems the prompt with
EmeraldX's `nlp` module, then matches against a built-in vocabulary
(~50 shapes, ~20 materials, ~35 colors, sizes, styles, counts). The result
drives `prism_shapes`, a library of 45+ procedural recipes (house, castle,
rocket, snowman, chess pawn, gear, ...) built from parametric primitives:
boxes, lathes, extrusions, icospheres, fractal-displaced rocks. Prism is a
**rule-based procedural generator** — a transparent, deterministic craftsman,
not a neural network. The same prompt (or seed) always rebuilds the same
model; unknown words fall back to an "abstract sculpture" recipe.

**Image pipeline** — `prism_image3d` builds geometry from a BMP/PPM image in
one of three modes (auto-detected, or forced with a word in the prompt):

* `terrain` — the image is a heightmap; the mesh is a displaced grid textured
  with the image itself (grayscale inputs are colorized by altitude:
  water → grass → rock → snow).
* `extrude` — the subject is segmented (Otsu threshold → largest connected
  component → Moore contour trace → Ramer-Douglas-Peucker simplification)
  and its outline is extruded; the caps carry the image, the sides get the
  subject's dominant color.
* `lathe` — the silhouette's per-row radius becomes a surface of revolution,
  tinted with a k-means palette sampled from the image.

**Texturing** — every part declares a material (`brick`, `wood`, `metal`,
`lava`, `crystal`, ...). Parts sharing a material share one cell of a texture
atlas; `prism_texgen` paints each cell procedurally (value-noise + hash
patterns) and part UVs are remapped into their cell. Prompt colors restyle
the primary surfaces ("**red** house" = red bricks, the roof stays a roof).

**Export** — `prism_mtlobj` writes OBJ/MTL; `prism_fbx` writes binary
FBX 7.4 from scratch (node records, property arrays, two-part names, footer
magic — see `docs/FORMATS.md`) and embeds the PNG so the single `.fbx` file
carries its texture. Both import cleanly in `assimp` (and anything using it,
e.g. Blender).

## Vocabulary cheat-sheet

* **shapes** — cube, sphere, cylinder, cone, pyramid, torus, ring, gem,
  crystal, house/cottage/cabin, tower/lighthouse, castle/fortress, tree,
  pine/fir/spruce, forest, rock/boulder/asteroid, mountain/hill, volcano,
  terrain/island, planet, moon, mushroom, rocket/spaceship, boat/ship,
  car/truck, table/desk, chair/stool, mug/cup, bottle/flask, vase/pot/urn,
  lamp/lantern, sword/dagger, shield, snowman, robot, barrel/keg, coin,
  dice, crown/tiara, pawn/chess, heart, star, gear/cog, arrow, tent,
  bridge, well, candle
* **materials** — wood, stone, brick, metal/steel, gold/brass, marble,
  glass/ice, crystal/emerald, rust, snow, sand, lava, water, grass/moss,
  fabric/cloth, checker, bark
* **colors** — red, orange, yellow, green, blue, purple, pink, cyan, teal,
  brown, tan, white, black, gray, gold, silver, crimson, navy, lime, olive,
  maroon, coral, lavender, mint, indigo, amber, ivory, charcoal, ... plus
  `light`/`dark` modifiers
* **sizes / styles / counts** — tiny, small, big, huge, tall, short, wide,
  thin, low poly, smooth, two...nine, pair, few, several

Examples that all do what you'd hope: `"stone castle"`,
`"three tall pine trees"`, `"rusty robot"`, `"dark blue vase"`,
`"2 marble chess pawns"`, `"huge emerald gem"`.

## Library API

```em
import prism;

opts = prism.PrismOpts;        # optional
opts.quality = "high";         # "fast" | "normal" | "high"  (atlas resolution)
opts.seed = 1234;              # override the prompt-derived seed
opts.targetSize = 2.0;         # max dimension of the exported model

model = prism.generate("a small red house", nil, opts);
# model.mesh   [positions, normals, uvs, faces] (EmeraldX mesh)
# model.atlas  [w, h, 3, data] image
# model.name / model.shape / model.seed

prism.export_all(model, "out", "house", true);   # obj+mtl+png (+fbx if true)

import prism_preview;
prism_preview.save_preview(model, "out/house_preview.png", 340, 130);

# image input
import prism_imageio;
img = prism_imageio.load_any("tests/island.bmp");   # BMP or PPM
model = prism.generate("terrain", img, nil);
```

The lower layers are usable on their own: `prism_prims` (parametric
primitives), `prism_uv` (box/cylinder/sphere/planar projection + atlas
cells), `prism_texgen` (20 material painters, palettes, k-means image
palettes), `prism_mtlobj` / `prism_fbx` (exporters for any EmeraldX mesh),
`prism_binio` (LE/BE scalars, crc32, adler32), `prism_imageio` (PNG/BMP
writers, BMP/PPM readers).

## Layout

```
prism/
├── prism.em              facade: generate() / export_all()
├── prism_types.em        GenSpec / PrismOpts / PrismModel
├── prism_text.em         prompt -> spec (nlp tokenizer + Porter stemmer)
├── prism_shapes.em       45+ procedural recipes
├── prism_image3d.em      image -> terrain / extrude / lathe
├── prism_prims.em        primitives: lathe, extrude, terrain, displaced sphere...
├── prism_uv.em           UV projection + atlas cell mapping
├── prism_texgen.em       procedural material painters + palettes
├── prism_mtlobj.em       OBJ + MTL writer
├── prism_fbx.em          binary FBX 7.4 writer (embedded texture)
├── prism_imageio.em      PNG/BMP writers, BMP/PPM readers
├── prism_binio.em        byte-string building, crc32/adler32
├── prism_preview.em      self-contained preview rasterizer
├── prism_repl.em         interactive CLI       prism_cli.em  run.sh driver
├── selftest.em           health check
├── mesh.em, image.em, …  vendored EmeraldX 1.0.0 modules (MIT)
├── examples/             runnable examples (run from this directory)
├── tests/                unit tests + sample input images
├── docs/                 FORMATS.md, PERFORMANCE.md
└── third_party/          full Emerald + EmeraldX sources and licenses
```

EmeraldX modules are vendored flat next to the Prism sources because the
interpreter resolves `import x;` against the working directory — so run
everything **from the package root**.

## Limitations, honestly

* **Input images must be BMP or PPM** (PNG *writing* is implemented, PNG
  *decoding* — inflate — is not). One-liner to convert:
  `python3 -c "from PIL import Image; Image.open('in.png').save('in.bmp')"`.
* The language model is a vocabulary, not an LLM: `"a dragon guarding
  treasure"` gives you the abstract-sculpture fallback, not a dragon.
* PNG output uses stored (uncompressed) deflate blocks — valid everywhere,
  just not small. Atlases are capped at 384×384.
* One material atlas per model, one mesh per FBX; no animation, no PBR maps.
* Speed: a typical prompt takes **~5-25 s** end-to-end with previews
  (tree-level interpreter; see `docs/PERFORMANCE.md` for why and how Prism
  stays inside that budget). Image modes take ~15-30 s.

## License

Prism is released under **GPL-3.0** (`LICENSE`), matching the bundled
Emerald interpreter (GPL-3.0). The vendored EmeraldX modules are MIT —
their license text ships in `third_party/EmeraldX/LICENSE` and applies to
the `.em` modules copied here. Full, unmodified sources of both upstream
projects are included under `third_party/`.
