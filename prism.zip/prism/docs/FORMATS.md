# File formats written by Prism

Everything below is produced by pure Emerald code — byte strings assembled
with `prism_binio` and written with `File.write`. This documents exactly
what the exporters emit, so the files can be debugged with a hex editor.

## OBJ + MTL (`prism_mtlobj.em`)

Standard Wavefront text:

```
mtllib name.mtl
o name
v x y z          # positions
vt u 1-v         # V flipped: OBJ's origin is bottom-left, Prism's is top-left
vn x y z
usemtl name_mat
f a/a/a b/b/b c/c/c    # 1-based, position/uv/normal share indices
```

The MTL declares one material with `map_Kd name.png`, `Kd 1 1 1`, mild
`Ks`. Anything that reads OBJ (Blender, assimp, three.js) picks up the
texture automatically when the `.png` sits next to the file.

## PNG (`prism_imageio.em`)

8-bit RGB, color type 2. The IDAT zlib stream uses **stored** (uncompressed)
deflate blocks: `0x78 0x01` header, then blocks of ≤ 60 000 bytes
(`BFINAL | LEN | ~LEN | raw`), then an adler32 of the raw scanlines.
Scanlines are `filter byte 0` + RGB triples. Chunk CRCs are real crc32
(polynomial `0xEDB88320`), computed with byte-XOR tables because Emerald has
no bitwise operators. Files validate in PIL/pngcheck; they are simply larger
than an optimally-compressed PNG.

Readers: BMP (24-bit uncompressed, bottom-up or top-down) and PPM (P6/P3).
PNG *decoding* would require a full inflate implementation and is not
included — convert inputs to BMP first.

## Binary FBX 7.4 (`prism_fbx.em`)

Little-endian Kaydara binary, 32-bit record format:

```
"Kaydara FBX Binary  \x00\x1a\x00"  u32 version=7400
node*  NULL(13 zero bytes)  footer
```

Each node record:

```
u32 EndOffset      absolute file offset just past this node
u32 NumProperties
u32 PropertyListLen
u8  NameLen, Name
properties...
children... + NULL(13)   (the NULL is present when the node has children
                          or has no properties)
```

Property payloads used: `S` string (`u32 len` + bytes; object names are the
two-part form `"name" 00 01 "Class"`), `I` i32, `L` i64, `D` f64, `C` u8
bool, `R` raw (`u32 len` + bytes), and arrays `d`/`i`
(`u32 count, u32 encoding=0, u32 byteLen, raw`) — Prism always writes
encoding 0 (uncompressed).

Scene graph emitted: `FBXHeaderExtension`, `GlobalSettings`
(Y-up, unit scale 1), `Documents`/`References`/`Definitions`, `Objects`
containing one `Geometry` (`Vertices` d, `PolygonVertexIndex` i with the
last index of each triangle bitwise-complemented, i.e. `-(i+1)`;
`LayerElementNormal` ByPolygonVertex/Direct; `LayerElementUV`
ByPolygonVertex/IndexToDirect with V flipped; `LayerElementMaterial`
AllSame), one `Model`, one phong `Material`, one `Texture`
(UVSet "UVMap") and one `Video` whose `Content` `R`-property **embeds the
PNG bytes** — the `.fbx` is self-contained. `Connections` wires
geometry→model→root, material→model, texture→material (`OP DiffuseColor`),
video→texture.

Footer: 16-byte code `fa bc ab 09 d0 c8 d4 66 b1 76 fb 83 1c f7 26 7e`,
4 zero bytes, zero-padding to a 16-byte boundary (16 bytes when already
aligned), `u32 7400`, 120 zero bytes, and the closing magic
`f8 5a 8c 6a de f5 d9 7e ec e9 0c e3 75 8f 29 0b`.

EndOffsets require absolute positions, so the writer does two passes:
`node_size()` computes every subtree size, then `emit_node()` serializes
with a running offset.

Validated with assimp 5.3: imports with the mesh, UVs, normals, material
and the embedded texture recognized (`Textures (embed.): 1`).
