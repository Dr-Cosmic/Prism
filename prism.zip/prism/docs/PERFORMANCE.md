# Performance notes

Prism generates a textured model in seconds on a tree-walking interpreter
with strict value semantics. That is only possible because the code respects
four properties of the Emerald runtime, measured while building this
library. They are worth knowing for any performance-sensitive Emerald code.

## 1. Function arguments are deep-cloned

Every call clones its arguments (`Interpreter::callFunction` →
`Value::clone`). Passing a 288×288 image (250 k floats) into a helper is a
250 k-element copy — *per call*.

Measured on this codebase:

| change | before | after |
|---|---|---|
| PNG encoder: inline the per-row helper that took the image as an argument | 18.9 s | 2.1 s |
| terrain / cell painting: inline `image.sample_bilinear(img, …)` per sample | minutes (hang) | < 1 s |

Rules of thumb:

* never pass images, meshes or big arrays into per-pixel / per-vertex helpers
  — inline the math into the loop instead (see `prism_preview.em`,
  `paint_cell_image` in `prism_texgen.em`);
* reads are cheap (`img[3][i]` does not clone); *assignments* clone
  (`d = img[3];` copies the whole array);
* index assignment `a[i] = v` mutates in place without cloning the container.

## 2. Builtin calls cost ~20-30 µs each

`floor()`, `int()`, `len()` are cheap C++ inside, but the call itself
(argument vector, dispatch) dominates in hot loops. 250 k pixels × 2 calls
≈ 15 s of pure overhead.

Emerald truncates floats toward zero when they are used as array indices
(`Value::asInt`), so for non-negative values

```em
row = row + bc[x * 255.0 + 0.5];     # float -> byte, ZERO builtin calls
```

replaces `int(floor(x * 255.0 + 0.5))`. Prism's PNG row encoder, checksum
loops and rasterizer use this trick throughout.

## 3. Class fields assign through enclosing scopes

`Environment::assign` first tries to *assign an existing name* in outer
scopes and only creates a field if the name is unknown. A field initializer

```em
import mesh;
class Model { mesh = nil; }      # silently overwrites the mesh MODULE
```

clobbers the import and never creates the field. All Prism data classes
therefore live in `prism_types.em`, a module with **no imports**, and are
re-exported (`PrismModel = prism_types.PrismModel;`). If you define classes
elsewhere, make sure no field shares a name with anything visible in scope
(imports, globals, builtins such as `len` or `type`).

Related: never name a local `len` — it shadows the builtin for the whole
function.

## 4. String building is quadratic unless chunked

`s = s + piece` copies `s` each time. All Prism writers accumulate into an
8 kB chunk, push full chunks into a parts array, and join once at the end
(`prism_binio.bjoin`); OBJ, PNG and FBX files are built this way.

## Other numbers

* crc32 (needed for PNG chunks) uses a 65 536-entry byte-XOR table plus a
  split-byte crc table, because the language has no bitwise operators:
  ≈ 1.7 s per 250 kB, verified against the standard test vector.
* adler32 defers its modulo to every 4 000 bytes: ≈ 0.35 s per 250 kB.
* binary FBX for a typical model: **≈ 0.1 s** (the format is cheap once the
  PNG bytes exist; the atlas encode dominates).
* preview renders (two 170×130 views, z-buffer + lambert + textures):
  ≈ 3 s for a few hundred faces. The rasterizer in `prism_preview.em` is
  deliberately one big function — see rule 1.

Typical end-to-end times (generate + obj + png + fbx + preview): simple
shapes 5-12 s, compound scenes ("castle", "three pine trees") 10-25 s,
image modes 15-30 s.
