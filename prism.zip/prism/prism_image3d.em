# prism_image3d - build 3D geometry from an input image.
#
# Three construction modes (spec.imageMode, or auto-detected):
#   terrain  image is a heightmap -> displaced grid, textured with the
#            image itself (colorized by altitude when the input is gray)
#   extrude  segment the subject (Otsu threshold -> largest component ->
#            Moore contour trace -> RDP simplify) and extrude the outline;
#            caps carry the image, sides get the subject's dominant color
#   lathe    per-row silhouette radius -> surface of revolution, tinted
#            with a palette sampled from the image
#
# Input images come from prism_imageio.load_any (BMP / PPM).
# emx-scope-safe

import image;
import mesh;
import mat4;
import prism_prims;
import prism_texgen;
import prism_uv;

# ---- small image helpers (inline-heavy: interpreter clones function args) ----

# nearest-resample img to wxh work resolution, returns [w,h,3,data]
fn shrink(img, w, h) {
    int d = 0; int iw = 0; int ih = 0; int ch = 0; int sd = 0; int x = 0; int y = 0;
    int sx = 0; int sy = 0; int si = 0; int n = 0;
    iw = img[0]; ih = img[1]; ch = img[2]; sd = img[3];
    d = [];
    n = 0;
    for (y = 0; y < h; ++y) {
        sy = y * ih // h;
        for (x = 0; x < w; ++x) {
            sx = x * iw // w;
            si = (sy * iw + sx) * ch;
            if (ch == 1) {
                d[n] = sd[si]; d[n + 1] = sd[si]; d[n + 2] = sd[si];
            } else {
                d[n] = sd[si]; d[n + 1] = sd[si + 1]; d[n + 2] = sd[si + 2];
            }
            n = n + 3;
        }
    }
    return [w, h, 3, d];
}

# grayscale array (0..1) from an rgb image
fn gray_of(img) {
    int g = 0; int i = 0; int n = 0; int sd = 0;
    n = img[0] * img[1];
    sd = img[3];
    g = [];
    for (i = 0; i < n; ++i) {
        g[i] = sd[i * 3] * 0.299 + sd[i * 3 + 1] * 0.587 + sd[i * 3 + 2] * 0.114;
    }
    return g;
}

# Otsu threshold over a 0..1 gray array using 32 bins.
# Returns [threshold, separability 0..1]
fn otsu(g) {
    int b = 0; int best = 0; int bestT = 0; int hist = 0; int i = 0; int mB = 0; int mF = 0;
    int n = 0; int sum = 0; int sumB = 0; int total = 0; int varB = 0; int varT = 0; int wB = 0;
    int wF = 0; int mean = 0; int t = 0; int v = 0;
    hist = [];
    for (i = 0; i < 32; ++i) { hist[i] = 0; }
    n = len(g);
    for (i = 0; i < n; ++i) {
        b = g[i] * 31.999;
        hist[b] = hist[b] + 1;
    }
    sum = 0.0;
    for (i = 0; i < 32; ++i) { sum = sum + i * hist[i]; }
    total = n;
    sumB = 0.0; wB = 0; best = 0.0; bestT = 16;
    for (t = 0; t < 32; ++t) {
        wB = wB + hist[t];
        if (wB == 0) { continue; }
        wF = total - wB;
        if (wF == 0) { break; }
        sumB = sumB + t * hist[t];
        mB = sumB / wB;
        mF = (sum - sumB) / wF;
        varB = wB * 1.0 * wF * (mB - mF) * (mB - mF);
        if (varB > best) { best = varB; bestT = t; }
    }
    # separability = between-class variance / total variance
    mean = sum / total;
    varT = 0.0;
    for (i = 0; i < 32; ++i) {
        v = i - mean;
        varT = varT + hist[i] * v * v;
    }
    if (varT <= 0.0) { return [(bestT + 1) / 32.0, 0.0]; }
    return [(bestT + 1) / 32.0, best / (total * 1.0 * total) / (varT / total)];
}

# binary mask: 1 where subject. picks the side of the threshold that touches
# the image border LESS (subjects rarely dominate the frame edge).
fn subject_mask(g, w, h) {
    int border0 = 0; int border1 = 0; int i = 0; int m = 0; int n = 0; int th = 0; int x = 0; int y = 0;
    int ot = 0;
    ot = otsu(g);
    th = ot[0];
    n = w * h;
    m = [];
    for (i = 0; i < n; ++i) {
        if (g[i] < th) { m[i] = 1; } else { m[i] = 0; }
    }
    border0 = 0; border1 = 0;
    for (x = 0; x < w; ++x) {
        border1 = border1 + m[x] + m[(h - 1) * w + x];
        border0 = border0 + 2;
    }
    for (y = 1; y < h - 1; ++y) {
        border1 = border1 + m[y * w] + m[y * w + w - 1];
        border0 = border0 + 2;
    }
    if (border1 * 2 > border0) {          # dark side touches border a lot -> invert
        for (i = 0; i < n; ++i) { m[i] = 1 - m[i]; }
    }
    return m;
}

# keep only the largest 4-connected component of mask, BFS.
# Returns [mask01, sizeOfLargest]
fn largest_component(mask, w, h) {
    int best = 0; int bestSize = 0; int cur = 0; int head = 0; int i = 0; int lab = 0;
    int m = 0; int n = 0; int p = 0; int q = 0; int size = 0; int x = 0; int y = 0; int out = 0;
    n = w * h;
    m = [];
    for (i = 0; i < n; ++i) { m[i] = mask[i]; }   # 1 = unvisited fg
    lab = 0; best = 0 - 1; bestSize = 0;
    for (i = 0; i < n; ++i) {
        if (m[i] != 1) { continue; }
        lab = lab + 1;
        cur = lab + 1;                       # labels start at 2
        q = [i];
        m[i] = cur;
        head = 0;
        size = 0;
        while (head < len(q)) {
            p = q[head];
            head = head + 1;
            size = size + 1;
            x = p % w; y = p // w;
            if (x > 0 && m[p - 1] == 1) { m[p - 1] = cur; q[len(q)] = p - 1; }
            if (x < w - 1 && m[p + 1] == 1) { m[p + 1] = cur; q[len(q)] = p + 1; }
            if (y > 0 && m[p - w] == 1) { m[p - w] = cur; q[len(q)] = p - w; }
            if (y < h - 1 && m[p + w] == 1) { m[p + w] = cur; q[len(q)] = p + w; }
        }
        if (size > bestSize) { bestSize = size; best = cur; }
    }
    out = [];
    for (i = 0; i < n; ++i) {
        if (m[i] == best) { out[i] = 1; } else { out[i] = 0; }
    }
    return [out, bestSize];
}

# Moore-neighbor contour trace. Returns [x0,y0, x1,y1, ...] (pixel coords).
fn trace_contour(mask, w, h) {
    int cx = 0; int cy = 0; int dirn = 0; int found = 0; int i = 0; int k = 0; int n = 0;
    int nx = 0; int ny = 0; int out = 0; int sx = 0; int sy = 0; int start = 0; int steps = 0;
    int dx = 0; int dy = 0; int d = 0;
    # 8 directions clockwise starting E
    dx = [1, 1, 0, 0 - 1, 0 - 1, 0 - 1, 0, 1];
    dy = [0, 1, 1, 1, 0, 0 - 1, 0 - 1, 0 - 1];
    n = w * h;
    start = 0 - 1;
    for (i = 0; i < n; ++i) { if (mask[i] == 1) { start = i; break; } }
    if (start < 0) { return []; }
    sx = start % w; sy = start // w;
    cx = sx; cy = sy;
    dirn = 6;                                 # pretend we arrived heading N
    out = [];
    steps = 0;
    while (steps < 20000) {
        out[len(out)] = cx;
        out[len(out)] = cy;
        found = false;
        # search neighbors clockwise beginning just after the backtrack dir
        for (k = 0; k < 8; ++k) {
            d = (dirn + 6 + k) % 8;           # start from dir-2 (Moore tracing)
            nx = cx + dx[d]; ny = cy + dy[d];
            if (nx < 0 || ny < 0 || nx >= w || ny >= h) { continue; }
            if (mask[ny * w + nx] == 1) {
                cx = nx; cy = ny; dirn = d;
                found = true;
                break;
            }
        }
        if (!found) { break; }                 # isolated pixel
        if (cx == sx && cy == sy) { break; }
        steps = steps + 1;
    }
    return out;
}

# Ramer-Douglas-Peucker simplification (iterative, explicit stack).
fn rdp(pts, eps) {
    int a = 0; int ax = 0; int ay = 0; int b = 0; int bx = 0; int by = 0; int best = 0;
    int bestD = 0; int dxx = 0; int dyy = 0; int i = 0; int keep = 0; int ll = 0; int n = 0;
    int out = 0; int px = 0; int py = 0; int stack = 0; int d = 0; int sp = 0;
    n = len(pts) // 2;
    if (n <= 3) { return pts; }
    keep = [];
    for (i = 0; i < n; ++i) { keep[i] = false; }
    keep[0] = true; keep[n // 2] = true;       # anchor two far apart points
    stack = [0, n // 2, n // 2, n - 1];        # segments [a,b] (indices)
    sp = len(stack);
    while (sp > 0) {
        b = stack[sp - 1]; a = stack[sp - 2];
        sp = sp - 2;
        ax = pts[a * 2]; ay = pts[a * 2 + 1];
        bx = pts[b * 2]; by = pts[b * 2 + 1];
        dxx = bx - ax; dyy = by - ay;
        ll = sqrt(dxx * dxx + dyy * dyy);
        if (ll < 1.0e-9) { ll = 1.0e-9; }
        best = 0 - 1; bestD = eps;
        for (i = a + 1; i < b; ++i) {
            px = pts[i * 2]; py = pts[i * 2 + 1];
            d = dxx * (ay - py) - (ax - px) * dyy;
            if (d < 0) { d = 0.0 - d; }
            d = d / ll;
            if (d > bestD) { bestD = d; best = i; }
        }
        if (best >= 0) {
            keep[best] = true;
            stack[sp] = a; stack[sp + 1] = best;
            stack[sp + 2] = best; stack[sp + 3] = b;
            sp = sp + 4;
        }
    }
    keep[n - 1] = true;
    out = [];
    for (i = 0; i < n; ++i) {
        if (keep[i]) {
            out[len(out)] = pts[i * 2];
            out[len(out)] = pts[i * 2 + 1];
        }
    }
    return out;
}

# average color of masked pixels
fn mask_color(img, mask) {
    int b = 0; int cnt = 0; int g = 0; int i = 0; int n = 0; int r = 0; int sd = 0;
    n = img[0] * img[1];
    sd = img[3];
    r = 0.0; g = 0.0; b = 0.0; cnt = 0;
    for (i = 0; i < n; ++i) {
        if (mask[i] == 1) {
            r = r + sd[i * 3]; g = g + sd[i * 3 + 1]; b = b + sd[i * 3 + 2];
            cnt = cnt + 1;
        }
    }
    if (cnt == 0) { return [0.5, 0.5, 0.5]; }
    return [r / cnt, g / cnt, b / cnt];
}

fn is_grayish(img) {
    int d = 0; int i = 0; int n = 0; int s = 0; int step = 0;
    d = img[3];
    n = img[0] * img[1];
    s = 0.0;
    step = n // 400;
    if (step < 1) { step = 1; }
    for (i = 0; i < n; i = i + step) {
        s = s + abs(d[i * 3] - d[i * 3 + 1]) + abs(d[i * 3 + 1] - d[i * 3 + 2]);
    }
    return s / (n / step) < 0.03;
}

# colorize a heightmap by altitude: water -> grass -> rock -> snow
fn colorize_height(img) {
    int g = 0; int i = 0; int n = 0; int out = 0; int c = 0; int pal = 0;
    n = img[0] * img[1];
    g = gray_of(img);
    pal = [[0.13,0.25,0.45],[0.16,0.42,0.55],[0.24,0.52,0.25],[0.42,0.38,0.24],[0.52,0.50,0.48],[0.94,0.95,0.97]];
    out = [];
    for (i = 0; i < n; ++i) {
        c = prism_texgen.ramp(pal, g[i]);
        out[i * 3] = c[0]; out[i * 3 + 1] = c[1]; out[i * 3 + 2] = c[2];
    }
    return [img[0], img[1], 3, out];
}

# crop a normalized-rect region and resample to maxDim
fn crop_scaled(img, u0, v0, u1, v1, maxDim) {
    int ch = 0; int d = 0; int dh = 0; int dw = 0; int ih = 0; int iw = 0; int n = 0;
    int sd = 0; int si = 0; int sx = 0; int sy = 0; int x = 0; int y = 0; int rw = 0; int rh = 0;
    int px0 = 0; int py0 = 0;
    iw = img[0]; ih = img[1]; ch = img[2]; sd = img[3];
    px0 = u0 * iw; py0 = v0 * ih;
    rw = (u1 - u0) * iw; rh = (v1 - v0) * ih;
    if (rw < 2) { rw = 2; }
    if (rh < 2) { rh = 2; }
    if (rw >= rh) { dw = maxDim; dh = maxDim * rh // rw; }
    else { dh = maxDim; dw = maxDim * rw // rh; }
    if (dw < 2) { dw = 2; }
    if (dh < 2) { dh = 2; }
    d = [];
    n = 0;
    for (y = 0; y < dh; ++y) {
        sy = int(py0) + y * int(rh) // dh;
        if (sy > ih - 1) { sy = ih - 1; }
        if (sy < 0) { sy = 0; }
        for (x = 0; x < dw; ++x) {
            sx = int(px0) + x * int(rw) // dw;
            if (sx > iw - 1) { sx = iw - 1; }
            if (sx < 0) { sx = 0; }
            si = (sy * iw + sx) * ch;
            if (ch == 1) { d[n] = sd[si]; d[n + 1] = sd[si]; d[n + 2] = sd[si]; }
            else { d[n] = sd[si]; d[n + 1] = sd[si + 1]; d[n + 2] = sd[si + 2]; }
            n = n + 3;
        }
    }
    return [dw, dh, 3, d];
}

# ---- modes ---------------------------------------------------------------------

fn build_terrain(spec, img) {
    int m = 0; int texImg = 0; int work = 0;
    work = shrink(img, 100, 100);
    m = prism_prims.terrain(work, 2.4, 0.85, 56);
    if (is_grayish(work)) { texImg = colorize_height(shrink(img, 160, 160)); }
    else { texImg = shrink(img, 160, 160); }
    return [[m, "__image__", texImg, "img|terrain"]];
}

fn build_extrude(spec, img) {
    int caps = 0; int col = 0; int comp = 0; int contour = 0; int g = 0; int h = 0; int i = 0;
    int mask = 0; int n = 0; int parts = 0; int poly = 0; int pr = 0; int scalef = 0; int sides = 0;
    int simp = 0; int texImg = 0; int w = 0; int work = 0; int cx = 0; int cy = 0;
    int minx = 0; int maxx = 0; int miny = 0; int maxy = 0; int dim = 0; int depth = 0;
    w = 110;
    h = 110 * img[1] // img[0];
    if (h < 24) { h = 24; }
    if (h > 150) { w = 150 * img[0] // img[1]; h = 150; }
    if (w < 24) { w = 24; }
    work = shrink(img, w, h);
    g = gray_of(work);
    mask = subject_mask(g, w, h);
    comp = largest_component(mask, w, h);
    mask = comp[0];
    if (comp[1] < 30) {
        # segmentation failed: fall back to terrain
        return build_terrain(spec, img);
    }
    contour = trace_contour(mask, w, h);
    if (len(contour) < 16) { return build_terrain(spec, img); }
    simp = rdp(contour, 1.9);
    n = len(simp) // 2;
    if (n > 90) { simp = rdp(contour, 3.0); n = len(simp) // 2; }
    if (n < 3) { return build_terrain(spec, img); }
    # to world coords: center, flip Y, scale so max dim ~ 1.8
    minx = simp[0]; maxx = simp[0]; miny = simp[1]; maxy = simp[1];
    for (i = 1; i < n; ++i) {
        if (simp[i * 2] < minx) { minx = simp[i * 2]; }
        if (simp[i * 2] > maxx) { maxx = simp[i * 2]; }
        if (simp[i * 2 + 1] < miny) { miny = simp[i * 2 + 1]; }
        if (simp[i * 2 + 1] > maxy) { maxy = simp[i * 2 + 1]; }
    }
    cx = (minx + maxx) / 2.0; cy = (miny + maxy) / 2.0;
    dim = maxx - minx;
    if (maxy - miny > dim) { dim = maxy - miny; }
    if (dim <= 0.0) { dim = 1.0; }
    scalef = 1.8 / dim;
    poly = [];
    for (i = 0; i < n; ++i) {
        poly[i * 2] = (simp[i * 2] - cx) * scalef;
        poly[i * 2 + 1] = (cy - simp[i * 2 + 1]) * scalef;    # flip Y
    }
    depth = 0.34;
    pr = prism_prims.extrude_parts(poly, depth);
    caps = pr[0]; sides = pr[1];
    # texture cell: the subject's bounding box cut from the source image
    texImg = crop_scaled(img, minx * 1.0 / w, miny * 1.0 / h, maxx * 1.0 / w, maxy * 1.0 / h, 150);
    col = mask_color(work, mask);
    parts = [];
    parts[0] = [caps, "__image__", texImg, "img|cap"];
    parts[1] = [sides, "plain", prism_texgen.palette_from_color(col), "img|side"];
    return parts;
}

fn build_lathe(spec, img) {
    int comp = 0; int g = 0; int h = 0; int i = 0; int m = 0; int mask = 0; int maxr = 0;
    int minRow = 0; int maxRow = 0; int pal = 0; int profile = 0; int r = 0; int rows = 0;
    int w = 0; int work = 0; int x = 0; int y = 0; int cx = 0; int cnt = 0; int hgt = 0;
    int prev = 0; int steps = 0; int t = 0; int yy = 0;
    w = 90; h = 110;
    work = shrink(img, w, h);
    g = gray_of(work);
    mask = subject_mask(g, w, h);
    comp = largest_component(mask, w, h);
    mask = comp[0];
    if (comp[1] < 30) { return build_terrain(spec, img); }
    # per-row max distance from the mask centroid column
    cx = 0.0; cnt = 0;
    for (i = 0; i < w * h; ++i) {
        if (mask[i] == 1) { cx = cx + i % w; cnt = cnt + 1; }
    }
    cx = cx / cnt;
    rows = [];
    minRow = 0 - 1; maxRow = 0 - 1;
    for (y = 0; y < h; ++y) {
        maxr = 0.0;
        for (x = 0; x < w; ++x) {
            if (mask[y * w + x] == 1) {
                r = x - cx;
                if (r < 0) { r = 0.0 - r; }
                if (r > maxr) { maxr = r; }
            }
        }
        rows[y] = maxr;
        if (maxr > 0.0) {
            if (minRow < 0) { minRow = y; }
            maxRow = y;
        }
    }
    if (maxRow - minRow < 4) { return build_terrain(spec, img); }
    # smooth (3-tap, two passes)
    for (t = 0; t < 2; ++t) {
        prev = rows[minRow];
        for (y = minRow + 1; y < maxRow; ++y) {
            r = (prev + rows[y] * 2.0 + rows[y + 1]) * 0.25;
            prev = rows[y];
            rows[y] = r;
        }
    }
    # resample bottom->top into a lathe profile (image y grows downward)
    steps = 22;
    hgt = 1.7;
    profile = [];
    for (i = 0; i <= steps; ++i) {
        yy = maxRow - (maxRow - minRow) * i / steps;
        profile[i * 2] = rows[int(yy)] * (1.7 / (maxRow - minRow));
        profile[i * 2 + 1] = hgt * i / steps;
    }
    m = prism_prims.lathe(profile, 26, true, true);
    m = prism_uv.project(m, "keep");
    pal = prism_texgen.palette_from_image(img, 4, spec.seed);
    return [[m, "plain", pal, "img|lathe"]];
}

fn auto_mode(img) {
    int g = 0; int ot = 0; int work = 0;
    work = shrink(img, 80, 80);
    g = gray_of(work);
    ot = otsu(g);
    if (ot[1] > 0.62) { return "extrude"; }
    return "terrain";
}

fn build(spec, img) {
    int mode = 0;
    mode = spec.imageMode;
    if (mode == "") { mode = auto_mode(img); }
    if (mode == "terrain") { return build_terrain(spec, img); }
    if (mode == "lathe") { return build_lathe(spec, img); }
    return build_extrude(spec, img);
}
